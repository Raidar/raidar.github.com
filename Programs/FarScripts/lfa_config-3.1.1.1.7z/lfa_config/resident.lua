--[[ lfa_config ]]--

----------------------------------------
--[[ description:
  -- Using in plugins.
  -- Использование в плагинах.
--]]
----------------------------------------
--[[ uses:
  LuaFAR,
  LF context.
  -- group: LFA config.
--]]
--------------------------------------------------------------------------------

----------------------------------------
local F = far.Flags

----------------------------------------
local lfa_common = ctxdata.config.lfa_common

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local lfa_config = context.use.lfa_config
local setEditorParameters = lfa_config.setEditorParameters
local drawLineNumbers = lfa_config.drawLineNumbers
local drawRightBorder = lfa_config.drawRightBorder

---------------------------------------- redraw
--local redraw = F.EE_REDRAW
--local redrawAll    = 0 --F.EEREDRAW_ALL

---------------------------------------- actions
local actions = {}

actions[F.EE_REDRAW] = function (id, param)

  local ei = editor.GetInfo()
  if not ei then return end

  if ei.EditorID ~= id then return end

  --drawLineNumbers(false, ei)
  drawLineNumbers(true, ei)
  editor.DelColor()
  drawRightBorder(ei)
  --editor.InsertText(nil, "*")

end

actions[F.EE_GOTFOCUS] = function ()

  return drawLineNumbers(true)

end

actions[F.EE_READ] = function ()

  if lfa_common.useAutoConfig then
    setEditorParameters()
    --setEditorParameters(true)
    drawLineNumbers(true)

  end
end

--[[
actions[F.EE_CHANGE] = function ()

  local ei = editor.GetInfo()
  if not ei then return end

  if ei.EditorID ~= id then return end

  --drawLineNumbers(true, ei)
  drawRightBorder(ei)

end
--]]

----------------------------------------

function ProcessEditorEvent (id, event, param)

  local f = actions[event]
  if f then f(id, param) end

  return 0

end ---- ProcessEditorEvent

if not lfa_common.doNotCatchHotKeys then
--do
  --[[
  local keys = {

    F10 = true,
    ["Alt+B"] = true,
    ESCAPE = true,
    RETURN = true,
    SHIFT = true,
    MENU = true,
    CONTROL = true,

  }
  --]]

  local lnRedraw = false
  local rctrl, shift, band = F.RIGHT_CTRL_PRESSED, F.SHIFT_PRESSED, bit64.band
  local ctrl = rctrl + F.LEFT_CTRL_PRESSED
  local modifiers = ctrl + F.LEFT_ALT_PRESSED + F.RIGHT_ALT_PRESSED + shift

  local saveFile = lfa_config.saveFile

  function ProcessEditorInput (rec)

    if rec.EventType ~= F.KEY_EVENT then return false end

    editor.DelColor() -- Удаление цветовых областей пакета!
    if rec.KeyDown then
      local scanCode = rec.VirtualScanCode
      local cKey = rec.ControlKeyState
      if ( band(cKey, rctrl) > 0 or                             -- RCtrl или
         ( band(cKey, ctrl) > 0 and band(cKey, shift) > 0 ) )   -- Ctrl+Shift
         and scanCode > 0 and scanCode < 12 then                -- Esc, 1..9, 0
        lnRedraw = true

      end

      -- [[
      --local kcode = rec.VirtualKeyCode
      if scanCode == 0x71 and band(cKey, modifiers) == 0 then -- F2
        return saveFile()

      end
      --]]

    elseif lnRedraw then
      drawLineNumbers(true)
      lnRedraw = false

    end

    return false

  end ---- ProcessEditorInput

end

local resident = {

  ProcessEditorEvent = ProcessEditorEvent,
  ProcessEditorInput = ProcessEditorInput,

} --- resident

--------------------------------------------------------------------------------
return resident
--------------------------------------------------------------------------------
