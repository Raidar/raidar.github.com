--[[ lfa_config ]]--

--------------------------------------------------------------------------------

local min = math.min

----------------------------------------
local bit = bit64
local band = bit.band
--local band, bor = bit.band, bit.bor
--local bshl, bshr = bit.lshift, bit.rshift

----------------------------------------
local far = far

local F = far.Flags
local addColor = editor.AddColor
--local delColor = editor.DelColor

----------------------------------------
local context, ctxdata = context, ctxdata

--local utils = require 'context.utils.useUtils'
--local tables = require 'context.utils.useTables'
local colors = require 'context.utils.useColors'

local editors = ctxdata.editors

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local lfa_config = context.use.lfa_config
--local GetDelta = lfa_config.editorGetDelta

local alltabs = F.EOPT_EXPANDALLTABS

function lfa_config.drawRightBorder (einfo)

  local ced = editors.current or {}
  local cfg = ced.lfa_editor
  if not cfg or not cfg.ColorizeElements then return end

  einfo = einfo or editor.GetInfo()
  local top = einfo.TopScreenLine

  --delColor()

  --logShow(mcfg, "lfa_config", 3)
  local mcfg = ced.lfa_vision or {}
  local showRm  = mcfg.ShowRightMargin
  local showEol = mcfg.ShowEndOfLine

  local rbPos   = mcfg.RightMarginPos
  local rbCol   = colors:dataColor(mcfg, 'RightMarginColor')
  local eolCol  = colors:dataColor(mcfg, 'EndOfLineColor') or rbCol

  --local res = GetDelta(einfo)
  --local res = lfa_config.editorDelta or GetDelta()
  --local sb, kb = res.DPosY, res.EPosY
  --local lastScreenLine = top + einfo.WindowSizeY - sb - kb + 1

  local lastScreenLine = top + einfo.WindowSizeY - 1
  local verylastline = einfo.TotalLines
  local lastline = min(lastScreenLine, verylastline)

  local notabs = band(einfo.Options, alltabs) ~= 0
  local nolen = not mcfg.TextCoversMargin

  -- Colorize last line:
  local llLen
  local showLL, showAllowedLL = mcfg.ShowLastLine, mcfg.ShowLastMargin
  if showLL or showAllowedLL then
    local llCol  = colors:dataColor(mcfg, 'LastLineColor') or rbCol
    local allCol = colors:dataColor(mcfg, 'LastMarginColor') or rbCol
    local lastlinetext = editor.GetString(nil, verylastline, 3)
    if lastlinetext then
      llLen = lastlinetext:len()

      if showLL then
        addColor(nil, verylastline, llLen, einfo.WindowSizeX, 0, llCol)

      end

      if showAllowedLL then
        addColor(nil, verylastline, llLen + ((mcfg.ShowEndOfFile or mcfg.ShowEndOfLine) and 1 or 0), rbPos, 0, allCol)

      end
    end
  end

  -- Colorize visible lines:
  for i = top, lastline do
    local pos = notabs and rbPos or editor.TabToReal(nil, i, rbPos)

    -- Colorize right border:
    local len
    if showRm and pos then
      if nolen then
        addColor(nil, i, pos, pos, 0, rbCol)

      else
        len = editor.GetString(nil, i, 3):len()
        if pos >= len then
          addColor(nil, i, pos, pos, 0, rbCol)

        end
      end
    end

    -- Colorize end of line:
    if showEol then
      len = len or editor.GetString(nil, i, 3):len()
      addColor(nil, i, len + 1, len + 1, 0, eolCol)

    end
  end

  -- Colorize EOF:
  if mcfg.ShowEndOfFile then
    local eofCol = colors:dataColor(mcfg, 'EndOfFileColor') or rbCol
    llLen = llLen or editor.GetString(nil, verylastline, 3):len()
    addColor(nil, verylastline, llLen + 1, llLen + 1, 0, eofCol)

  end

  --editor.SetPosition(nil, einfo)
  editor.SetPosition(einfo.EditorID, einfo)

end
--------------------------------------------------------------------------------
