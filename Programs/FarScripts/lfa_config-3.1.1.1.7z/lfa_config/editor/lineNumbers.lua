--[[ lfa_config ]]--

--------------------------------------------------------------------------------

local tostring = tostring

----------------------------------------
--local F = far.Flags

----------------------------------------
local context, ctxdata = context, ctxdata

local colors = require 'context.utils.useColors'

local editors = ctxdata.editors

--------------------------------------------------------------------------------
local lfa_config = context.use.lfa_config

local GetDelta = lfa_config.editorGetDelta

local cfgCommon = ctxdata.config.lfa_common
--local fillerCol = colors:getColor"black on cyan"

local repTable = { pos = -1, line = -1, bm = -1, }
--local repTable = { pos = 0, line = 0, bm = 0, }

function lfa_config.drawLineNumbers (force, einfo)

  local ced = editors.current or {}
  local dn = rawget(ced, 'drawNumbers')
  if not dn then return end

  einfo = einfo or editor.GetInfo()
  local top = einfo.TopScreenLine
  if not force and top == dn.top then return end
  dn.top = top

  local cfg = ced.lfa_vision
  local bookMarks
  if cfg.ShowBookmarks then
    bookMarks = {}
    local farBookMarks = editor.GetBookmarks()
    for i = 1, #farBookMarks do
      if farBookMarks[i].Line > 0 then
        bookMarks[farBookMarks[i].Line] = i - 1

      end
    end
  end

  local res = GetDelta(einfo)
  --local res = lfa_config.editorDelta or GetDelta()
  local sb, kb = res.DPosY, res.EPosY
  if sb > 0 then dn.fill(0) end
  if kb > 0 then dn.fill(einfo.WindowSizeY + 1) end

  --[[
  repTable.ln  = sb
  repTable.pos = sb
  repTable.bm  = false
  dn.text(repTable)

  repTable.ln  = kb
  repTable.pos = sb + 1
  repTable.bm  = false
  dn.text(repTable)
  for i = sb + 2, einfo.WindowSizeY - kb + 1  do
  --]]

  for i = sb, einfo.WindowSizeY + (1 - kb) do
    local line = top + i + 1 - sb
    repTable.ln  = line
    repTable.pos = i
    repTable.bm  = bookMarks and bookMarks[line] -- TODO: Check this

    dn.text(repTable)

  end
end ---- drawLineNumbers

function lfa_config.drawLineNumbersInit (tlines)

  local nwidth = tostring(tlines):len() + 1
  local width = cfgCommon.LinePanelMinWidth
  width = math.max(nwidth, width)

  local ced = editors.current
  if not ced then return end

  local curEditor = ced.lfa_editor
  local curVision = ced.lfa_vision
  if not curVision or not curEditor then return end

  local bmText = curVision.BookmarkText
  local pattern = '%$(%a+)'
  local dn = { nwidth = width }

  if curVision.ShowBookmarks and bmText then
    repTable.ln = tlines
    repTable.line = tostring(tlines)
    repTable.bm = 0
    width = math.max(width, bmText:gsub(pattern, repTable):len() + 1)

  end
  dn.width = width

  do
    local emInterval = curVision.EmphInterval or 1.1
    local fCol     = colors:dataColor(curVision, 'Color')
    local fEmCol   = colors:dataColor(curVision, 'EmphColor')
    local fBmCol   = colors:dataColor(curVision, 'BookmarkColor')
    local fFillCol = colors:dataColor(curVision, 'FillColor')
    local farText = far.Text

    local numForm = ('%%%ii'):format(dn.nwidth - 1)
    local strForm = '$line '
    --far.Message((' '):rep(width - 3 - strForm:gsub(pattern, repTable):len()):len(), strForm:gsub(pattern, repTable):len())
    --strForm = (' '):rep(width - 3 - strForm:gsub(pattern, repTable):len())..strForm..' '
    strForm = strForm..(' '):rep(width - strForm:gsub(pattern, repTable):len())

    local filler = (' '):rep(width)
    local bmForm = bmText and
                   bmText..(' '):rep(width - bmText:gsub(pattern, repTable):len())

    local function form (tbl)

      tbl.line = numForm:format(tbl.ln)
      if tbl.bm and bmForm then
        return bmForm:gsub(pattern, tbl)

      end

      return strForm:gsub(pattern, tbl)

    end --

    function dn.text (t)

      local col = t.bm and fBmCol or
                  (t.ln % emInterval == 0 and fEmCol or fCol)

      farText(0, t.pos, col, form(t):sub(1, width))

    end --

    function dn.fill (pos)

      farText(0, pos, fFillCol, filler)

    end
  end

  return dn

end ---- drawLineNumbersInit
--------------------------------------------------------------------------------
