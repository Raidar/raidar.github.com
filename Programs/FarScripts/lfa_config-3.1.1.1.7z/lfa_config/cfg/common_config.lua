--[[ lfa_config ]]--

----------------------------------------
--[[ description:
  -- Common configuration.
  -- Общая конфигурация.
--]]
----------------------------------------
--[[ uses:
  nil.
  -- group: Config, Datas.
--]]
--------------------------------------------------------------------------------
local cfg = {
  useAutoConfig = true,

  -- default line numbering settings
  LinePanelMinWidth   = 3,       -- minimal panel width
  LinePanelLinesLimit = 100000,  -- maximal number of lines in file to show the panel
} --- cfg

return cfg
--------------------------------------------------------------------------------
