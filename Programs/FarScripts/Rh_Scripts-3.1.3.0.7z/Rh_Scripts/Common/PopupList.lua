--[[ Popup List ]]--

----------------------------------------
--[[ description:
  -- Popup list.
  -- Всплывающий список.
--]]
----------------------------------------
--[[ uses:
  LuaFAR,
  far2,
  Rh Utils, RectMenu.
  -- areas: editor.
--]]
----------------------------------------
--[[ code from:
*. Editor\WordComplete.lua
--]]
--------------------------------------------------------------------------------

local require = require
local setmetatable = setmetatable

----------------------------------------
--local bit = bit64
--local band, bor = bit.band, bit.bor
--local bshl, bshr = bit.lshift, bit.rshift

--local t_sort = table.sort

----------------------------------------
local win, far, editor = win, far, editor
local F = far.Flags

----------------------------------------
--local context = context
local logShow = context.ShowInfo

--local lua = require 'context.utils.useLua'
--local utils = require 'context.utils.useUtils'
--local tables = require 'context.utils.useTables'
--local numbers = require 'context.utils.useNumbers'
--local strings = require 'context.utils.useStrings'
--local colors = require 'context.utils.useColors'
--local datas = require 'context.utils.useDatas'
--local locale = require 'context.utils.useLocale'

--local isFlag, delFlag = utils.isFlag, utils.delFlag

--local abs = math.abs
--local min2, max2 = numbers.min2, numbers.max2

--local addNewData = tables.extend

----------------------------------------
local farUt = require "Rh_Scripts.Utils.Utils"
local macUt = require "Rh_Scripts.Utils.Macro"
local menUt = require "Rh_Scripts.Utils.Menu"

----------------------------------------
--local fkeys = require "far2.keynames"
--local InputRecordToName = fkeys.InputRecordToName

--local keyUt = require "Rh_Scripts.Utils.Keys"

--local isVKeyChar = keyUt.isVKeyChar
--local IsModAlt, IsModShift = keyUt.IsModAlt, keyUt.IsModShift
--local GetModBase = keyUt.GetModBase

--------------------------------------------------------------------------------
local unit = {}

---------------------------------------- Main data
unit.ScriptName = "PopupList"
unit.ScriptPath = "scripts\\Rh_Scripts\\Common\\"

---------------------------------------- ---- Custom
--[[
unit.DefCustom = {
  name = unit.ScriptName,
  path = unit.ScriptPath,

  label = "PL",

  --help   = { topic = unit.ScriptName, },
  locale = { kind = 'load', },
} -- DefCustom
--]]
----------------------------------------
--unit.DefOptions = {
--} -- DefOptions

---------------------------------------- ---- Config
--unit.DefCfgData = { -- Конфигурация по умолчанию:
--} -- DefCfgData

---------------------------------------- ---- Types
--unit.DlgTypes = { -- Типы элементов диалога:
--} -- DlgTypes

---------------------------------------- ---- Popup
local usercall = farUt.usercall
--local unit.RunMenu = require "Rh_Scripts.RectMenu.RectMenu"
unit.RunMenu = usercall(nil, require, "Rh_Scripts.RectMenu.RectMenu")

---------------------------------------- ---- Keys

---------------------------------------- Main class
local TMenu = {
  --Guid       = win.Uuid(""),
  --ConfigGuid = win.Uuid(""),
}
local MMenu = { __index = TMenu }

local function CreateMenu (Properties, Items, BreakKeys, Additions) --> (object)

  local self = {
    Props     = Properties,
    Items     = Items,
    BreakKeys = BreakKeys,
    Options   = Options,
  } --- self

  return setmetatable(self, MMenu)
end -- CreateMain

---------------------------------------- Dialog

---------------------------------------- Menu making
do
  --local ItemHotLen = 2

-- Заполнение списка-меню.
function TMenu:MakePopupMenu () --> (table)

  local Cfg = self.CfgData

  -- Создание таблицы пунктов меню.
  local Count = self.Words.n --or #self.Words
  --logShow(self.Words, "Words for Items")
  local Width, Height = 0, Count
  if Count == 0 and
     (not Cfg.EmptyList or -- Не пустой список слов или
      -- Не пустой список слов при первоначальном показе
      self.Current.StartMenu and not Cfg.EmptyStart) then
    return
  end

  --local Words = self.Words
  --logShow(self.Words, "Words for Items")
  local Items = {}
  for k = 1, Count do
    local Text
    Items[#Items+1], Text = self:MakePopupItem(k)
    Width = max2(Width, Text:len())
  end
  self.Items = Items
  if Cfg.HotChars then Width = Width - 1 end

  -- Определение области маркировки.
  local function MakeSlabMark ()
    --logShow(self.Pattern, "Patterns")
    local SlabPat = self.Pattern.Slab
    local SlabLen = self.Current.Slab:len()

    if Cfg.HotChars then    -- text ~= Word:
      return Cfg.UseMagic and { " "..SlabPat } or
             { ItemHotLen + 1, ItemHotLen + SlabLen }
    else                    -- text == Word:
      return Cfg.UseMagic and { SlabPat } or { 1, SlabLen }
    end
  end --

  -- Задание параметров меню RectMenu.
  local Props = self.Props
  Props.Id = Props.Id or self.PopupGuid
  Props.HelpTopic = self.Custom.help.tlink

  local RM = Props.RectMenu
  --logShow(RM, "RectMenu Props")
  if Cfg.SlabMark then RM.TextMark = MakeSlabMark() end -- Маркировка
  -- Расчёт позиции и размера окна:
  local Info, Popup = EditorGetInfo(), self.Popup
  Width, Height = Width + Popup.LenH, Height + Popup.LenV
  --[[
  local Rect, CursorPos = GetFarRect(), far.AdvControl(F.ACTL_GETCURSORPOS)
  logShow({ Info, Rect, CursorPos }, "Window info")
  --]]
  local Pos = {
    x = Info.CurPos  - Info.LeftPos       + Popup.PosX,
    y = Info.CurLine - Info.TopScreenLine + Popup.PosY,
    angle = "",
  } ---
  --logShow({ RM.MenuEdge, Width, Height, Pos, Info }, "Position")
  if Pos.y <= Height then
    Pos.y = Pos.y + 1
    Pos.angle = "T"
  else
    Pos.y = Pos.y - Height
    Pos.angle = "B"
  end
  -- Warning: "<" & "+1" instead of "<=" because editor may have scroll bar.
  if Pos.x + Width + 1 < Info.WindowSizeX then
    --Pos.x = Pos.x 
    Pos.angle = Pos.angle.."L"
  else
    Pos.x = Pos.x - Width - 1
    Pos.angle = Pos.angle.."R"
  end
  RM.Position = Pos

  local Colors = RM.Colors
  if Colors.BorderAngle then
    Colors.Borders = { [Pos.angle] = Colors.BorderAngle, }
  end
  --logShow(RM.Position, "RectMenu Position")
  --logShow(Items, "Items")

  return true
end -- MakePopupMenu

end -- do

---------------------------------------- ---- Run
function TMenu:Run () --> (bool | nil)
  return usercall(nil, unit.RunMenu,
                  self.Props, self.Items, self.BreakKeys, self.Options)
  --return unit.RunMenu(self.Props, self.Items, self.BreakKeys, self.Options)
end -- Run

---------------------------------------- main

function unit.Menu (Properties, Items, BreakKeys, Options) --> (bool | nil)

  if not Items then return end

  local _Menu = CreateMenu(Properties, Items, BreakKeys, Options)
  if not _Menu then return end

  return _Menu:Run()
end ---- Menu

--------------------------------------------------------------------------------
return unit
--------------------------------------------------------------------------------
