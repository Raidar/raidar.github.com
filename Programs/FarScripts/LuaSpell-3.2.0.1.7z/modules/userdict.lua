--[[ UserDict ]]--

----------------------------------------
--[[ description:
  -- User dictionary handling.
  -- Обработка пользовательских словарей.
--]]
----------------------------------------
--local win = win

--local ffi = require'ffi'

--------------------------------------------------------------------------------
local unit = {}

local lib = false

---------------------------------------- Main data
unit.ScriptName = "UserDict"

---------------------------------------- Main class
local TMain = {
  --Guid       = win.Uuid(""),
}
local MMain = { __index = TMain }

---------------------------------------- Methods
function TMain:free ()
  local h = self.handle
  if not h then return end

  self.handle = nil
end ---- free

function TMain:match (s)
  local h = self.handle
  if not h or not s then return end

  return self.handle[s] or false
end ---- match

--[[
function TMain:spell (s)
  local h = self.handle
  if not h or not s then return end

  local ret = self.handle[s] and 1 or 2
  return ret ~= 0, ret == 2 and 'warn' or nil
end ---- spell
--]]
--[[
function TMain:get_dic_encoding ()
  return
end -- get_dic_encoding

--local tinsert = table.insert

function TMain:suggest (word)
  return nil
end ---- suggest

function TMain:analyze (word)
  return nil
end ---- analyze

function TMain:stem (word)
  return nil
end ---- stem

function TMain:generate (word, word2)
  return nil
end ---- generate

function TMain:add_word (word, example)
  return nil
end ---- add_word

function TMain:remove_word (word)
  return nil
end ---- remove_word

--extras
function TMain:add_dic (dpath, key)
  return nil
end ---- add_dic
--]]
---------------------------------------- main
do
  local io_open = io.open

function unit.load (path, key)
  local f = io_open(path, 'r')
  if not f then return end -- Нет словаря

  -- Пропуск заголовка:
  local s = ""
  while s and not s:find("^%-%-%-") do
    --logShow(s, "Header line")
    s = f:read('*l')
  end
  if s == nil then return end -- Нет слов

  -- Чтение слов:
  s = f:read('*l') -- first
  if s == nil then return end -- Нет слов

  local t = {}
  while s do
    --logShow(s, "Word line")
    t[s] = true

    s = f:read('*l') -- next
  end

  return t
end ---- load

end -- do

function unit.new (path, key)

  local h = unit.load(path, key)

  local self = {
    handle = h,
  } --- self

  return setmetatable(self, MMain)
end -- new

--------------------------------------------------------------------------------
return unit
--------------------------------------------------------------------------------
