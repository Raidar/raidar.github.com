--[[ LFc testing ]]--
--[[ useLoc: English ]]--

--------------------------------------------------------------------------------
local Data = {

  Test = 'Test',
  TestMessage = 'Test of localization',
  Warning = 'Warning',
  WarnMsg = 'Warning with localization',

  -- Dialog items texts.
  btn_Ok     = 'Ok',
  btn_Close  = 'Close',
  btn_Cancel = 'Cancel',
  btn_Apply  = 'Apply',

} --- Data

return Data
--------------------------------------------------------------------------------
