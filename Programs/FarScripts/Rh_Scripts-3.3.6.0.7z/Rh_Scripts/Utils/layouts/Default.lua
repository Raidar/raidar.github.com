--[[ Layout: Default ]]--

--------------------------------------------------------------------------------
return {

  Name = "Default",

  Layout = 
  [[QWERTYUIOP{}ASDFGHJKL:"ZXCVBNM<>?~qwertyuiop[]asdfghjkl;'zxcvbnm,./`\|!@#$%^&*()-=_+]]
--[[QWERTYUIOP{}ASDFGHJKL:"ZXCVBNM<>?~qwertyuiop[]asdfghjkl;'zxcvbnm,./`\|!@#$%^&*()-=_+]]

} ----
--------------------------------------------------------------------------------
