--[[ Morphs' generator ]]--

----------------------------------------
--[[ description:
  -- Morphs' generator.
  -- Генератор морфов.
--]]
----------------------------------------
--[[ uses:
  LuaFAR,
  far2,
  Rh Utils.
  -- group: Common.
  -- areas: any.
--]]
--------------------------------------------------------------------------------

local setmetatable = setmetatable

----------------------------------------
local bit = bit64
bshr = bit.rshift

----------------------------------------
local far = far
local F = far.Flags

----------------------------------------
--local context = context
local logShow = context.ShowInfo

local utils = require 'context.utils.useUtils'
local tables = require 'context.utils.useTables'
local datas = require 'context.utils.useDatas'
local locale = require 'context.utils.useLocale'
local serial = require 'context.utils.useSerial'

--local allpairs = tables.allpairs
local addNewData = tables.extend

----------------------------------------
--local farUt = require "Rh_Scripts.Utils.Utils"
--local chrUt = require "Rh_Scripts.Utils.Character"

--------------------------------------------------------------------------------
local unit = {}

---------------------------------------- Main data
unit.ScriptName = "MorfoGener"
unit.ScriptPath = "scripts\\Rh_Scripts\\Others\\"

---------------------------------------- ---- Custom
unit.DefCustom = {
  name = unit.ScriptName,
  path = unit.ScriptPath,

  label = unit.ScriptName,

  help   = { topic = unit.ScriptName, },
  locale = { kind = 'load', },
} --- DefCustom

unit.DefOptions = {
  KitName  = "LangData",
  --BaseDir  = nil,
  WorkDir  = "",

  AbecoName = "Abeco",
  MorfoName = "Morfo",

  ResultName = "Result",
  FileExt = "lud",
} ---

---------------------------------------- ---- Config
unit.DefCfgData = { -- Конфигурация по умолчанию:
  Enabled = true,
} --- DefCfgData

---------------------------------------- ---- Types
--unit.DlgTypes = { -- Типы элементов диалогов:
--} --- DlgTypes

---------------------------------------- Main class
local TMain = {
  --Guid       = win.Uuid(""),
  --ConfigGuid = win.Uuid(""),
}
local MMain = { __index = TMain }

local FullNameFmt = "%s%s.%s"

local function CreateMain (ArgData) --> (object)
  local self = {
    ArgData   = addNewData(ArgData, unit.DefCfgData),

    Custom    = false,
    Options   = false,
    History   = false,
    CfgData   = false,
    DlgTypes  = unit.DlgTypes,
    LocData   = false,

    -- Текущее состояние:
    Language  = {},
  } --- self

  self.ArgData.Custom = self.ArgData.Custom or {} -- MAYBE: addNewData with deep?!
  --logShow(self.ArgData, "ArgData")
  self.Custom = datas.customize(self.ArgData.Custom, unit.DefCustom)
  self.Options = addNewData(self.ArgData.Options, unit.DefOptions)

  self.History = datas.newHistory(self.Custom.history.full)
  self.CfgData = self.History:field(self.Custom.history.field)

  setmetatable(self.CfgData, { __index = self.ArgData })
  --logShow(self.CfgData, "CfgData")

  locale.customize(self.Custom)
  --logShow(self.Custom, "Custom")

  local Custom = self.Custom
  local Options = self.Options
  Options.FullDir = ("%s%s"):format(Custom.base, Custom.path)
  Options.AbecoFile = FullNameFmt:format(Options.FullDir,
                                         Options.AbecoName,
                                         Options.FileExt)
  Options.MorfoFile = FullNameFmt:format(Options.FullDir,
                                         Options.MorfoName,
                                         Options.FileExt)
  Options.ResultFile = FullNameFmt:format(Options.FullDir,
                                          Options.ResultName,
                                          Options.FileExt)
  --logShow(self.Options, "Options")

  return setmetatable(self, MMain)
end -- CreateMain

---------------------------------------- Dialog
do
  local dialog = require "far2.dialog"
  local dlgUt = require "Rh_Scripts.Utils.Dialog"

  local DI = dlgUt.DlgItemType
  local DIF = dlgUt.DlgItemFlag
  local ListItems = dlgUt.ListItems

function TMain:ConfigForm () --> (dialog)
  local DBox = self.DBox
  local isSmall = DBox.Flags and isFlag(DBox.Flags, F.FDLG_SMALLDIALOG)

  local I, J = isSmall and 0 or 3, isSmall and 0 or 1
  local H = DBox.Height - (isSmall and 1 or 2)
  local W = DBox.Width  - (isSmall and 0 or 2)
  local M = bshr(W, 1) -- Medium -- Width/2
  local Q = bshr(M, 1) -- Quarta -- Width/4
  W = W - 2 - (isSmall and 0 or 2)
  local A, B = I + 2, M + 2

  local L = self.L
  local D = dialog.NewDialog() -- Форма окна:
                    -- 1          2     3    4   5  6  7  8  9  10
                    -- Type      X1    Y1   X2  Y2  L  H  M  F  Data
  D._             = {DI.DBox,     I,    J, W+2,  H, 0, 0, 0, 0, L:caption"Dialog"}

  -- Кнопки управления:
  D.sep           = {DI.Text,     0,  H-2,   0,  0, 0, 0, 0, DIF.SeparLine, ""}
  D.chkEnabled    = {DI.Check,    A,  H-1,   M,  0, 0, 0, 0, 0, L:config"Enabled"}
  D.btnOk         = {DI.Button,   0,  H-1,   0,  0, 0, 0, 0, DIF.DefButton, L:defbtn"Ok"}
  D.btnCancel     = {DI.Button,   0,  H-1,   0,  0, 0, 0, 0, DIF.DlgButton, L:fmtbtn"Cancel"}

  return D
end -- ConfigForm

function TMain:ConfigBox ()

  local isSmall = self.Custom.isSmall
  if isSmall == nil then isSmall = true end

  -- Область:
  local DBox = {

    Width     = 0,
    Height    = 0,
    Flags     = isSmall and F.FDLG_SMALLDIALOG or nil,
  } -- DBox
  self.DBox = DBox

  DBox.Width  = 2 + 36*2 -- Edge + 2 columns
          -- Edge + (sep+Btns) + group separators and
  DBox.Height = 2 + 2 + 5*2 + -- group empty lines + group item lines
                0--DBox.cSlab + DBox.cFind + DBox.cSort + DBox.cList + DBox.cCmpl
  if not isSmall then
    DBox.Width, DBox.Height = DBox.Width + 4*2, DBox.Height + 1*2
  end

  return DBox
end ---- ConfigBox

function unit.ConfigDlg (Data)

  local _Main = CreateMain(Data)
  if not _Main then return end

  _Main:Localize() -- Локализация

  local DBox = _Main:ConfigBox()
  if not DBox then return end

  local HelpTopic = _Main.Custom.help.tlink

  local D = _Main:ConfigForm()
  dlgUt.LoadDlgData(_Main.CfgData, _Main.ArgData, D, _Main.DlgTypes)
  local iDlg = dlgUt.Dialog(_Main.ConfigGuid, -1, -1,
                            DBox.Width, DBox.Height, HelpTopic, D, DBox.Flags)
  --logShow(D, "D", 3)
  if D.btnOk and iDlg == D.btnOk.id then
    dlgUt.SaveDlgData(_Main.CfgData, _Main.ArgData, D, _Main.DlgTypes)
    --logShow(_Main, "Config", 3)
    _Main.History:save()

    return true
  end
end ---- ConfigDlg

end -- do
---------------------------------------- Main making

---------------------------------------- ---- Prepare
do
-- Localize data.
-- Локализация данных.
function TMain:Localize ()
  self.LocData = locale.getData(self.Custom)
  -- TODO: Нужно выдавать ошибку об отсутствии файла сообщений!!!
  if not self.LocData then return end

  self.L = locale.make(self.Custom, self.LocData)

  return self.L
end ---- Localize

end -- do

local Msgs = {
  NoLocale      = "No localization",
} ---

-- Подготовка.
-- Preparing.
function TMain:Prepare ()

  if not self:Localize() then
    --self.Error = Msgs.NoLocale
    return
  end

  return
end -- Prepare

---------------------------------------- ---- Work
do
  local tconcat = table.concat

-- Формирование данных в подтаблицах таблицы Language.
function TMain:FillSubDataPos (Kind) --| Abeco
  local a = self.Language.Abeco
  local aKind = a[Kind]
  --local aKind, aLiter = a[Kind], a.Liter
  if type(aKind) ~= 'table' or
     type(aKind[1]) ~= 'string' then
    return
  end

  -- Store positions of letters:
  local Len = 0 -- Max length of sounds
  for k = 1, #aKind do
    local v = aKind[k]
    aKind[v] = k
    local len = v:len()
    if len > Len then Len = len end
  end
  aKind[0] = Len
end ---- FillSubDataPos

local sformat = string.format

-- Формирование строк из подтаблиц таблицы Language.
function TMain:FillSubDataStr (Kind) --| Abeco
  local a = self.Language.Abeco
  local aOrder = a.Order
  local aKind = a[Kind]
  if type(aKind) ~= 'table' or
     type(aKind[1]) ~= 'string' then
    return
  end

  local oKind = aOrder[Kind]
  if not oKind then
    oKind = { Liter = true, YeuPat = true, NeuPat = true, }
    aOrder[Kind] = oKind
  end

  local Len = aKind[0]

  if Len == 1 then
    -- String of letters:
    oKind.Literi = tconcat(aKind)
    -- Patterns with letters:
    oKind.YeuPat = sformat("[%s]", oKind.Literi)
    oKind.NeuPat = sformat("[^%s]", oKind.Literi)
  else
    -- MAYBE:
    --[[
    local bKind = o.Binali[Kind]
    if bKind then
      --logShow(bKind, Kind)
      --logShow({ bKind, aOrder[bKind.kombo], aOrder.Vokon, }, Kind)
    end
    --]]
  end
end ---- FillSubDataStr

end -- do

-- Заполнение монофтонгов заданного вида.
function TMain:FillMonoSet (Kind) --| Abeco
  local a = self.Language.Abeco
  local aOrder = a.Order
  local aKind = a[Kind]
  
  local oKind = aOrder[Kind]
  for i = 1, #oKind do
    local iKind = oKind[i]
    local q = a[iKind]
    for j = 1, #q do
      aKind[#aKind + 1] = q[j]
    end

    self:FillSubDataPos(iKind)
    self:FillSubDataStr(iKind)
  end

  self:FillSubDataPos(Kind)
  self:FillSubDataStr(Kind)
end -- FillMonoSet

-- Формирование сочетаний с диграфными.
function TMain:FillBinoSets () --| Abeco
  local a = self.Language.Abeco
  local aOrder = a.Order

  for n, b in pairs(aOrder.Binali) do
    local aKind = a[n]
    local l = b.liter
    local f = b.flang

    if f == "R" then
      local q = a[b.kombo]
      for k = 1, #q do
        aKind[#aKind + 1] = q[k]..l
      end
    else--if f == "L" then
      local q = a[b.kombo]
      for k = 1, #q do
        aKind[#aKind + 1] = l..q[k]
      end
    end

    self:FillSubDataPos(n)
    self:FillSubDataStr(n)
  end --
end -- FillBinoSets

function TMain:FillTrinoSets() --| Abeco
  local a = self.Language.Abeco
  local aOrder = a.Order

  for n, b in pairs(aOrder.Trinali) do
    local aKind = a[n]
    local l = b.literL
    local r = b.literR
    --local f = b.flang

    local q = a[b.kombo]
    for k = 1, #q do
      aKind[#aKind + 1] = l..q[k]..r
    end

    self:FillSubDataPos(n)
    self:FillSubDataStr(n)
  end --
end -- FillTrinoSets

-- Заполнение букв.
function TMain:FillLiterSet (Kind) --| Abeco
  local a = self.Language.Abeco
  local aOrder = a.Order
  local aKind = a[Kind]

  local oKind = aOrder[Kind]
  for i = 1, #oKind do
    local iKind = oKind[i]
    local q = a[iKind]
    for j = 1, #q do
      aKind[#aKind + 1] = q[j]
    end
  end

  --self:FillSubDataPos(Kind)
  self:FillSubDataStr(Kind)
end -- FillLiterSet

-- Заполнение Language с учётом имеющихся в нём данных.
function TMain:FillData () --| Abeco

  --local a = self.Language.Abeco

  do -- Заполнение монофтонгов
    self:FillMonoSet("Vokal")
    self:FillMonoSet("Konal")
    self:FillMonoSet("Binal")

    self:FillMonoSet("Vokon")
    self:FillMonoSet("Liter")
  end -- do

  do -- Формирование мультифтонгов
    self:FillBinoSets()     -- Формирование дифтонгов
    -- TODO:
    --self:FillTrinoSets()    -- Формирование трифтонгов
  end -- do

  do -- Заполнение букв
    self:FillLiterSet("Vokali")
    self:FillLiterSet("Konali")
  end -- do

end ---- FillData

-- Генерация морфов.
function TMain:Generate ()

  --local D = self.Language
  --local a = D.Abeco
  --local m = D.Morfo
  --local F = D.Formo
  -- TODO
end ---- Generate

-- Формирование данных.
function TMain:Make () --> (table)

  self:FillData()

  return self:Generate()
end -- Make

---------------------------------------- ---- Load/Save
-- Загрузка.
function TMain:Load ()
  local Options = self.Options

  self.Language.Abeco = datas.load(Options.AbecoFile, nil, 'change')
  --logShow(self.Language.Abeco, "Abeco")
  --- TEMP: Exclude Morfo
  self.Language.Morfo = datas.load(Options.MorfoFile, nil, 'change')
  --logShow(self.Language.Morfo, "Morfo")
end ---- Load

-- Сохранение.
function TMain:Save ()
  local Options = self.Options

  local sortkind = {
    pairs = pairs, -- TEST: array + hash fields
    --pairs = allpairs, -- TEST: all fields including from metas
  } ---

  local kind = {
    --localret = true,
    --tnaming = true,
    astable = true,
    --nesting = 0,
    strlong = 80,

    pairs = tables.sortpairs, -- TEST: sort pairs
    pargs = { sortkind },

    -- Параметры линеаризации
    lining = "all",
    --lining = "array",
    --lining = "hash",

    alimit = 60,
    acount = 5,
    awidth = 4,
    --avalth = 4,
    --avarth = 4,

    zeroln = true,
    hstrln = true,

    hlimit = 60,
    hcount = 5,
    --hwidth = 6,
    hkeyth = 2,
    hvalth = 2,
    --[[ TEST: extended pretty write
    KeyToStr = serial.KeyToText,
    ValToStr = serial.ValToText,
    TabToStr = serial.TabToText,
    --]]
    serialize = serial.prettyize,
  } ---

  --logShow(self.Language, "Language", "d2")
  return datas.save(Options.ResultFile, "Data", self.Language, kind)
end ---- Save

---------------------------------------- ---- Run
function TMain:Run () --> (bool | nil)

  --logShow(self, "TMain")

  self:Load()

  self:Make()

  self:Save()

  --logShow(_Lang.Language, "w")

  return
end -- Run

---------------------------------------- main

function unit.Execute (Data) --> (bool | nil)

  --logShow(Data, "Data", "w d2")

  local _Main = CreateMain(Data)
  --logShow(_Main, "_Main")
  if not _Main then return end

  --logShow(Data, "Data", "w d2")
  --logShow(_Main, "Config", "w _d2")
  --logShow(_Main.CfgData, "CfgData", "w d2")
  --if not _Main.CfgData.Enabled then return end

  _Main:Prepare()
  if _Main.Error then return nil, _Main.Error end

  return _Main:Run()
end ---- Execute

--------------------------------------------------------------------------------
--return unit
return unit.Execute()
--------------------------------------------------------------------------------
