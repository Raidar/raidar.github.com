--[[ Chars: English ]]--

--------------------------------------------------------------------------------
local Data = {
  ----------------------------------------
  Caption       = "Characters map",
  BlocksCaption = "Character blocks",
  
  --
  InputCodePoint    = "Input code point",
  InputCharName     = "Input character name",
  BlocksColBlockRange   = "Range",
  BlocksColBlockName    = "Name",

  ----------------------------------------
} --- Data

return Data
--------------------------------------------------------------------------------
