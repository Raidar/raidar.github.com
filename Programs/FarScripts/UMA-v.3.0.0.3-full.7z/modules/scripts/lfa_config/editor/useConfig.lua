--[[ lfa_config ]]--

--------------------------------------------------------------------------------

local pairs = pairs
--local pairs, ipairs = pairs, ipairs
local tostring = tostring

----------------------------------------
local far, win = far, win
local F = far.Flags

local EditorGetInfo  = editor.GetInfo
local EditorSetParam = editor.SetParam

local GetFileInfo = win.GetFileInfo

----------------------------------------
local context, ctxdata = context, ctxdata

local utils = require 'context.utils.useUtils'

local editors = ctxdata.editors

--------------------------------------------------------------------------------
--[[ Терминология:
  margin - край области.
  marker - маркер (признак).
--]]
--------------------------------------------------------------------------------
local useConfig = context.use.lfa_config
local useEditor = useConfig.editor
local shared = useEditor.shared
local update = useEditor.update

-- 'common' type value from lfa_editor config.
local cfgEditor = ctxdata.config.lfa_editor
shared.cmnEditor = cfgEditor.common or {}

-- 'common' type value from lfa_vision config.
local cfgVision = ctxdata.config.lfa_vision
shared.cmnVision = cfgVision.common or {}

---------------------------------------- Making
local function getEditor (field)
  return shared.cmnEditor[field] or shared.curEditor[field]
end ----
local function getVision (field)
  return shared.cmnVision[field] or shared.curVision[field]
end ----

-- Сборка параметров линий.
function update.makeLineation ()
  local Info = shared.Info
  local TotalLines = Info.TotalLines

  do
    -- Если нет требуемого числа линий, не переоткрывать
    local LineationMin = getVision"LineationMin"
    local LineationMax = getVision"LineationMax"
    if LineationMin and TotalLines <  LineationMin or
       LineationMax and TotalLines >= LineationMax then
      return
    end
  end

  local mrgLeft = shared.MakeData.Margin.left
  mrgLeft.use = true

  local LineationLen = tostring(TotalLines):len() + 1
  mrgLeft.LineationReq = LineationLen
  LineationLen         = math.max(LineationLen, getVision"LeftMarginMin")
  mrgLeft.LineationLen = math.min(LineationLen, getVision"LeftMarginMax")

end ---- makeLineation

-- Сборка параметров полей.
function update.makeMargining ()
  local Data = shared.MakeData
  --local curConfigs = editors.current

  local Margin = {
    top    = {},
    left   = {},
    right  = {},
    bottom = {},
  } ---
  Data.Margin = Margin

  if getEditor"useLineation" then
    update.makeLineation() -- Линеация
  end
  if getEditor"useBookmarks" then
    update.makeBookmarks() -- Закладки
  end
end ----

-- Сборка основных данных.
function update.makeData ()
  --local Info = shared.Info
  local Data = {
    Area = {
      X1 = -1, Y1 = -1,
      X2 = -1, Y2 = -1,
      Line = -1, Pos = -1,
      --CodePage = F.CP_AUTODETECT,
    }, --
  } ---
  shared.MakeData = Data
  shared.curEditor = editors.current.lfa_editor
  shared.curVision = editors.current.lfa_vision

  local res = getEditor"useMargin"
  if res then
    makeMargining()
  end

  return res and Data
end ---- makeData

---------------------------------------- Tuning
--shared.isMessage = true

--[[
  local EditorFlags = {
    EF_NONMODAL = true,
    EF_IMMEDIATERETURN = true,
    EF_ENABLE_F6 = true,
  } ---
--]]

-- Настройка окна.
function update.Window ()
  local curConfigs = editors.current
  -- Если окно уже переоткрыто, то
  if shared.isReopen then
    -- Сохранить подготовленные данные.
    rawset(curConfigs, 'lfa_Data', shared.HomeData)
    -- Сброс для возможности открытия новых окон.
    shared.isReopen, shared.HomeData = nil, nil
    return true
  end

  local Info = shared.Info
  local FileName = Info.FileName
  if not GetFileInfo(FileName) then return true end

  do -- Если файл временный, то не переоткрывать.
    local TempDir = win.GetEnv('TEMP')
    if TempDir and FileName:find(TempDir, 1, true) then
      return true
      --[[ -- TODO: Unknown maxfile code:
      local pname = panel.GetCurrentPanelItem(nil, 1).FileName
      if FileName:match('([^/\\]+)$') == pname then
        FileName = pname
      else
        return true
      end
      --]]
    end
  end

  -- Подготовка данных.
  local Data = update.makeData()
  if not Data then return true end
  shared.isReopen = true
  shared.HomeData = Data
  shared.HomeType = curConfigs.type

  --far.Message("update.Window", "lfa_config")

  -- Отложенное закрытие окна редактора
  -- (исключение вылета FAR при быстром закрытии открываемого файла).
  far.Timer(1,
    function (h)
      if h.Closed then return end
      local Area = Data.Area
      h:Close()
      editor.Quit()
      far.AdvControl(F.ACTL_COMMIT)
      editor.Editor(FileName, nil,
                    Area.X1, Area.Y1,
                    Area.X2, Area.Y2,
                    EditorFlags,
                    Area.Line, Area.Pos,
                    nil)
    end)
  return 'exit'
end ---- Window

---------------------------------------- Getting
-- Получение значения.
update.getParamValue = utils.b2n

-- Получение разделителей слов.
function update.getWordSeps (separators)
  local s = separators.value or ''
  if s == '' then
    local res
    res, s = EditorSetParam(nil, F.ESPT_GETWORDDIV)
    s = s or ''
  end

  if s ~= '' and separators.del then
    s = s:gsub(separators.del, '')
  end
  if separators.add then
    return s..separators.add
  end
  return s
end ---- getWordSeps

-- Получение кодовой страницы.
do
  local cpNames = {
    utf7         = 65000,
    ['utf-7']    = 65000,
    utf8         = 65001,
    ['utf-8']    = 65001,

    utf16le      =  1200,
    ['utf-16le'] =  1200,
    utf16be      =  1201,
    ['utf-16be'] =  1201,

    dos          =   866,
    ansi         =  1251,
    win1251      =  1251,
    windows1251  =  1251,
    ['koi8-r']   = 20866,
    koi8r        = 20866,
    ['7bit']     = 20127,
  } --- cpNames

  local cpOEM, cpANSI = win.GetOEMCP(), win.GetACP()

function update.getCodePage (Value) --> (number)
  local Info = shared.Info
  if not Value or GetFileInfo(Info.FileName) then return end
  --if Info.CodePage ~= shared.defaultCodePage then return end
  if Info.CodePage ~= cpOEM and
     Info.CodePage ~= cpANSI then
    return
  end

  local tp = type(Value)
  return tp == 'number' and Value or
         tp == 'string' and cpNames[Value:lower()]
end --

end -- do

-- Получение признака сигнатуры BOM.
do
  local cpBOMed = {
    [65000] = true,
    [65001] = true,
    [1200]  = true,
    [1201]  = true,
  } --- cpBOMed

function update.getBOM (Value) --> (0 | 1)
  local Info = shared.Info
  return not GetFileInfo(Info.FileName) and
         cpBOMed[Info.CodePage] and update.getParamValue(Value)
end --

end -- do

---------------------------------------- Parameters
local vCharCodeBases = {
  oct = 0,
  dec = 1,
  hex = 2,
} ---
local vExpandTabs = {
  no  = F.EXPAND_NOTABS,
  all = F.EXPAND_ALLTABS,
  new = F.EXPAND_NEWTABS,
} ---

local Parameters = {
  { name = 'Quit',            command = editor.Quit,          exit = true },
  { name = 'ShowMargin',      command = update.Window },
  { name = 'Lock',            flag = F.ESPT_LOCKMODE,         value = update.getParamValue },
  { name = 'AutoIndent',      flag = F.ESPT_AUTOINDENT,       value = update.getParamValue },
  { name = 'CodePage',        flag = F.ESPT_CODEPAGE,         value = update.getCodePage, updateInfo = true },
  { name = 'SetBom',          flag = F.ESPT_SETBOM,           value = update.getBOM },
  { name = 'CursorBeyondEOL', flag = F.ESPT_CURSORBEYONDEOL,  value = update.getParamValue },
  { name = 'CharCodeBase',    flag = F.ESPT_CHARCODEBASE,     value = vCharCodeBases },
  { name = 'SavePosition',    flag = F.ESPT_SAVEFILEPOSITION, value = update.getParamValue },
  { name = 'ShowWhiteSpace',  flag = F.ESPT_SHOWWHITESPACE,   value = update.getParamValue },
  { name = 'WordSeparators',  flag = F.ESPT_SETWORDDIV,       value = update.getWordSeps },
  { name = 'TabSize',         flag = F.ESPT_TABSIZE },
  { name = 'ExpandTabs',      flag = F.ESPT_EXPANDTABS,       value = vExpandTabs },
} ---                                     

-- Обработка "значений"-таблиц как функций получения значения.
do
  local sUnknownFieldError = 'Unknown field "%s"'

  -- Работа с таблицей как функцией.
  local function tcall (t, a)
    return t[a]
  end
  -- Обработка незаданного поля.
  local function tindex (t, k)
    far.Message(sUnknownFieldError:format(tostring(k)))
  end

  local value_mt = { __call = tcall, __index = tindex }

  for _, v in pairs(Parameters) do
    if type(v.value) == 'table' then
      setmetatable(v.value, value_mt)
    end
  end
end -- do

do
  --local cpOEM, cpANSI = win.GetOEMCP(), win.GetACP()

  local warn = 'Failed to set value "%s" for parameter "%s"'
  local set = "%16.16s -> %30.30s"
  local sParamUpdateFmt = "Update parameters for type '%s':\n"

-- Установка параметров окна.
function update.Parameters ()
  local curConfigs = ctxdata.editors.current
  if shared.HomeType then
    curConfigs.type = shared.HomeType
  end
  shared.repeatType = nil

  local curEditor = curConfigs.lfa_editor
  if not curEditor then return end

  shared.Info = EditorGetInfo()

  --local opts = {}
  --shared.defaultCodePage = win.GetRegKey('HKCU', 'Editor','AnsiCodePageForNewFile') == 1 and cpANSI or cpOEM

  local message = shared.isMessage and
                  { sParamUpdateFmt:format(curConfigs.type) } --or nil

  for k = 1, #Parameters do
    local v = Parameters[k]
    local param = curEditor[v.name]
    if param ~= nil then
      local value = v.value and v.value(param) or not v.value and param
      if value then
        if message then
          table.insert( message, set:format(v.name, tostring(param)) )
        end

        local res = (v.command or EditorSetParam)(nil, v.flag, value)
        if not res then
          far.Message( warn:format(tostring(param), v.name), "Error", nil, 'w' )
          if message then table.insert( message, " (FAILED)" ) end
        elseif v.exit or res == 'exit' then
          return
        end

        if v.updateInfo then shared.Info = EditorGetInfo() end
        if message then table.insert( message, '\n' ) end
      end
    end
  end

  if message then
    far.Message(table.concat(message), 'Update editor parameters')
  end
end -- Parameters

end -- do
--------------------------------------------------------------------------------
