--[[ lfa_config ]]--

--------------------------------------------------------------------------------

local pairs, ipairs = pairs, ipairs
local tostring = tostring

----------------------------------------
local context, ctxdata = context, ctxdata

local editors = ctxdata.editors

----------------------------------------
local far = far
local F = far.Flags

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local lfa_config = context.use.lfa_config

local editinfo
local maincfg = ctxdata.config.lfa_common
local oemCP, ansiCP, defaultStartCodePage = win.GetOEMCP(), win.GetACP()

local repeatType, repeatVerbose, globalVerbose

local function bool (a) --> (number)
  return a and 1 or 0
end

local EditorFlags = {
  EF_NONMODAL = true,
  EF_IMMEDIATERETURN = true,
  EF_ENABLE_F6 = true,
} ---

function lfa_config.showLineNumbers ()
  if lfa_config.showLineNumbersActs then
    rawset(editors.current, 'drawNumbers', lfa_config.showLineNumbersParams)
    lfa_config.showLineNumbersParams = nil
    lfa_config.showLineNumbersActs = nil
    return true
  end

  local fname = editinfo.FileName
  if not win.GetFileInfo(fname) then return true end

  local temp = win.GetEnv'TEMP'
  if temp and fname:find(temp, 1, true) then
    --local pname = panel.GetCurrentPanelItem(nil, 1).FileName
    --if fname:match('([^/\\]+)$')==pname then
        --fname=pname
    --else
        return true
    --end
  end

  local tlines = editinfo.TotalLines
  if maincfg.LinePanelLinesLimit and
    tlines > maincfg.LinePanelLinesLimit then
    return true
  end

  local dn = lfa_config.drawLineNumbersInit(tlines)
  if not dn then return true end

  lfa_config.showLineNumbersActs = true
  repeatType = editors.current.type
  repeatVerbose = globalVerbose
  lfa_config.showLineNumbersParams = dn

  --far.Message("showLineNumbers", "lfa_config")

  far.Timer(1,
    function(h)
      if h.Closed then return end
      h:Close()
      editor.Quit()
      far.AdvControl(F.ACTL_COMMIT)
      editor.Editor(fname, nil, dn.width, -1, -1, -1, EditorFlags, -1, -1)
    end)

  return 'exit'
end ---- showLineNumbers

local function addWordDiv (a)
  local _, wd = editor.SetParam(nil, F.ESPT_GETWORDDIV)
  return (wd or '')..a
end --

local function removeWordDiv (a)
  local _, wd = editor.SetParam(nil, F.ESPT_GETWORDDIV)
  if not wd or wd == '' then return wd end

  for i, v in ipairs(a) do
    wd = wd:gsub(v, '')
  end
  return wd
end --

local codepageMask = {
  utf8         = 65001,
  ['utf-8']    = 65001,
  utf7         = 65000,
  ['utf-7']    = 65000,
  utf16le      =  1200,
  ['utf-16le'] =  1200,
  utf16be      =  1201,
  ['utf-16be'] =  1201,
  dos          =   866,
  ansi         =  1251,
  windows1251  =  1251,
  ['koi8-r']   = 20866,
  koi8r        = 20866,
  ['7bit']     = 20127,
} ---

local function setCodePage (a)
  if not a or win.GetFileInfo(editinfo.FileName) then return end
  if editinfo.CodePage ~= defaultStartCodePage then return end

  local tpa = type(a)
  return tpa == 'number' and a or
         tpa == 'string' and codepageMask[a:lower()]
end --

local supportBom = {
    [65000] = true,
    [65001] = true,
    [1200] = true,
    [1201] = true,
} ---

local function setBom (a)
  return not win.GetFileInfo(editor.GetFileName()) and
         supportBom[editinfo.CodePage] and bool(a) or nil
end --

local parameters = {
  { name = 'Quit',            command  = editor.Quit,              exit = true },
  { name = 'ShowMargin',      command  = lfa_config.showLineNumbers },
  { name = 'Lock',            parameter = F.ESPT_LOCKMODE,         mask = bool },
  { name = 'AutoIndent',      parameter = F.ESPT_AUTOINDENT,       mask = bool },
  { name = 'CodePage',        parameter = F.ESPT_CODEPAGE,         mask = setCodePage, updateInfo = true},
  { name = 'SetBom',          parameter = F.ESPT_SETBOM,           mask = setBom },
  { name = 'CursorBeyondEOL', parameter = F.ESPT_CURSORBEYONDEOL,  mask = bool },
  { name = 'CharCodeBase',    parameter = F.ESPT_CHARCODEBASE,     mask = { oct = 0, dec = 1, hex = 2 } },
  { name = 'SavePosition',    parameter = F.ESPT_SAVEFILEPOSITION, mask = bool },
  { name = 'ShowWhiteSpace',  parameter = F.ESPT_SHOWWHITESPACE,   mask = bool },
  { name = 'WordDiv',         parameter = F.ESPT_SETWORDDIV },
  { name = 'RemoveWordDiv',   parameter = F.ESPT_SETWORDDIV,       mask = removeWordDiv },
  { name = 'AddWordDiv',      parameter = F.ESPT_SETWORDDIV,       mask = addWordDiv },
  { name = 'TabSize',         parameter = F.ESPT_TABSIZE },
  { name = 'ExpandTabs',      parameter = F.ESPT_EXPANDTABS,
    mask = { no = F.EXPAND_NOTABS, all = F.EXPAND_ALLTABS, new = F.EXPAND_NEWTABS } },
} ---                                     

local function tcall (t, a)
  return t[a]
end

for _, v in pairs(parameters) do
  if type(v.mask) == 'table' then
    --add __call to metatable to use in a same way as function
    --add __index to metatable to make an errormessage
    local function tindex (t, k)
      far.Message(('Abnormal parameter value "%s" for "%s"'):format(tostring(k), v.name))
    end
    setmetatable(v.mask, { __call = tcall, __index = tindex })
  end
end

local warn = 'Failed to set value "%s" for parameter "%s"'
local set = "%16.16s -> %30.30s"
local settype = "Set parameters for type '%s':\n"

function lfa_config.setEditorParameters (verbose)
  local currented = ctxdata.editors.current
  --logShow(currented)
  globalVerbose = verbose
  local verbose = repeatVerbose or verbose
  if repeatType then
    currented.type = repeatType
  end
  repeatVerbose, repeatType = nil, nil

  --logShow(getmetatable(currented))
  local editorConfig = currented.lfa_editor
  if not editorConfig then return end

  editinfo = editor.GetInfo()

  --local opts = {}
  defaultStartCodePage = win.GetRegKey('HKCU', 'Editor', 'AnsiCodePageForNewFile') == 1 and ansiCP or oemCP

  local message = verbose and { settype:format(currented.type) } or nil

  for _, v in ipairs(parameters) do
    local param = editorConfig[v.name]
    if param ~= nil then
      local value = v.mask and v.mask(param) or not v.mask and param
      if value then
        if message then
          table.insert(message, set:format(v.name, tostring(param)))
        end

        local res = (v.command or editor.SetParam)(nil, v.parameter, value)
        if not res then
          far.Message(warn:format(tostring(param), v.name), "Error", nil, 'w')
          if message then table.insert(message, " (FAILED)") end
        elseif v.exit or res == 'exit' then
          return
        end

        if v.updateInfo then editinfo = editor.GetInfo() end
        if message then table.insert(message, '\n') end
      end
    end
  end
  if message then
    far.Message(table.concat(message), 'Set editor parameters')
  end
end ---- setEditorParameters
--------------------------------------------------------------------------------
