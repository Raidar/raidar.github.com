--[[ lfa_config ]]--

----------------------------------------
--[[ description:
  -- Editor vision configuration.
  -- Конфигурация вида редактора.
--]]
----------------------------------------
--[[ uses:
  nil.
  -- group: Config, Datas.
--]]
--------------------------------------------------------------------------------
--[=[
Options:
    ShowBookmarks = true,               -- show bookmarks (true/false)
    EmphInterval = 10,                  -- line emphasize interval (number)
    BookmarkText = 'b: $bm',            -- show bookmarks text instead of the line number (string)
                                        -- $line - line number
                                        -- $bm - bookmark number
    Color = 'white on blue',            -- margin color (color string or number)
    EmphColor = 'white on blue',        -- margin color (color string or number)
    BookmarkColor = 'white on red',     -- bokmarks color (color string or number)
    FillColor = 'white on cyan',        -- color for the region of keybar and statusbar (color string or number)

    ShowRightMargin = true,             -- show right margin (true/false)
    RighMarginPos = 81,                 -- right margin position (number)
                                        -- right margin is drawn right after this position.
    RightMarginColor = 'black on gray', -- right margin color (color string or number)
    TextCoversMargin = false,           -- if true then right margin is not drawn over the text (true/false)

    ShowEndOfLine    = false,           -- highlight end of line (true/false)
    ShowEndOfFile    = true,            -- highlight end of file (true/false)
    ShowLastLine     = true,            -- highlight last line (true/false)
    ShowLastMargin   = false,           -- if true, highlight last line from the last pos to the right margin (true/false)
                                        -- if false, highlight only one symbol after the last line
    EndOfLineColor   = 'black on white',-- EOL color (color string or number)
    EndOfFileColor   = 'black on red',  -- EOF color (color string or number)
    LastLineColor    = 'black on blue', -- last line color (color string or number)
    LastMarginColor  = 'black on cyan', -- last margin color (color string or number)
]=]

--------------------------------------------------------------------------------
local cfg = {

  default = {
    --ShowLineNumbers = false,
    ShowLineNumbers = true,
    --ShowBookmarks = false,
    ShowBookmarks = true,
    EmphInterval = 10,

    BookmarkText = '> $bm',
    --BookmarkText = '$line ($bm)',

    Color         = 'gray on black',
    EmphColor     = 'silver on black',
    FillColor     = 'silver on cyan',
    BookmarkColor = 'magenta on black',
    --BookmarkColor = 'land on black',

    ShowRightMargin   = true,
    RightMarginPos    = 80,
    TextCoversMargin  = true,
    RightMarginColor  = 'silver on black',

    --ShowEndOfLine     = true,
    ShowEndOfLine     = false,
    ShowEndOfFile     = true,
    --ShowLastLine      = true,
    ShowLastLine      = false,
    ShowLastMargin    = true,

    --EndOfLineColor    = 'silver on land',
    EndOfLineColor    = 'silver on black',
    EndOfFileColor    = 'silver on maroon',
    LastLineColor     = 'silver on black',
    LastMarginColor   = 'silver on black',
  }, --

  none = { inherit = 'default' },

  common = {
    -- Поля области редактора:
    LeftMarginMin   = 3,       -- Мин. длина левого поля
    LeftMarginMax   = 6,       -- Макс. длина левого поля
    -- Линеация - нумерация линий файла:
    LineationMin    = 0,       -- Мин. число линий файла
    LineationMax    = 10000,   -- Макс. число линий файла
  },

  --text = {},

  plain = {},

  sub_assa = {
    RightMarginPos = 100,
  },

  --source = {
    --Color     = 'gray on blue',
    --EmphColor = 'white on blue',
  --},

  pascal = {},

  fortran = {
    RightMarginPos = 73,
  },

  packed = {
    ShowRightMargin = false,

    ShowEndOfLine   = false,
    ShowEndOfFile   = false,
    ShowLastLine    = false,
    ShowLastMargin  = false,
  },

  mixed = {
    ShowRightMargin = false,

    ShowEndOfLine   = false,
    ShowEndOfFile   = false,
    ShowLastLine    = false,
    ShowLastMargin  = false,
  },
} --- cfg

return cfg
--------------------------------------------------------------------------------
