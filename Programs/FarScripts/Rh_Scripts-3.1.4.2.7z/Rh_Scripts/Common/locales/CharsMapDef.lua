--[[ Chars: English ]]--

--------------------------------------------------------------------------------
local Data = {
  ----------------------------------------
  Caption       = "Characters map",
  NomensCaption = "Characters",
  BlocksCaption = "Character blocks",
  
  --
  InputCodePoint    = "Input code point",
  InputCharName     = "Input character name",
  NomensColBlockName    = "Name",
  BlocksColBlockRange   = "Range",
  BlocksColBlockName    = "Name",

  ----------------------------------------
} --- Data

return Data
--------------------------------------------------------------------------------
