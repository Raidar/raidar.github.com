//@@ filename=editor.GetInfo().FileName:match('.+[/\\]([^%.]+)')
void @@return filename@@(){


}
