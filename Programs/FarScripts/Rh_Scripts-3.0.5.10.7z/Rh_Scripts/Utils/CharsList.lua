--[[ Characters' list ]]--

----------------------------------------
--[[ description:
  -- Unicode characters' list.
  -- Список Unicode‑символов.
--]]
----------------------------------------
--[[ uses:
  LuaFAR.
  -- group: Utils.
--]]
--------------------------------------------------------------------------------

local tonumber = tonumber
local setmetatable = setmetatable

local io_open = io.open

----------------------------------------
--local context = context
local logShow = context.ShowInfo

local utils = require 'context.utils.useUtils'
local strings = require 'context.utils.useStrings'

local capital = strings.capital

--------------------------------------------------------------------------------
local unit = {}

----------------------------------------
local Names = {} -- Таблица-список названий
unit.Names = Names

-- Make and return subtable for t[k].
local function subTable (t, k) --> (table)
  local u = {
    code = "0000",
    name = "",
  } ---
  t[k] = u
  return u
end
Names.__index = subTable; setmetatable(Names, Names)

----------------------------------------
local PluginPath = utils.PluginPath
local DataPath = "scripts\\Rh_Scripts\\data\\"
local DataName = "NamesList.txt"

---------------------------------------- main
do
  local FileName = string.format("%s%s%s", PluginPath, DataPath, DataName)

  local f = io_open(FileName, 'r')
  if f == nil then return unit end
  --[[
  local f, SError = io_open(FileName, 'r')
  if SError then logShow(SError, "NamesList.txt") end
  --]]

  -- Цикл по строкам файла:

  local last, data = 0, 0

  local s = "@"
  --local sn = 0
  repeat
    --logShow(s, "File line")
    -- Пропуск комментариев, доп. информации и старых названий:
    while s and (s:find("^%@") or
          s:find("^\t[^%=]") or
          s:find("^\t%= .+%(1%.0%)$")) do
      --logShow(s, "File unused line")
      s = f:read('*l')
      --sn = sn + 1
    end
    if s == nil then break end -- Конец файла
    --if sn > 40 then break end -- DEBUG only
    --logShow(s, "File used line")

    -- TODO: Check codepoint ranges!!
    -- Основное название:
    local code, name = s:match("^(%x%x%x%x)\t(.+)$")
    if code then
      --logShow(code, name)
      local cp = tonumber(code, 16)
      --if cp > 0x300 then break end -- DEBUG only
      --if cp > 0xFFFF then break end -- DEBUG only
      last, data = cp, Names[cp]
      data.code = code
      data.name = name:sub(1, 1) == '<' and name or capital(name)
    end

    --[[
    name = s:match("^\t%= (.+)")
    -- Альтернативное название:
    if name then
      data = Names[last]
      if not data.alias then data.alias = {} end
      data.alias[#data.alias+1] = name
    end --
    --]]

    s = f:read('*l')
    --sn = sn + 1
  until s == nil

  f:close()
end -- do

--logShow(Names, "Char Names", 2)

--------------------------------------------------------------------------------
return unit
--------------------------------------------------------------------------------
