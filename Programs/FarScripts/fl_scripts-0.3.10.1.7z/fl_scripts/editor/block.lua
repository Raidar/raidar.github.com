local farselection=require 'fl_scripts/utils/block_iterator'

function jumptoblockbegin()
    for _,str in farselection() do
        far.EditorSetPosition({CurPos=str.SelStart})
        break
    end
end

function jumptoblockend()
    local str,line
    for _,str1 in farselection() do
        line,str=_,str1
    end
    if not line then return end
    far.EditorSetPosition({CurLine=line, CurPos=str.SelEnd})
    far.EditorRedraw()
end

local call=(...)[1]
if call then
    setfenv(loadstring(call), getfenv(1))()
    return
end
