
local FK = require'farkeys'
---------------------------------------------------------------------
-- Sets position to the first nonspace character
function smarthome()
    local p = far.EditorGetInfo().CurPos
    local p_S = (far.EditorGetString(-1,2):find('%S') or 1) -1
    far.EditorSetPosition(nil,(p==0 or p>p_S) and p_S or 0)
    far.EditorRedraw()
end

--------------------------------------------------------------------
--
local function find_nearest_space_right(line,pos,down)
   local newpos=nil
   for i=1,10 do
       if down and line<down then return nil end
       line = line - (down and -1 or 1)
       local str=far.EditorGetString(line,2)
       if str and str~='' then
           local pp,spos=str:find('%s%s+%S',pos)
           if spos then
               if not newpos or newpos>spos then
                   newpos = spos
                   return newpos-1
               end
           end
       end
   end
   return newpos and (newpos-1) or nil
end

-----------------------------------------------------------------------
----
--function smartbs()
--    local einfo = far.EditorGetInfo()
--    local l,p = einfo.CurLine, einfo.CurPos
--    local str = far.EditorGetString(-1,1).StringText
--    str=str:sub(1,p)
--    if not str:sub(p-1,p):find('^%s%s+$') then far.EditorProcessKey(FK.KEY_BS) end
--    local spaces=str:match('%s+$')
--    local nspaces=#spaces
--    local n=nil
--    for i=1,10 do
--        line=line-1
--        local str=far.EditorGetString(line,2):sub(p-nspaces,p)
--
--    end
--
----    far.Message(n)
----    einfo.CurPos = einfo.CurPos-n
--    --far.EditorSetPosition(einfo)
----    local n=1
----    for i=1,n do far.EditorProcessKey(FK.KEY_BS) end
--    far.EditorRedraw()
--end

---------------------------------------------------------------------
--
function smarttab()
    local einfo = far.EditorGetInfo()
    local l,p = einfo.CurLine,einfo.CurPos
    local spos = find_nearest_space_right(l,p)  -- einfo.TotalLines
    far.EditorSetPosition(einfo)
    local tab=spos and (spos-p) or einfo.TabSize
    far.EditorInsertText( string.format('%'..tostring( tab )..'s',''))
    far.EditorRedraw()
end

local call=(...)[1]
if call then
    setfenv(loadstring(call), getfenv(1))()
    return
end
