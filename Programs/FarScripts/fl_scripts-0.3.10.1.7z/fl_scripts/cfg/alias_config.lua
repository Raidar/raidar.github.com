
return {
         farhome = 'cd %farhome%',
         farlua = 'cd %farhome%/plugins/luafareditor/scripts',
         ['~config'] = 'edit:%farhome%/plugins/luafareditor/scripts/fl_scripts/config_user/alias_config.lua '
}