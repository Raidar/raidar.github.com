
return { LuaFarHotKey='' }
