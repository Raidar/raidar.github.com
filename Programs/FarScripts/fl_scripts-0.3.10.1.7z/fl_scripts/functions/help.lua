
help['sin(x)']='Calculate sine of x'
help['cos(x)']='Calculate cosine of x'
