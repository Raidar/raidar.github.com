//@@ filename=far.EditorGetInfo().FileName:match('.+[/\\]([^%.]+)')
void @@return filename@@(){


}
