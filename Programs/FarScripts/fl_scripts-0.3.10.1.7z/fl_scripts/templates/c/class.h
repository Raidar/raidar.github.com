//@@ filename=far.EditorGetInfo().FileName:match('.+[/\\]([^%.]+)')
//@@ classname=filename:lower()
#ifndef __@@return filename:upper()@@__
#define __@@return filename:upper()@@__
class @@return filename@@
{
public:
    @@return filename@@();
   ~@@return filename@@();

    @@here()@@
private:

};

#endif
