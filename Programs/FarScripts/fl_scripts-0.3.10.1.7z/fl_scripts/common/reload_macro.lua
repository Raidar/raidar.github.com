local function reload_macro()
    local res=far.AdvControl('ACTL_KEYMACRO',{Command='MCMD_LOADALL',Flags={}})
    far.Message(res==1 and 'ok' or 'Error reloading macros','Reload macro',nil,res==1 and '' or 'w')
end

reload_macro()