--TODO: use FileFilters

local pluginDir = far.PluginStartupInfo().ModuleName:match(".+\\")
local helpTopic = "<" .. pluginDir .. [[scripts\fl_scripts\doc\>panelfilter]]
local far2dialog=require 'far2.dialog'
local disable_output = { KSFLAGS_DISABLEOUTPUT = 1 } -- FAR2
--local disable_output = { KMFLAGS_DISABLEOUTPUT = 1 } -- FAR3

context.config.register{key='flpanelfilter', inherit=false, path='fl_scripts', name='panelfilter'}
local conf = ctxdata.config.flpanelfilter
local hotkey=conf and conf.LuaFarHotKey or ''
local flags=far.GetFlags()

filter, delete_filter = 0, 0

local redirect_keys = { 'Up', 'Down', 'Ins', 'PgUp', 'PgDn' }
local redir={}
for i, v in ipairs( redirect_keys ) do
    redir[far.FarNameToKey(v)]=v
end
redirect_keys=redir

if not rawget(_G,'my_memory') then
   _G.my_memory={}
end
local mem =_G.my_memory

local items = far2dialog.NewDialog()
items.calc     = { 'DI_EDIT',         0,0,20,0,     1,0,0,1,                     '' }

-- call filter dialog, open or create _luafilter_, goto filter
local fil_1=([[
    CtrlI
    %%pos=Menu.Select("_luafilter_",1);
    $If (%%pos<0)
        $Exit
    $Else
        $If ( %%pos==0 )
            Ins
            CtrlY
            $Text "_luafilter_"
            Down Down Down Down Down Down Down Down Down Down Space Space
            Up Up Up Up Up Up Up Up
        $Else
            F4
            Down Down
        $End
    $End
    CtrlY
]])

-- after filling filter, close dialog, turn on, call plugin again
local fil_3=([[
    Enter
    BS Up +
    Enter
    F11
    $If ( checkhotkey("%s") )
        %s
    $Else
        msgbox("Error", "LuaFar hotkey not set")
        $Exit
    $End
    : End
]]):format(hotkey, hotkey)

local delfilter=([[
CtrlI
$if( Menu.Select("_luafilter_",1)>0 )
    Del
    Enter
$End
Esc
]])

local macro={ Command='MCMD_POSTMACROSTRING', Flags=disable_output }
local function call_macro(str)
    macro.SequenceText=str
    far.AdvControl('ACTL_KEYMACRO', macro)
end

local function filter_macro(str, key)
    call_macro 'Enter'
    if key then call_macro(key) end
    call_macro(fil_1)
    call_macro('$Text "*'..str..'*"')
    call_macro(fil_3)
end

local function dlg_handler(handle, msg, p1, p2)
    if msg==flags.DN_EDITCHANGE then
        local cur_item=items[p1+1]
        cur_item[10] = far.GetDlgItem(handle,p1,nil)[10]
        mem.panelfilter=cur_item[10]
        return filter_macro(cur_item[10])
    -- FAR3: p2 = InputRecord!
    elseif msg==flags.DN_KEY and far.FarKeyToName(p2)=='Esc' then
        delete_filter()
    elseif msg==flags.DN_KEY then
        if redirect_keys[p2] then
            return filter_macro(items[p1+1][10], redirect_keys[p2])
        end
    end
end

filter = function ()
    items.calc[10]=mem.panelfilter or ''
    local rect=far.CtrlGetPanelInfo(-1, 1).PanelRect
    items.calc[4]=rect.right-rect.left-2
    far.Dialog( rect.left+1, rect.top+1, rect.right-1, rect.top+1, helpTopic, items, { FDLG_SMALLDIALOG=1, FDLG_NODRAWSHADOW=1, FDLG_NODRAWPANEL=1 }, dlg_handler ) -- FAR3: GUID
end

delete_filter = function ()
    far.AdvControl('ACTL_KEYMACRO',{ Command='MCMD_POSTMACROSTRING',
                                     Flags=disable_output,
                                     SequenceText=delfilter })
end

local call=(...)[1]
if call then
    if hotkey ~= "" then
        setfenv(loadstring(call), getfenv(1))()
    else
        far.Message("LuaFar hotkey not set\n(press F1 for help)",
                    "Panel filter", ";Ok", "w", helpTopic)
    end
    return
end
