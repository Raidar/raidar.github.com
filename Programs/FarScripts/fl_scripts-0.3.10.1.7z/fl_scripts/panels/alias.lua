context.config.register{key='flalias', path='fl_scripts', name='alias'}
local config = ctxdata.config

local disable_output = { KSFLAGS_DISABLEOUTPUT = 1 } -- FAR2
--local disable_output = { KMFLAGS_DISABLEOUTPUT = 1 } -- FAR3

local function run_alias()
    local cmdline=far.CtrlGetCmdLine(-1)
    local alias=config.flalias[cmdline]
    if not alias then return end
    far.CtrlSetCmdLine(-1, alias)
    return far.AdvControl("ACTL_KEYMACRO", {
                          Command = "MCMD_POSTMACROSTRING",
                          SequenceText = "Enter",
                          Flags = disable_output })
end

run_alias()
