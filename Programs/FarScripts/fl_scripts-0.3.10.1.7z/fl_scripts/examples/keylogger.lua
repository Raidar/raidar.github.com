local far2dialog=require 'far2.dialog'

local flags=far.GetFlags()
local width=80

local items = far2dialog.NewDialog()
items._        = { "DI_DOUBLEBOX",    3,1, width+6 ,5,    0,0,0,0,                     "Key logger" }
items.dec      = { "DI_TEXT",         4,3,0,3,    0,0,0,0,                     ''          }

local str=''
local function dlg_handler(handle,msg,p1,p2)
    if msg==flags.DN_KEY then
        local key=far.FarKeyToName(p2) -- FAR3: p2 = InputRecord!
        str=str..' '..key
        items.dec[10]=str:sub(-width)
        far.SetDlgItem(handle, 1, items.dec)

        if key=='Esc' then far.SendDlgMessage(handle, flags.DM_CLOSE, p2) end
    end
end

local function keylogger()
    far.Dialog( 2,5, 2+width+8,11, nil, items, 0, dlg_handler ) -- FAR3: GUID
end

keylogger()
