﻿--[[ Lua Hunspell ]]--

----------------------------------------
--[[ description:
  -- Spell checking based on Hunspell.
  -- Проверка орфографии на основе Hunspell.
--]]
----------------------------------------
--[[ uses:
  LuaFAR, LuaMacro.
  -- areas: editor.
--]]
----------------------------------------
--[[ based on:
  spell.lua
  (Макрос для проверки орфографии в редакторе.)
  (Searchable Menu.)
  (c) 2013+, zg.
  URL: http://forum.farmanager.com/viewtopic.php?f=60&t=8089&hilit=LuaSpell
--]]
----------------------------------------
--[[ required:
  1. Библиотека dll из проекта luapower (http://luapower.com/)
     URL: http://luapower.com/hunspell
     Отсюда берётся архив с последней версией. Из него нужна
     либо \bin\mingw32\hunspell.dll, либо bin\mingw64\hunspell.dll .
     Положить её в каталог общих dll, например, в каталог FAR Manager,
     добавив к названию x86 или x64 в соответствии с версией программы.
  2. Словари.
     Словари ожидаются в каталоге ~%FARPROFILE%\Dictionaries~.
     Все файлы словарей должны быть в кодировке UTF-8 без BOM,
     в первой строке aff-файлов нужно прописать "SET UTF-8" (без кавычек).
     По умолчанию макрос настроен на словари
     ru_RU_yo и en_US (нужны файлы aff и dic).
  3. Конфигурация:
     файл конфигурации макроса - ~%FARPROFILE%\data\macros\LuaSpell.cfg~.
--]]
--------------------------------------------------------------------------------

----------------------------------------
local regex = regex

local F = far.Flags
local Flag4BIT = bit64.bor(F.FCF_FG_4BIT, F.FCF_BG_4BIT)

local EditorGetInfo = editor.GetInfo
local EditorGetLine = editor.GetString
local EditorSetLine = editor.SetString

--------------------------------------------------------------------------------
--local unit = {}

---------------------------------------- Main data
local ScriptName = "LuaSpell"
--unit.ScriptName = "LuaSpell"

---------------------------------------- utils
local function ExpandEnv (s)
  return s:gsub("%%(.-)%%", win.GetEnv)
end

---------------------------------------- config
local CfgName = [[%FARPROFILE%\data\macros\]]..ScriptName..".cfg"

local CharEnum = [[A-Za-zÀ-ÖØ-ßà-öøÿĀ-ʯḀ-ỿА-Яа-яЁёЎўЄєЇї΄-Ͽἀ-῿_0-9́]]
local CharsSet = "["..CharEnum.."]+"

local DefCfgData = {
  -- Settings:
  Enabled = false,

  Guid      = win.Uuid("f7684e73-a856-4196-9562-9e829e53a410"),
  ColorGuid = win.Uuid("d7f001ff-7860-4a24-b9ca-37bef603f7bc"),
  PopupGuid = false,

  Path = [[%FARPROFILE%\Dictionaries\]],

  CharsSet = CharsSet,
  InnerSet = CharsSet.."$",
  StartSet = "^"..CharsSet,
  CheckSet = "/\\b"..CharsSet.."\\b/",

  ColorPrio = 199,

  MacroKeys = {
    CheckSpell  = "CtrlF12",
    SwitchCheck = "CtrlShiftF12",
  },

  -- Dictionaries:
  { -- rus
    dic = "ru_RU_yo.dic",
    aff = "ru_RU_yo.aff",
    find = [[/[А-Яа-яЁё]+/]],
    color = {
      Flags = Flag4BIT,
      ForegroundColor = 0xF,
      BackgroundColor = 0x4,
    },
    Enabled = true,
  },
  { -- eng
    dic = "en_US.dic",
    aff = "en_US.aff",
    find = [[/[A-Za-z]+/]],
    color = {
      Flags = Flag4BIT,
      ForegroundColor = 0xF,
      BackgroundColor = 0x5,
    },
    Enabled = true,
  },

} --- DefCfgData

DefCfgData.PopupGuid = DefCfgData.Guid

---------------------------------------- Main
local config

local function CreateMain (ArgData)
  ArgData = ArgData or DefCfgData

  local chunk, serror = loadfile(ExpandEnv(CfgName))
  --far.Show(CfgName, chunk)
  if chunk then
    local env = { __index = _G }
    setmetatable(env, env)
    config, serror = setfenv(chunk, env)()
    if config == nil then config = env.Data end
  end
  if not config then config = {} end

  setmetatable(config, { __index = DefCfgData })

  local n = #config
  if n == 0 then
    n = #DefCfgData
    --for k = 1, n do
    --  config[k] = DefCfgData[k]
    --end
  end
  config.n = n
end -- CreateMain

CreateMain()

----------------------------------------
local editors = {}

---------------------------------------- Hunspell through FFI
local hunspell = require "hunspell"

if type(hunspell) == 'string' then
  far.Message(win.OemToUtf8(hunspell), "hunspell", nil, 'e')
  hunspell = false
end
if not hunspell then return end

---------------------------------------- Init
local function CheckFile (filename)
  local file = io.open(filename, "rb")
  if not file then return end
  file:close()

  return true
end -- CheckFile

local function Init ()

  local Path = config.Path

  for k = 1, config.n do
    local v = config[k]
    v.full_dic = v.dic and ExpandEnv((v.path or Path)..v.dic) or nil
    v.full_aff = v.aff and ExpandEnv((v.path or Path)..v.aff) or nil

    if v.full_dic and CheckFile(v.full_dic) and
       v.full_aff and CheckFile(v.full_aff) then
      v.handle = hunspell.new(v.full_aff, v.full_dic, nil)
      --v.coding = v.handle:get_dic_encoding()
      v.regex = regex.new(v.find)

      --far.Show(v.dic, v.find, v.coding)
    else
      v.Enabled = false
    end
  end

  Init = function() end
end -- Init

---------------------------------------- Menu
local tinsert = table.insert

local function ShowMenu (strings, wordLen)
  local info = EditorGetInfo()

  local menuShadowWidth = 2
  local menuOverheadWidth = menuShadowWidth + 4 --6 => 2 рамка, 2 тень, 2 место для чекмарка
  local menuOverheadHeight = 3 --3 => 2 рамка, 1 тень

  local w = 0
  local Items = {}
  for k = 1, #strings do
    local v = strings[k]
    w = math.max(w, v:len())
    tinsert(Items, { Flags = 0, Text = v })
  end

  local h = 1
  local c = info.CurTabPos - info.LeftPos
  local r = info.CurLine - info.TopScreenLine
  local x = math.max(0, c - w - menuOverheadWidth + menuShadowWidth)
  x = (info.WindowSizeX - c) > (c + 2 - wordLen) and (c + 1) or x -- меню справа или слева от слова?
  local y = 0
  if (info.WindowSizeY - r - 1) > (r + 1) then -- меню сверху или снизу?
    -- снизу
    y = r + 2
    h = info.WindowSizeY - y + 1 - menuOverheadHeight
    h = math.min(h, #strings)
  else
    -- сверху
    y = r - #strings - 1
    if y < 1 then y = 1 end
    h = r - y - 1
  end

  -- fix menu width
  if (x + w + menuOverheadWidth) > info.WindowSizeX then
    w = info.WindowSizeX - x - menuOverheadWidth
  end

  local Form = {
    {"DI_LISTBOX", 0, 0, w + 3, h + 1, Items, 0, 0, 0, ""}
  }

  local function DlgProc (dlg, msg, param1, param2)
  end -- DlgProc

  local hDlg = far.DialogInit(config.PopupGuid,
                              x, y,
                              x + w + 3,
                              y + h + 1,
                              nil, Form, 0, DlgProc)
  local Index = far.DialogRun(hDlg) > 0 and
                far.SendDlgMessage(hDlg, F.DM_LISTGETCURPOS, 1).SelectPos or nil
  far.DialogFree(hDlg)

  return Index
end -- ShowMenu

---------------------------------------- Spell
local function ClearWord (word)
  return word:gsub("́", "")
end -- ClearWord

local function CheckSpell ()
  local Info = EditorGetInfo()
  if not Info then return end

  Init()

  local row, pos = Info.CurLine, Info.CurPos
  local line, eol = EditorGetLine(Info.EditorID, row, 3)
  if not line then return end

  local word = ""
  local s, spos = line, 0
  if pos <= s:len() + 1 then
    local slab = pos > 1 and
                 s:sub(1, pos - 1):match(config.InnerSet) or ""
    local tail = s:sub(pos, -1):match(config.StartSet) or ""
    spos = pos - slab:len()
    word = slab..tail
  end

  local wLen = word:len()
  word = ClearWord(word)
  if word:len() <= 1 then return end -- WARN: exclude one char words

  for k = 1, config.n do
    local v = config[k]
    if v.Enabled and v.regex:match(word) and
       not v.handle:spell(word) then

      local items = v.handle:suggest(word)
      if #items > 0 then
        local Index = ShowMenu(items, wLen)
        if Index then
          local s = line:sub(1, spos - 1)..
                    items[Index]..
                    line:sub(spos + wLen)
          EditorSetLine(-1, 0, s, eol)
        end
      end

      break
    end
  end -- for

end -- CheckSpell

---------------------------------------- Colorize

function GetData (id)
  local data = editors[id]
  if not data then
    editors[id] = { start = 0, finish = -1, }
    data = editors[id]
  end

  return data
end ---- GetData

local function RemoveColors (id)
  local data = GetData(id)
  local guid = config.ColorGuid
  for l = data.start, data.finish do
    editor.DelColor(id, l, 0, guid)
  end

  data.start = 0
  data.finish = -1
  return data
end -- RemoveColors

local Far_WinInfo = F.ACTL_GETWINDOWINFO
local WinType_Editor = F.WTYPE_EDITOR

local function RemoveAllColors ()
  local Count = far.AdvControl(F.ACTL_GETWINDOWCOUNT, 0, 0)
  for i = 1, Count do
    local Info = far.AdvControl(Far_WinInfo, i, 0)
    if Info and Info.Type == WinType_Editor then
      RemoveColors(Info.Id)
    end
  end
end -- RemoveAllColors

local AddColor = editor.AddColor
local Mark_Current = F.ECF_TABMARKCURRENT

local function CheckSpellAll (Info)
  if not Info then return end

  Init()

  local id = Info.EditorID
  local prio = config.ColorPrio
  local guid = config.ColorGuid

  local data = RemoveColors(id)
  data.start = Info.TopScreenLine
  data.finish = math.min(Info.TopScreenLine + Info.WindowSizeY - 1, Info.TotalLines)
  local Regex = regex.new(config.CheckSet)

  for l = data.start, data.finish do
    local line = EditorGetLine(-1, l, 3)
    local pos = 1
    while true do
      local sbegin, send = Regex:find(line, pos)
      if not sbegin then break end

      pos = send + 1 -- for next word
      if send > sbegin then -- WARN: exclude one char words
        local word = line:sub(sbegin, send)
        word = ClearWord(word)
        if word == "" then return end

        --far.Show(config.CheckSet, line, word, sbegin, send)

        for k = 1, config.n do
          local v = config[k]
          if v.Enabled and
             v.regex:match(word) and
             not v.handle:spell(word) then
            AddColor(id, l, sbegin, send, Mark_Current, v.color, prio, guid)

            break
          end
        end -- for
      end
    end -- while
  end -- for data

end -- CheckSpellAll

local function SwitchCheck ()
  config.Enabled = not config.Enabled
  if not config.Enabled then
    RemoveAllColors()
  end

  return editor.Redraw()
end -- SwitchCheck

---------------------------------------- Events
Event {
  group = "EditorEvent",
  description = "Check spell all",

  action = function (id, event, param)
    if event == F.EE_READ then
      editors[id] = { start = 0, finish = -1, }
    end
    if event == F.EE_CLOSE then
      editors[id] = nil
    end
    if event == F.EE_REDRAW then
      if config.Enabled then
        CheckSpellAll(EditorGetInfo())
      end
    end
  end,
} -- Event "EditorEvent"

Event {
  group = "ExitFAR",
  description = "Remove all spell colors",

  action = function ()
    RemoveAllColors()

    for _, v in ipairs(config) do
      if v.Enabled and v.handle then
        v.handle:free()
      end
    end
  end,
} -- Event "ExitFAR"

---------------------------------------- Macros
Macro {
  area = "Editor",
  key = config.MacroKeys.CheckSpell,
  description = "Check spell",
  action = CheckSpell,
} ---

Macro {
  area = "Editor",
  key = config.MacroKeys.SwitchCheck,
  description = "Spell on/off",
  action = SwitchCheck,
} ---
--------------------------------------------------------------------------------
