--[[ lfa_config ]]--

----------------------------------------
--[[ description:
  -- Work initiation.
  -- Инициирование работы.
--]]
----------------------------------------
--[[ uses:
  LuaFAR,
  LF context.
  -- group: LFA config.
--]]
--------------------------------------------------------------------------------
local CErrorTitle = "Error: LuaFAR Editor config"
local SInstallError = "Package is not properly installed:\n%s"
local farError = function (Msg) return far.Message(Msg, CErrorTitle, nil, 'e') end

if rawget(_G, 'context') == nil then
  farError(SInstallError:format"LuaFAR context is required!")
  return false
end

----------------------------------------
local context = context
--local context, ctxdata = context, ctxdata

----------------------------------------
local ext = ""
if context.use.LFVer < 3 then ext = ".lua" end

--------------------------------------------------------------------------------
local lfa_config = {
  editor = {
    shared  = {}, -- shared data
    update  = {}, -- update functions
    process = {}, -- process functions
  }, --
  viewer = {
    shared  = {}, -- shared data
    update  = {}, -- update functions
    process = {}, -- process functions
  }, --
} --
context.use.lfa_config = lfa_config

---------------------------------------- Configs
-- Register configuration files.
local registerConfig = context.config.register
registerConfig{ key = 'lfa_common', name = 'common',
                path = 'lfa_config' }
registerConfig{ key = 'lfa_editor', name = 'editor',
                path = 'lfa_config', inherit = true, }
registerConfig{ key = 'lfa_vision', name = 'vision',
                path = 'lfa_config', inherit = true, }

-- Add context handlers.
require 'lfa_config.editor.changeType'
context.handle.add('changeType', lfa_config.changeType)

---------------------------------------- Modules
-- Modules used in lfa_config
local modules = {
  'lfa_config.editor.editorDelta',
  'lfa_config.editor.lineNumbers',
  'lfa_config.editor.vision',
  'lfa_config.editor.saveFile',
  'lfa_config.editor.editorConfig',
} ---

-- Unregister all loaded modules.
for k = 1, #modules do
  package.loaded[modules[k]] = nil
  require(modules[k])
end

----------------------------------------
local ScriptsPath = "scripts\\lfa_config\\"

AddToMenu("e", ":sep:lfa config")
AddToMenu('e', "Change current type", '', ScriptsPath.."editor\\changeType"..ext, "chooseCurrentType")
--AddToMenu('e',  "Set editor parameters", '', ScriptsPath.."editor\\editorConfig"..ext, "lfa_config.setEditorParameters()")

----------------------------------------
MakeResident(ScriptsPath.."resident"..ext)

--------------------------------------------------------------------------------
