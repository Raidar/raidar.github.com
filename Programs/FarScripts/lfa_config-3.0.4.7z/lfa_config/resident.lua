--[[ lfa_config ]]--

----------------------------------------
--[[ description:
  -- Using in plugins.
  -- Использование в плагинах.
--]]
----------------------------------------
--[[ uses:
  LuaFAR,
  LF context.
  -- group: LFA config.
--]]
--------------------------------------------------------------------------------

----------------------------------------
local F = far.Flags

----------------------------------------
local lfa_common = ctxdata.config.lfa_common

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local lfa_config = context.use.lfa_config
local setEditorParameters = lfa_config.setEditorParameters
local drawLineNumbers = lfa_config.drawLineNumbers
local drawRightBorder = lfa_config.drawRightBorder

---------------------------------------- redraw
local redraw = F.EE_REDRAW
local redrawAll    = 0 --F.EEREDRAW_ALL
--local redrawLine   = 1 --F.EEREDRAW_LINE
--local redrawChange = 2 --F.EEREDRAW_CHANGE

local redrawActions = {}

-- [[
redrawActions[redrawAll] = function ()
  local ei = editor.GetInfo()
  --drawLineNumbers(false, ei)
  drawLineNumbers(true, ei)
  drawRightBorder(ei)
end
--]]

--[[
redrawActions[redrawLine] = function ()
  --lfa_config.editorDelta = lfa_config.editorGetDelta()
  --lfa_config.editorDelta = lfa_config.editorDelta or lfa_config.editorGetDelta()
  --logShow(lfa_config.editorDelta, "editorDelta")
  local ei = editor.GetInfo()
  drawLineNumbers(true, ei)
  drawRightBorder()
end
--]]

--[[
redrawActions[redrawChange] = function ()
  --drawLineNumbers(false)
  drawLineNumbers(true)
  --drawRightBorder()
end
--]]

---------------------------------------- actions
local actions = {}

actions[redraw] = function (param)
  --local f = redrawActions[param]   -- FAR2
  local f = redrawActions[redrawAll] -- FAR23
  if f then return f() end
end

actions[F.EE_GOTFOCUS] = function (param)
  return drawLineNumbers(true)
end

actions[F.EE_READ] = function ()
  if lfa_common.useAutoConfig then
    setEditorParameters()
    --setEditorParameters(true)
    drawLineNumbers(true)
  end
end

----------------------------------------
function ProcessEditorEvent (id, event, param)
  id, event, param = far.ParseEditorEvent(id, event, param)
  local f = actions[event]
  if f then f(param) end
  return 0
end

if not lfa_common.doNotCatchHotKeys then
--do
  --[[
  local keys = {
    F10 = true,
    ["Alt+B"] = true,
    ESCAPE = true,
    RETURN = true,
    SHIFT = true,
    MENU = true,
    CONTROL = true,
  }
  --]]

  local lnRedraw = false
  local rctrl, shift, band = F.RIGHT_CTRL_PRESSED, F.SHIFT_PRESSED, bit64.band
  local ctrl = rctrl + F.LEFT_CTRL_PRESSED
  local modifiers = ctrl + F.LEFT_ALT_PRESSED + F.RIGHT_ALT_PRESSED + shift

  local saveFile = lfa_config.saveFile

  function ProcessEditorInput (rec)
    if rec.EventType ~= F.KEY_EVENT then return false end

    far.RepairInput(rec)
    if rec.KeyDown then
      local scanCode = rec.VirtualScanCode
      local cKey = rec.ControlKeyState
      if ( band(cKey, rctrl) > 0 or
         ( band(cKey, ctrl) > 0 and band(cKey, shift) > 0 ) )
         and scanCode > 0 and scanCode < 12 then
        lnRedraw = true
      end
      -- [[
      --local kcode = rec.VirtualKeyCode
      if scanCode == 0x71 and band(cKey, modifiers) == 0 then -- F2
        return saveFile()
      end
      --]]
    elseif lnRedraw then
      drawLineNumbers(true)
      lnRedraw = false
    end

    return false
  end

end

local resident = {
  ProcessEditorEvent = ProcessEditorEvent,
  ProcessEditorInput = ProcessEditorInput,
} --- resident

--------------------------------------------------------------------------------
return resident
--------------------------------------------------------------------------------
