--[[ lfa_config ]]--

--------------------------------------------------------------------------------

----------------------------------------
--
-- Save newly created file with specified EOL.
--
----------------------------------------
--local far = far

local save = editor.SaveFile

----------------------------------------
local context, ctxdata = context, ctxdata

local editors = ctxdata.editors

--------------------------------------------------------------------------------
local lfa_config = context.use.lfa_config

local eols = {
  win  = '\r\n',
  unix = '\n',
  mac  = '\r',
} ---

function lfa_config.saveFile ()
  local einfo = editor.GetInfo()
  if not einfo or win.GetFileInfo(einfo.FileName) then
    return false
  end

  local cfg = editors.current.lfa_editor
  local k = cfg and cfg.NewFileEOL
  if not k then return false end

  editor.Redraw() -- Avoid saving an empty file!
  save(nil, eols[k])
  return true
end
--------------------------------------------------------------------------------
