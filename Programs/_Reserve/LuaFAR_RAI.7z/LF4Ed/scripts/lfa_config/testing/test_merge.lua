--[[ LuaFAR Editor config ]]--
--[[ config merge test ]]--

--------------------------------------------------------------------------------

----------------------------------------
local ctxdata = ctxdata
--local context, ctxdata = context, ctxdata

--local utils = require 'context.utils.useUtils'
--local tables = require 'context.utils.useTables'

----------------------------------------
-- [[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local lfa_def = ctxdata.config.lfa_editor.default
--local lfa_def = ctxdata.config.lfa_vision.default

local lfa_old = (getmetatable(lfa_def) or {}).__cfgMT

--logShow(ctxdata.editors.current, "Current", 3)
--logShow(lfa_def, "lfa_editor", "d2 _")
logShow({ def = lfa_def, old = lfa_old }, "lfa_editor", "d3 _")
--logShow(lfa_def, "lfa_vision", 2)

--------------------------------------------------------------------------------
