--[[ lfa_config ]]--

----------------------------------------
--[[ description:
  -- Editor configuration.
  -- Конфигурация редактора.
--]]
----------------------------------------
--[[ uses:
  nil.
  -- group: Config, Datas.
--]]
--------------------------------------------------------------------------------
local cfg = {
  --_meta_ = { basis = 'user', merge = 'none' },
  --_meta_ = { basis = 'base', merge = 'asmeta' },
  --_meta_ = { basis = 'user', merge = 'asmeta' },
  _meta_ = { basis = 'user', merge = 'expand' },
  --_meta_ = { basis = 'user', merge = 'update' },

  default = {
    --inherit = nil,

    --Lock = false,
    --CodePage = 'utf8',
    --SetBom = true,
    --NewFileEOL = 'win',
    --CharCodeBase = 'oct',
    --CharCodeBase = 'hex',

    SavePosition = true,
    --CursorBeyondEOL = true,
    --ShowWhiteSpace = false,

    --AutoIndent = false,
    TabSize = 4,
    ExpandTabs = 'no',
    --WordDiv = [[!%^&*()+|{}:"'`<>?-=\/[];,.~@#$]],
    --AddWordDiv = '',
    --RemoveWordDiv = {'',''},

    --ShowMargin = false, -- DEBUG
    ColorizeElements = true,
  },
  none = { inherit = 'default' },

  --[=[
  text = {
  },
  --]=]

  plain = {
    CodePage = 'utf8',
    --WordDiv = [[.,!?:;"']],
  },

  readme = {
    CodePage = 'utf8',
    SetBom = false,
  },

  imd_file = {
    TabSize = 8,
  },

  source = {
    --SetBom = false,
    --CharCodeBase = 'hex',

    CursorBeyondEOL = true,

    AutoIndent = true,
    TabSize = 4,
    ExpandTabs = 'no',
  },

  pascal = {
    CodePage = 'ansi',
  },

  python = {
    TabSize = 4,
    CursorBeyondEOL = false,
    --ExpandTabs = 'all',
  },
--[=[
  packed = {
    Lock = true,
    CharCodeBase = 'hex',

    --SavePosition = false,
    ShowWhiteSpace = true,

    TabSize = 1,
    ExpandTabs = 'no',
  },

  mixed = {
    Lock = true,
    CharCodeBase = 'hex',

    --SavePosition = false,
    ShowWhiteSpace = true,

    TabSize = 1,
    ExpandTabs = 'no',
  },
--]=]
  --mso = {},

} --- cfg

return cfg
--------------------------------------------------------------------------------
