--[[ lfa_config ]]--

----------------------------------------
--[[ description:
  -- Common configuration.
  -- Общая конфигурация.
--]]
----------------------------------------
--[[ uses:
  nil.
  -- group: Config, Datas.
--]]
--------------------------------------------------------------------------------
local cfg = {
  _meta_ = { basis = 'user', merge = 'expand' },

  useAutoConfig = true,

  LinePanelMinWidth   = 3,
  LinePanelLinesLimit = 10000,
} --- cfg

return cfg
--------------------------------------------------------------------------------
