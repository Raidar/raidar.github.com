--[[ UniUtf ]]--

----------------------------------------
--[[ description:
  -- UniUtf: Enumerations for Unicode.
  -- UniUtf: Перечисления для Unicode.
--]]
----------------------------------------
--[[ uses:
  nil.
  -- group: UniUtf.
--]]
----------------------------------------
--/* license.terms: see slnudata.c */
--------------------------------------------------------------------------------

----------------------------------------
local bit = bit64
local bor = bit.band
local bshl = bit.lshift
--local band, bor = bit.band, bit.bor
--local bnot, bxor = bit.bnot, bit.bxor
--local bshl, bshr = bit.lshift, bit.rshift

---------------------------------------- unidata
--local UD = require "UniUtf.slnudata"
local UD = require "Rh_Scripts.UniUtf.unidata"

--------------------------------------------------------------------------------
local unit = {}

---------------------------------------- masks
--[[
 * Each group represents a unique set of character attributes.
 * The attributes are encoded into a 32-bit value as follows:
 *
 * Bits 00-04 -- Character category: see the constants listed below.
 *
 * Bits 05-07 -- Case delta type: 000 = identity
 *                010 = add delta for lower
 *                011 = add delta for lower, add 1 for title
 *                100 = sutract delta for title/upper
 *                101 = sub delta for upper, sub 1 for title
 *                110 = sub delta for upper, add delta for lower
 *
 * Bits 08-21 -- Reserved for future use.
 *
 * Bits 22-31 -- Case delta: delta for case conversions.
 *               This should be the highest field so we can easily sign extend.
--]]

local masks = {
  --UNICODE_CHAR_CAT_MASK = 0x0F, -- ???
  UNICODE_CATEGORY_MASK = UD.UNICODE_CATEGORY_MASK, -- 0x1F
  UNICODE_CASETYPE_MASK = UD.UNICODE_CASETYPE_MASK, -- 0xE0
  UNICODE_CASECONV_MASK = 0xFFC00000,
} ---- masks
unit.masks = masks

---------------------------------------- categories
--[[
 * The following constants are used
 * to determine the category of a Unicode character.
--]]
local cats = {
    UNASSIGNED = 0, -- Cn
    -- LETTER       -- L  = LC | Lm | Lo
    -- CASED_LETTER -- LC = Lu | Ll | Lt
    UPPERCASE_LETTER = 1, -- Lu
    LOWERCASE_LETTER = 2, -- Ll
    TITLECASE_LETTER = 3, -- Lt
    MODIFIER_LETTER  = 4, -- Lm
    OTHER_LETTER     = 5, -- Lo
    -- MARK         -- M  = Mn | Me | Mc
    NON_SPACING_MARK = 6, -- Mn
    ENCLOSING_MARK   = 7, -- Me
    SPACING_MARK     = 8, -- Mc -- COMBINING_SPACING_MARK = 8,
    -- NUMBER       -- N  = Nd | Nl | No
    DECIMAL_NUMBER   = 9,  -- Nd -- DECIMAL_DIGIT_NUMBER = 9, -- == digit
    LETTER_NUMBER    = 10, -- Nl
    OTHER_NUMBER     = 11, -- No
    -- SEPARATOR    -- Z  = Zs | Zl | Zp
    SPACE_SEPARATOR     = 12, -- Zs
    LINE_SEPARATOR      = 13, -- Zl
    PARAGRAPH_SEPARATOR = 14, -- Zp
    -- OTHER        -- C  = Cn | Cc | Cf | Co | Cs
    CONTROL     = 15, -- Cc -- == cntrl
    FORMAT      = 16, -- Cf
    PRIVATE_USE = 17, -- Co
    SURROGATE   = 18, -- Cs
    -- PUNCTUATION  -- P  = Pc | Pd | Ps | Pe | Pi | Pf | Po -- == punct
    CONNECTOR_PUNCTUATION     = 19, -- Pc
    DASH_PUNCTUATION          = 20, -- Pd
    OPEN_PUNCTUATION          = 21, -- Ps --< start
    CLOSE_PUNCTUATION         = 22, -- Pe --< end
    INITIAL_QUOTE_PUNCTUATION = 23, -- Pi
    FINAL_QUOTE_PUNCTUATION   = 24, -- Pf
    OTHER_PUNCTUATION         = 25, -- Po
    -- SYMBOL       -- S  = Sm | Sc | Sk | So
    MATH_SYMBOL     = 26, -- Sm
    CURRENCY_SYMBOL = 27, -- Sc
    MODIFIER_SYMBOL = 28, -- Sk
    OTHER_SYMBOL    = 29, -- So
    UNKNOWN_30 = 30,
    UNKNOWN_31 = 31,
} ---- categories
unit.categories = cats

---------------------------------------- group bits
--[[
 * The following macros are used for fast character category tests.
 * The x_BITS values are shifted right by the category value
 * to determine whether the given category is included in the set.
--]]
local bits = {

  ALPHA = bor(bshl(1, cats.UPPERCASE_LETTER), -- Lu
              bshl(1, cats.LOWERCASE_LETTER), -- Ll
              bshl(1, cats.TITLECASE_LETTER), -- Lt
              bshl(1, cats.MODIFIER_LETTER),  -- Lm
              bshl(1, cats.OTHER_LETTER)),    -- Lo
  LETTER = 0,

  DIGIT = bshl(1, cats.DECIMAL_NUMBER),-- Nd

  NUMBER = bor(bshl(1, cats.DECIMAL_NUMBER), -- Nd
               bshl(1, cats.LETTER_NUMBER),  -- Nl
               bshl(1, cats.OTHER_NUMBER)),  -- No

  SPACE = bor(bshl(1, cats.SPACE_SEPARATOR),      -- Zs
              bshl(1, cats.LINE_SEPARATOR),       -- Zl
              bshl(1, cats.PARAGRAPH_SEPARATOR)), -- Zp

  CONNECTOR = bshl(1, cats.CONNECTOR_PUNCTUATION), -- Pc

  PUNCT = bor(bshl(1, cats.CONNECTOR_PUNCTUATION),     -- Pc
              bshl(1, cats.DASH_PUNCTUATION),          -- Pd
              bshl(1, cats.OPEN_PUNCTUATION),          -- Ps
              bshl(1, cats.CLOSE_PUNCTUATION),         -- Pe
              bshl(1, cats.INITIAL_QUOTE_PUNCTUATION), -- Pi
              bshl(1, cats.FINAL_QUOTE_PUNCTUATION),   -- Pf
              bshl(1, cats.OTHER_PUNCTUATION)),        -- Po

  -- ???? --
  GRAPHEME = bor(bshl(1, cats.NON_SPACING_MARK), -- Mn
                 bshl(1, cats.ENCLOSING_MARK)),  -- Me

  MARK = bor(bshl(1, cats.NON_SPACING_MARK), -- Mn
             bshl(1, cats.ENCLOSING_MARK),   -- Me
             bshl(1, cats.SPACING_MARK)),    -- Mc

  SYMBOL = bor(bshl(1, cats.MATH_SYMBOL),     -- Sm
               bshl(1, cats.CURRENCY_SYMBOL), -- Sc
               bshl(1, cats.MODIFIER_SYMBOL), -- Sk
               bshl(1, cats.OTHER_SYMBOL)),   -- So

  SURROGATE = bshl(1, cats.SURROGATE), -- Cs

  OTHER = bor(bshl(1, cats.UNASSIGNED),  -- Cn
              bshl(1, cats.CONTROL),     -- Cc
              bshl(1, cats.FORMAT),      -- Cf
              bshl(1, cats.PRIVATE_USE), -- Co
              bshl(1, cats.SURROGATE)),  -- Cs

  PRINT = 0,
} ---- bits
unit.group_bits = bits

bits.LETTER = bits.ALPHA
bits.PRINT = bor(bits.ALPHA, bits.NUMBER, bits.SPACE,
                 bits.MARK,  bits.PUNCT,  bits.SYMBOL)

--------------------------------------------------------------------------------
return unit
--------------------------------------------------------------------------------
