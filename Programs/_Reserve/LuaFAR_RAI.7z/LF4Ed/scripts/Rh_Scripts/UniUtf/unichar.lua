--[[ UniUtf ]]--

----------------------------------------
--[[ description:
  -- UniUtf: Unicode char converter.
  -- UniUtf: Конвертер символов Unicode.
--]]
----------------------------------------
--[[ uses:
  [Rh Utils].
  -- group: UniUtf.
--]]
--------------------------------------------------------------------------------
--[[
According to http://ietf.org/rfc/rfc3629.txt we support up to
4-byte (21 bit) sequences encoding the UTF-16 reachable 0-0x10FFFF.
Any byte not part of a 2-4 byte sequence in that range decodes to itself.
Ill formed (non-shortest) "C0 80" will be decoded as two code points
C0 and 80, not code point 0; see security considerations in the RFC.
However, UTF-16 surrogates (D800-DFFF) are accepted.

See http://www.unicode.org/reports/tr29/#Grapheme_Cluster_Boundaries
for default grapheme clusters.
Lazy westerners we are (and lacking the Hangul_Syllable_Type data),
we care for base char + Grapheme_Extend, but not for Hangul syllable sequences.

For http://unicode.org/Public/UNIDATA/UCD.html#Grapheme_Extend
we use Mn (NON_SPACING_MARK) + Me (ENCLOSING_MARK),
ignoring the 18 mostly south asian Other_Grapheme_Extend (16 Mc, 2 Cf) from
http://www.unicode.org/Public/UNIDATA/PropList.txt
--]]
--------------------------------------------------------------------------------

local string = string

local slen = string.len
local schar, sbyte = string.char, string.byte

----------------------------------------
local bit = bit64
local band, bor = bit.band, bit.bor
--local bnot, bxor = bit.bnot, bit.bxor
local bshl, bshr = bit.lshift, bit.rshift

----------------------------------------

--local numbers = require 'context.utils.useNumbers'

--local hex = numbers.hex8

----------------------------------------
--local farUt = require "Rh_Scripts.Utils.Utils"

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
--[[
Bytes Range of values        > Bits  > Code     = dec value    = hex value
count                          count   points count
1   0x00..0x7F,              >     7 > 2^7  - 1 = 127          = 0x7F
2   0x080..0x7FF,            > 5+6*1 > 2^11 - 1 = 2 047        = 0x7FF
3   0x0800..0xFFFF,          > 4+6*2 > 2^16 - 1 = 65 535       = 0xFFFF
4   0x1 0000..0x1F FFFF,     > 3+6*3 > 2^21 - 1 = 2 097 151    = 0x1F FFFF
5   0x02 0000..0x3FF FFFF,   > 2+6*4 > 2^26 - 1 = 67 108 863   = 0x3FF FFFF
6   0x040 0000..0x7FFF FFFF, > 1+6*5 > 2^31 - 1 = 2 147 483647 = 0x7FFF FFFF
7   0x800 0000..             > 0+6*6 > 2^36 - 1 = 68719 476735 = 0xF FFFF FFFF

1   0x00    > 0x7F  > 0xxx xxxx
2   0xC0    > 0x3F  > 110x xxxx
3   0xE0    > 0x1F  > 1110 xxxx
4   0xF0    > 0x0F  > 1111 0xxx
5   0xF8    > 0x07  > 1111 10xx
6   0xFC    > 0x03  > 1111 110x
7   0xFE    > 0x01  > 1111 1110
--]]
--------------------------------------------------------------------------------

---------------------------------------- const
-- Max byte count:
local UTF8_MAX = 6 -- for UTF-8
-- Values limits for en/decoding.
local lims, adds
local limmax = 0xFFFFFFFFF

if UTF8_MAX <= 4 then -- Standard limits
  lims = { 0x80, 0x800, 0x10000, limmax } -- Standard only
  adds = { 0x00, 0xC0,  0xE0,    0xF0 }
else --     > 5 -- Full available limits
  lims = { 0x80, 0x800, 0x10000, 0x200000, 0x4000000, limmax }
  adds = { 0x00, 0xC0,  0xE0,    0xF0,     0xF8,      0xFC }
--  lims = { 0x80, 0x800, 0x10000, 0x200000, 0x4000000, 0x80000000, limmax }
--  adds = { 0x00, 0xC0,  0xE0,    0xF0,     0xF8,      0xFC,       0xFE }
end
local limslen = #lims - 1

---------------------------------------- base
local unit = {
-- [[
  MAX = UTF8_MAX,
  limmax = limmax,
  lims = lims,
  adds = adds,
  limslen = limslen,
--]]
} ---

-- Byte count in UTF-8 char.
function unit.count (char)
  -- Move from assumed end to begin.
  local s, k = sbyte(char, 1), limslen + 1
  while k > 1 and s < adds[k] do k = k - 1 end
  return k
end ----

-- UTF-8 encoding from Unicode.

-- Short-byte preferred encoding. --< code ~= (nil|"")
function unit.enco (code) --> (string char, byte count)
  --if not code or code == "" then return nil end
  if code < lims[1] then return schar(code), 1 end

  local s, c = "", code
  for k = 2, limslen + 1 do
    s, c = schar( bor(0x80, band(0x3F, c)) )..s, bshr(c, 6)
    if code < lims[k] then return schar( bor(adds[k], c) )..s, k end
  end
end ---- enco

-- [[
local tconcat = table.concat
-- Long-byte preferred encoding.
function unit.emco (code) --> (string char, byte count)
  if code < lims[1] then return schar(code), 1 end

  local c, s, v = code, {}
  for k = limslen, 1, -1 do
    v = lims[k]

    if code >= v then
      s[k+1] = schar( bor(0x80, band(c, 0x3F)) )
      c = bor(bshr(c, 6), v)
    end
  end
  s[1] = schar( bor(0xC0, c) )

  return tconcat(s), #s
end ---- emco
--]]

-- UTF-8 decoding to Unicode.

-- Short-byte preferred decoding. --< char ~= (nil|"")
function unit.deco (char) --> (number code, byte count)
  --if not char or char == "" then return nil end

  local s = sbyte(char, 1)
  if s < adds[2] then return s, 1 end

  local k = limslen + 1
  while k > 2 and s < adds[k] do k = k - 1 end

  local c, len = band(s, bshr(0x3F, k - 1)), slen(char)

  for j = 2, k do
    if j > len then return c, j - 1 end
    s = sbyte(char, j)
    if band(s, 0xC0) ~= 0x80 then return c, j - 1 end
    c = bor(bshl(c, 6), band(s, 0x3F))
  end

  return c, k
end ---- utf8.deco

--------------------------------------------------------------------------------
return unit
--------------------------------------------------------------------------------
