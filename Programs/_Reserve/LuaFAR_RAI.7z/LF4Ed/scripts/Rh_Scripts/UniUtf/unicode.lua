--[[ UniUtf ]]--

----------------------------------------
--[[ description:
  -- Unicode handling.
  -- Обработка Unicode.
--]]
----------------------------------------
--[[ uses:
  [Rh Utils].
  -- group: UniUtf.
--]]
--------------------------------------------------------------------------------

--local string = string

--local slen = string.len
--local schar, sbyte = string.char, string.byte

----------------------------------------
local bit = bit64
local band = bit.band
local bnot = bit.bnot
local bshr = bit.rshift
--local band, bor = bit.band, bit.bor
--local bnot, bxor = bit.bnot, bit.bxor
--local bshl, bshr = bit.lshift, bit.rshift

---------------------------------------- unidata
--local UD = require "UniUtf.unidata"
local UD = require "Rh_Scripts.UniUtf.unidata"

local UNICODE_CATEGORY_MASK = UD.UNICODE_CATEGORY_MASK

--local GetCaseType = UD.GetCaseType
--local GetCategory = UD.GetCategory
--local GetDelta    = UD.GetDelta
local GetUniCharInfo = UD.GetUniCharInfo

---------------------------------------- unienum
--local UE = require "UniUtf.unienum"
local UE = require "Rh_Scripts.UniUtf.unienum"

--local cats = UE.categories
local bits = UE.group_bits

---------------------------------------- uniconv
--local UV = require "UniUtf.uniconv"

---------------------------------------- unichar
--local UH = require "Rh_Scripts.UniUtf.unichar"

--local u8 = UH.utf8
--local utf8_count = u8.count
--local utf8_enco = u8.enco
--local utf8_emco = u8.emco
--local utf8_deco = u8.deco

----------------------------------------
--local numbers = require 'context.utils.useNumbers'

--local hex = numbers.hex8

----------------------------------------
--local farUt = require "Rh_Scripts.Utils.Utils"

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local unit = {}

----------------------------------------
--local UNICODE_SELF = 0x7F
--local UTF_MAX = 6
---------------------------------------- info

-- charinfo(c) (~0xFFFF&(c) ? 0 : GetUniCharInfo(c))
local function charinfo (c)
  return band(c, bnot(0xFFFF)) == 0 and 0 or GetUniCharInfo(c) -- Why 0xFFFF only?
end --
unit.charinfo = charinfo

-- charcat(c) (UNICODE_CATEGORY_MASK & charinfo(c))
local function charcat (c)
  return band(UNICODE_CATEGORY_MASK, charinfo(c))
end --
unit.charcat = charcat

do
  local GRAPHEME_BITS = bits.GRAPHEME
--[[
 Grapheme_Extend(code) (1 & (GRAPHEME_BITS >> charcat(code)))
--]]
function unit.Grapheme_Extend (code)
  return band(1, bshr(GRAPHEME_BITS, charcat(code)))
end ----

end -- do

local modes = { -- operation modes:
  MODE_ASCII = 0, -- single byte 7bit
  MODE_LATIN = 1, -- single byte 8859-1
  MODE_UTF8  = 2, -- UTF-8 by code points
  MODE_GRAPH = 3, -- UTF-8 by grapheme clusters
} --- modes
unit.modes = modes

do
  local not_one = bnot(1)
-- MODE_MBYTE(mode) (~1&(mode))
function unit.MODE_MBYTE (mode)
  return band(not_one, mode)
end ----

end -- do

--------------------------------------------------------------------------------
return unit
--------------------------------------------------------------------------------
