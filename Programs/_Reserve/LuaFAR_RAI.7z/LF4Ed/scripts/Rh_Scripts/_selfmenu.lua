--[[ Self Menu ]]--

---------------------------------------- Check
local CErrorTitle = "Error: Rh_Scripts Testing"
local SInstallError = "Package is not properly installed:\n%s"
local farError = function (Msg)
  return far.Message(Msg, CErrorTitle, nil, 'e')
end

if rawget(_G, 'context') == nil then
  farError(SInstallError:format"LuaFAR context is required!")
  return false
end

----------------------------------------
local ext = ""
if context.use.LFVer < 3 then ext = ".lua" end

---------------------------------------- Items
local ScriptPath = "scripts/Rh_Scripts/"
local TestingPath = ScriptPath.."Testing/"

AddToMenu("evp", ":sep:Testing")

-- Tabular Menu.
AddToMenu("evp", "T&abular Menu", nil, TestingPath.."Test_RM"..ext, "ShowTabularMenu")
AddToMenu("evp", "F&ilter RMenu", nil, TestingPath.."Test_RM"..ext, "ShowFilterMenu")
AddToMenu("evp", "D&efault Menu", nil, TestingPath.."Test_RM"..ext, "ShowDefaultMenu")
--AddToMenu("evp", "&Rectang Menu", nil, TestingPath.."Test_RM"..ext, "ShowRectangMenu")
  -- -- -- -- --

--------------------------------------------------------------------------------
