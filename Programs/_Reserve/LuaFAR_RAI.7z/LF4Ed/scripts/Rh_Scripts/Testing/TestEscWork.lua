-- Тест обработки --

-- Разделитель для разбиения
--local sep = "|" -- 0x007C
local sep = "│" -- 0x2500

-- Строка для разбиения
local s = "10"..sep.." some code"

-- Строка для поиска разбиения
--local f = string.format("^(.-%s)", sep) -- с этим одинаково
local f = string.format("^(.-%%%s)", sep) -- с этим различно

far.Message(s:gsub(f, "")           -- utf8
            .."\n".. 
            string.gsub(s, f, ""),  -- ascii
            s)
