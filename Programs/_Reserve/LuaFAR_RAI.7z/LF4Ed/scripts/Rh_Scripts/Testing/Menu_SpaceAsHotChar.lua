local Props = {
  Title = "Menu",
} ---

local Items = {
  { text = "&abc", },
  { text = "& abcdef", },
} ---

local Item = far.Menu(Props, Items)
far.Message(Item.text, "Choosed")
