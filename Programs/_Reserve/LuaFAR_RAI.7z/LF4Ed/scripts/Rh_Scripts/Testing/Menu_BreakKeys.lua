
--local Menu = far.Menu
local Menu = require "Rh_Scripts.RMenu.RectMenu"

local Props = {
  Title = "Menu",
} ---

local Items = {
  { text = "&abc", },
  { text = "& abcdef", },
} ---

local BKeys = {
  { BreakKey = "BACK",    Action = "BACK", },
  --{ BreakKey = "BS",      Action = "BS", },
  --{ BreakKey = "Back",    Action = "Back", },

  { BreakKey = "ShiftF1", Action = "ShiftF1", },
  --{ BreakKey = "S+F1",    Action = "S+F1", },
} ---

local Item, Pos = Menu(Props, Items, BKeys)
if not Item then return end

if Item.text then
  far.Message(Item.text, tostring(Pos))
else
  far.Message(Item.BreakKey, Item.Action)
end

