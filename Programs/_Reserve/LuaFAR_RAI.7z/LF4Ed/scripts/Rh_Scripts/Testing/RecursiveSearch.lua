--[[ Test RecursiveSearch ]]--

----------------------------------------
local far = far
local F = far.Flags

----------------------------------------
-- [[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]
--------------------------------------------------------------------------------

local t = {}

local function AddItem (aItem, aName)
  if aName == nil then
    t[#t + 1] = aItem
  else
    t[aName] = aItem
  end
end --

--local flags
local flags = F.FRS_SCANSYMLINK + F.FRS_RECUR

far.RecursiveSearch("D:/Programs/Far3/Profile/plugins/LF4Ed/scripts", "_usermenu.lua", AddItem, flags)
--local t = far.RecursiveSearch("D:/Programs/Far3/Profile/plugins/LF4Ed/scripts/Rh_Scripts", "*", AddItem, flags)
--local t = far.RecursiveSearch("D:/Programs/Far2/Personals/LF4Ed/scripts", "*", AddItem, flags)
--far.Message(#t, "RecursiveSearch")
logShow(t, "RecursiveSearch")

--------------------------------------------------------------------------------
