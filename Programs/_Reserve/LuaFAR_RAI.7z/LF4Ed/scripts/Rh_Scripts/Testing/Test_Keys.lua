----------------------------------------
-- [[
local log = require "context.samples.logging"
local logShow = log.Show
local dbg = require "context.utils.useDebugs"
local dbgShow = dbg.Show
--]]

logShow(win.GetVirtualKeys())
dbgShow(win.GetVirtualKeys(), "Virtual Keys", "w")

--------------------------------------------------------------------------------
