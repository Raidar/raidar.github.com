--[[ Key utils ]]--

----------------------------------------
--[[ description:
  -- Functions for key codes handling.
  -- Функции обработки кодов клавиш.
--]]
----------------------------------------
--[[ uses:
  LuaFAR,
  Rh Utils.
  -- group: Keys.
--]]
--------------------------------------------------------------------------------
--local _G = _G

local pairs, ipairs = pairs, ipairs

----------------------------------------
local bit = bit64
local band, bor = bit.band, bit.bor
local bnot, bxor = bit.bnot, bit.bxor
local bshl, bshr = bit.lshift, bit.rshift

----------------------------------------
local context = context

local numbers = require 'context.utils.useNumbers'
local strings = require 'context.utils.useStrings'
--local utils = require 'context.utils.useUtils'
local tables = require 'context.utils.useTables'

local tfind = tables.find

----------------------------------------
local keys = require "Rh_Scripts.Utils.keyTypes"

local FKEY_Base = keys.FKEY_Base
local SKEY_Base = keys.SKEY_Base

----------------------------------------
--[[
local hex = numbers.hex

local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local unit = {} -- key utilities

-- TODO: Переделать обработку с VKey на (VKey, CState)!

---------------------------------------- SKey <--> Text
-- Полное название комбо из краткого названия.
--[[ Параметры:
  Key -- строка с кратким названием клавиши.
  ModSep -- разделитель модификаторов между собой.
  KeySep -- разделитель модификаторов и самой клавиши.
--]]
function unit.SKeyToText (Key, ModSep, KeySep) --> (string)
  ModSep = ModSep or "-"
  KeySep = KeySep or "+"
  local Vars = { L = true, R = true } -- Вариаторы модификатора
  local Sep = '%'..ModSep..'%'..KeySep

  local MKey, AKey = Key:match("([^"..Sep.."]*)["..Sep.."]([^"..Sep.."]*)")

  if not AKey then AKey = Key end -- Нет модификаторов
  if #AKey > 1 then AKey = AKey:upper() end -- :len() ?
  if not MKey then return AKey end -- Одна клавиша
  MKey = MKey:upper()

  -- Цикл по модификаторам
  local Result = ""
  local k, Len = 1, MKey:len()
  while k <= Len do
    local Mod = MKey:sub(k, k)
    if Vars[Mod] then
      k = k + 1
      if k > Len then return "" end
      Mod = Mod..MKey:sub(k, k)
    end

    Mod = keys.SKEY_Text[Mod]
    if not Mod then return "" end

    k = k + 1
    Result = Result..Mod..ModSep
  end

  return Result:sub(1, -ModSep:len() - 1)..KeySep..AKey
end ---- SKeyToText

-- Краткое название комбо из полного названия.
--[[ Параметры:
  Key -- строка с полным названием клавиши.
  ModSep -- разделитель модификаторов между собой.
  KeySep -- разделитель модификаторов и самой клавиши.
--]]
function unit.TextToSKey (Key, ModSep, KeySep) --> (string)
  ModSep, KeySep = ModSep or '-', KeySep or '+'
  local UKey = Key

  if ModSep == "" then
    ModSep = '-'
    -- Вставка отсутствующего разделителя
    for _, v in ipairs(SKEY_Base) do
      local PosB, PosE = UKey:upper():cfind(v)
      if PosB then UKey = UKey:sub(1, PosE)..'-'..UKey:sub(PosE+1) end
    end
  end

  local Sep = '%'..ModSep..'%'..KeySep
  local MKey, AKey = UKey:match("(.*)["..Sep.."]([^"..Sep.."]*)")

  if not AKey then AKey = UKey end -- Нет модификаторов
  if #AKey > 1 then AKey = AKey:upper() end -- :len() ?
  if not MKey then return AKey end -- Одна клавиша
  MKey = MKey:upper()

  -- Цикл по модификаторам
  local Result = ""
  for Value in MKey:gmatch("[^"..Sep.."]+") do
    local Mod = keys.SKEY_Mods[Value]
    if Mod then Result = Result..Mod else return "" end
  end

  return Result..KeySep..AKey
end ---- TextToSKey

---------------------------------------- Modifier
-- Разделение клавиши на модификатор и саму клавишу.
local function ModKey (FullKey, ModMask, KeyMask) --> (number, number)
  return band(FullKey, ModMask), band(FullKey, KeyMask)
end

-- Проверка флага в модификаторе.
local function ismod (mod, flag) --> (bool)
  return band(mod, flag) ~= 0
end
unit.ismod = ismod

-- Разделение клавиши VK_ на модификатор и саму клавишу.
local function ModVKey (FullKey) --> (mod, key)
  return ModKey(FullKey, keys.VKEY_ModMask, keys.VKEY_KeyMask)
end
unit.ModVKey = ModVKey

-- Разделение клавиши KEY_ на модификатор и саму клавишу.
local function ModFKey (FullKey) --> (mod, key)
  return ModKey(FullKey, keys.FKEY_ModMask, keys.FKEY_KeyMask)
end
unit.ModFKey = ModFKey

---------------------------------------- Check
-- Проверка значения v в [a; b].
local function inseg (v, a, b) --> (bool)
  return v >= a and v <= b
end

-- Проверка VK_ и KEY_ на цифру.
function unit.isKeyDigit (key) --> (bool)
  return inseg(key, 0x30, 0x39)
end

-- Проверка VK_ на "символьность".
function unit.isVKeyChar (key) --> (bool)
  return key == 0x20 or
         inseg(key, 0x30, 0x39) or
         inseg(key, 0x41, 0x5A) or
         inseg(key, 0xBA, 0xC0) or
         inseg(key, 0xDB, 0xDF) or
         key == 0xE2
end ----

-- Проверка VK_ на латинскую букву.
function unit.isVKeyLat (key) --> (bool)
  return inseg(key, 0x41, 0x5A)
end

-- Проверка VK_ на "расширенность".
function unit.isVKeyExt (key) --> (bool)
  return inseg(key, 0x10, 0x2F) or
         inseg(key, 0x5B, 0x87) or
         inseg(key, 0xA0, 0xA5) or
         inseg(key, 0xA6, 0xB7)
end

-- VK chars
unit.VKeyToChar, unit.CharToVKey = string.char, string.byte

-- Проверка KEY_ на "символьность".
function unit.isFKeyChar (key) --> (bool)
  return inseg(key, FKEY_Base.KEY_CHAR_BEGIN, FKEY_Base.KEY_CHAR_END)
end

-- Проверка KEY_ на латинскую букву.
function unit.isFKeyLatChar (key) --> (bool)
  return inseg(key, 0x41, 0x5A) or inseg(key, 0x61, 0x7A)
end

-- Проверка KEY_ на расшренную "символьность".
function unit.isFKeyExtChar (key) --> (bool)
  return inseg(key, FKEY_Base.KEY_CHAR_EXT, FKEY_Base.KEY_CHAR_END)
end

-- FK 0xFFFF chars
unit.FKeyToChar, unit.CharToFKey = strings.u8char, strings.u8byte

---------------------------------------- FKey <--> GKey
do
  local FShift = keys.FKEY_Mods.SHIFT

  local FarNameToKey = far.FarNameToKey
  local function LocNameToKey (SKey) --> (number)
    return FarNameToKey("Ctrl"..SKey)
  end --

-- Преобразование локальной клавиши в обычную.
--[[ Параметры:
  key (number) - клавиша без модификаторов.
--]]
function unit.LocToLatKey (key) --> (key | nil, key)
  if not unit.isFKeyExtChar(key) then return end

  local SKey = unit.FKeyToSKey(key)
  if SKey == "" then return end
  --logShow({ hex(key), SKey }, hex(LocNameToKey(SKey)))

  local _, CKey = unit.ModFKey(LocNameToKey(SKey))
  if CKey == -1 then return end

  -- Особый случай для неудачных преобразований:
  local _Key = unit.FKeyToSKey(CKey)
  if _Key:lower() == SKey then
    _, CKey = unit.ModFKey(LocNameToKey(SKey:upper()))
    if CKey ~= -1 then CKey = keys.AKEY_Shifts[CKey] or CKey end
  --elseif _Key:upper() == SKey then
    --_, CKey = unit.ModFKey(LocNameToKey(SKey:lower()))
    --if CKey ~= -1 then CKey = keys.AKEY_SBacks[CKey] or CKey end
  end
  if CKey == -1 then return end
  --logShow(unit.FKeyToSKey(CKey), hex(CKey))
  --logShow({ hex(key), SKey, unit.FKeyToSKey(CKey) }, hex(CKey))

  if inseg(CKey, 0x41, 0x5A) then
    --logShow(unit.FKeyToSKey(CKey), hex(CKey + (SKey:find("%u") and FShift or 0)))
    if SKey:find("%u") then return bor(FShift, CKey) end
    if SKey:find("%l") then return CKey end
  end
  --logShow(unit.FKeyToSKey(CKey), hex(CKey))

  return nil, CKey -- Дальнейшая обработка
end ---- LocToLatKey

-- Преобразование локальной буквы в латинскую.
--[[ Параметры:
  Char (string) - локальная буква.
--]]
function unit.LocToLatChar (Char) --> (char)
  local key = unit.CharToFKey(Char)
  local CKey, _ = unit.LocToLatKey(key)
  if not CKey then return Char end

  _, CKey = unit.ModFKey(CKey)
  local KChar = unit.FKeyToChar(CKey)
  if (KChar or "") == "" then return Char end
  return KChar
--[=[
  --if not unit.isFKeyExtChar(unit.CharToFKey(Char)) then return Char end

  local _, CKey = unit.ModFKey(LocNameToKey(Char))
  if CKey == -1 then return Char end
  --logShow(unit.FKeyToSKey(CKey), hex(CKey))

  local KChar = unit.FKeyToChar(CKey)
  if (KChar or "") == "" then return Char end

  if Char:find("%l") then
    return KChar:lower()
  end
  return KChar
--]=]
end ---- LocToLatChar

-- Получение нелокализованного KEY_ кода из KEY_ .
function unit.FKeyToGKey (FKey) --> (GKey)
  local mod, key = unit.ModFKey(FKey)

  if mod ~= 0 then -- С модификаторами: почти без изменений
    if key == 0x22 then return bor(mod, 0x27) end -- '"' --> "'"
    return FKey
  end

  -- Локальная буква: заглавная и строчная.
  local CKey, AKey = unit.LocToLatKey(key)
  --logShow(unit.FKeyToSKey(CKey or AKey or key), hex(CKey or AKey or key))
  if CKey then return CKey end
  if AKey then key = AKey end

  -- Символ с Shift.
  AKey = keys.AKEY_Shifts[key]
  --if AKey then logShow({ AKey = hex(AKey), SKey = unit.FKeyToSKey(AKey) }, hex(key)) end
  if AKey then return bor(FShift, AKey) end

  -- Латинская буква: заглавная и строчная.
     -- VK заглавной буквы --> Shift + 0x41..0x5A.
  if inseg(key, 0x41, 0x5A) then return bor(FShift, key) end
     -- VK строчной буквы  --> 0x41..0x5A.
  if inseg(key, 0x61, 0x7A) then return key - 0x20 end

  return key
end ---- FKeyToGKey

-- Получение KEY_ кода из нелокализованного KEY_ .
function unit.GKeyToFKey (GKey) --> (FKey)
  -- WARN: Частично: локализация невозможна!
  local mod, key = unit.ModFKey(GKey)

  -- С модификаторами (кроме Shift):
  if mod ~= 0 and mod ~= FShift then -- почти без изменений
    if key == 0x27 then return bor(mod, 0x22) end -- "'" --> '"'
    return GKey
  end -- Без изменений

  -- Локальная буква.
  -- Символ с Shift.
  if mod == FShift then
    local AKey = tfind(keys.AKEY_Shifts, key)
    if AKey then return AKey end
  end

  -- Латинская буква: заглавная и строчная.
  if inseg(key, 0x41, 0x5A) then
    -- FK заглавной буквы --> 0x41..0x5A.
    -- FK строчной буквы  --> 0x41..0x5A + 0x20.
    return mod == FShift and key or key + 0x20
  end

  return GKey
end ---- GKeyToFKey

end -- do

---------------------------------------- FKey <--> VK
do
  local KEY_FKtoVK = keys.FKEY_to_VKEY

-- Получение VK_ кода из KEY_ без модификаторов.
function unit.FKtoVK_key (FKey, FMod) --> (VKey, FMod)
  -- Спец. символ.
  local VKey = KEY_FKtoVK[FKey]
  if VKey then return VKey, FMod end

  -- Цифра / Латинская буква.
  if inseg(FKey, 0x30, 0x39) or
     inseg(FKey, 0x41, 0x5A) then return FKey, FMod end

  -- Дополнительные клавиши.
  if FKey == 0x00 then 
    -- Нажатие только модификатора:
    local key = keys.FKEY_Mod_VExts[FMod]
    --logShow({ hex(FKey), hex(FMod), hex(key) }, "FKtoVK_key")
    if key then return key, 0x00 end
    return 0x00, FMod
  end
  VKey = FKey - FKEY_Base.EXTENDED_KEY_BASE
  if unit.isVKeyExt(VKey) then return VKey, FMod end

  -- Функциональные OEM клавиши: OemXXXXX, XXXXX -- виртуальный код.
  if inseg(FKey, FKEY_Base.KEY_FKEY_BEGIN, FKEY_Base.KEY_END_FKEY) then
    VKey = FKey - FKEY_Base.KEY_FKEY_BEGIN
    if VKey < 0xFF then return VKey, FMod end
  end

  -- Мультимедийные клавиши: SpecXXXXX, XXXXX -- сканкод клавиши.
  -- TODO: Как определить сканкод? ==> Не использовать их в BreakKeys.
  if inseg(FKey, FKEY_Base.KEY_VK_0xFF_BEGIN, FKEY_Base.KEY_VK_0xFF_END) then
    VKey = FKey - FKEY_Base.KEY_VK_0xFF_BEGIN
    if VKey == 0xFF then return VKey, FMod end
  end

  return 0x00, FMod
end ---- FKtoVK_key

end -- do
do
  local KEY_VKtoFK = keys.VKEY_to_FKEY

-- Получение KEY_ кода из VK_ без модификаторов.
-- TODO: Учесть флаг ENHANCED в VMod.
function unit.VKtoFK_key (VKey, VMod) --> (FKey, VMod)
  -- Спец. символ.
  local FKey = KEY_VKtoFK[VKey]
  --logShow(hex(FKey), hex(VKey))
  if FKey then return FKey, VMod end

  -- Цифра / Латинская буква.
  if inseg(VKey, 0x30, 0x39) or
     inseg(VKey, 0x41, 0x5A) then return VKey, VMod end

  -- Дополнительные клавиши.
  if unit.isVKeyExt(VKey) then
    do -- Нажатие только модификатора:
      local mod = keys.VKEY_Ext_VMods[VKey]
      --logShow({ hex(VKey), hex(VMod), hex(mod) }, "VKtoFK_key")
      if mod then return 0x00, mod end
      --if mod then return 0x00, bor(VMod, mod) end
    end
    return VKey + FKEY_Base.EXTENDED_KEY_BASE, VMod
  end

  -- Функциональные OEM клавиши: OemXXXXX, XXXXX -- виртуальный код.
  if VKey < 0xFF then return VKey + FKEY_Base.KEY_FKEY_BEGIN, VMod end

  -- Мультимедийные клавиши: SpecXXXXX, XXXXX -- сканкод клавиши.
  -- TODO: Как определить сканкод? ==> Не использовать их в BreakKeys.
  if VKey == 0xFF then return VKey + FKEY_Base.KEY_VK_0xFF_BEGIN, VMod end

  return 0x00, VMod
end ---- VKtoFK_key

end -- do

-- Получение VK_ модификаторов из KEY_ модификаторов.
-- TODO: Учесть флаг ENHANCED в VMod.
function unit.FKtoVK_mod (FKey, FMod, VKey) --> (VMod)
  local VMod = 0x000000

  for k, v in pairs(keys.FKEY_Mods) do
    --logShow(hex(v), tostring(i)..' '..hex(KMod))
    if ismod(FMod, v) then
      local Flag = keys.VKEY_Mods[k]
      if Flag then VMod = bor(VMod, Flag) end
    end
  end

  return VMod
end ---- FKtoVK_mod

-- Получение KEY_ модификаторов из VK_ модификаторов.
function unit.VKtoFK_mod (VKey, VMod, FKey) --> (KMod)
  local KMod = 0x00000000

  for k, v in pairs(keys.VKEY_Mods) do
    if ismod(VMod, v) then
      local Flag = keys.FKEY_Mods[k]
      if Flag then KMod = bor(KMod, Flag) end
    end
  end

  return KMod
end ---- VKtoFK_mod

-- Получение VK_ кода из KEY_ .
-- TODO: Учесть новые флаги в VMod.
function unit.FKeyToVKey (FKey) --> (VKey)
  local mod, key = ModFKey( unit.FKeyToGKey(FKey) )
  --logShow(hex(mod), hex(key))

  local Vkey
  Vkey, mod = unit.FKtoVK_key(key, mod)
  --logShow(hex(mod), hex(key))
  local Vmod = unit.FKtoVK_mod(key, mod, Vkey)

  return bor(Vmod, Vkey)
end ---- FKeyToVKey

-- Получение KEY_ кода из VK_ .
-- TODO: Учесть новые флаги в VMod.
function unit.VKeyToFKey (VKey) --> (FKey)
  local mod, key = ModVKey(VKey)

  local Fkey
  Fkey, mod = unit.VKtoFK_key(key, mod)
  local Fmod = unit.VKtoFK_mod(key, mod, Fkey)

  return unit.GKeyToFKey( bor(Fmod, Fkey) )
end ---- VKeyToFKey

function unit.VModToCState (VMod) --> (CtrlState)
  return bshr(VMod, keys.VKEY_CSmod)
end ----

function unit.CStateToVMod (CtrlState) --> (VMod)
  return bshl(CtrlState, keys.VKEY_CSmod)
end ----

---------------------------------------- SKey <--> Key

-- Преобразование "строки" KEY_ клавиши в значение.
function unit.SKeyToFKey (Key) --> (number)
  local Keys = keys.FKEY_Keys

  local SMod, SKey = Key:match("([^+]*)[+]([^+]*)")

  if Key == '+' then SKey = Key       -- Клавиша '+'
  elseif not SKey then SKey = Key end -- Нет модификаторов

  local FKey = Keys[SKey] or unit.CharToFKey(SKey) or 0x00
  if (SMod or "") == "" then return FKey end -- Одна клавиша
  SMod = SMod:upper()

  local FMod = 0x00 -- Цикл по модификаторам
  for k, v in pairs(keys.FKEY_Mods) do
    if keys.SKEY_Mods[k] and
       SMod:find(keys.SKEY_Mods[k], 1, true) then
      FMod = bor(FMod, v)
    end
  end

  return bor(FMod, FKey)
end ---- unit.SKeyToFKey

-- Преобразование значения KEY_ клавиши в "строку".
function unit.FKeyToSKey (Key) --> (string)
  local Keys, SKey = keys.FKEY_Keys

  local FMod, FKey = ModFKey(Key)

  if unit.isFKeyChar(FKey) then SKey = unit.FKeyToChar(FKey) end
  --logShow(hex(FKey), SKey)

  if not SKey or (" \008\009"):find(SKey, 1, true) then
  --if not SKey or (" \[\],\".\\\:/\008\009"):find(SKey, 1, true) then
    SKey = tfind(Keys, FKey) or ""
  end
  if FMod == 0 then return SKey end -- Одна клавиша

  local SMod = "" -- Цикл по модификаторам
  for k, v in pairs(keys.FKEY_Mods) do
    if keys.SKEY_Mods[k] and ismod(FMod, v) then
      --logShow(hex(FMod), SMod)
      SMod = SMod..keys.SKEY_Mods[k]
    end
  end

  return SMod..'+'..SKey
end ---- unit.FKeyToSKey

local SShift = keys.SKEY_Mods.SHIFT

-- Преобразование "строки" VK_ клавиши в значение.
function unit.SKeyToVKey (Key) --> (number)
  local Keys = keys.VKEY_Keys

  local SMod, SKey = Key:match("([^+]*)[+]([^+]*)")
  --logShow((SMod or "")..'\n'..(SKey or ""), Key)

  if not SKey then SKey = Key end -- Нет модификаторов

  local _Key = keys.KSYM_Mods[SKey]
  if _Key then -- Особые клавиши-символы:
    if _Key > 0 then
      SKey = keys.SKEY_Shifts[SKey]
      if not SMod:find(SShift, 1, true) then SMod = SMod..SShift end
    end
    SKey = keys.KSYM_VKeys[SKey] or SKey
  end

  local VKey = Keys[SKey] or unit.CharToVKey(SKey) or 0x00
  if (SMod or "") == "" then return VKey end -- Одна клавиша
  SMod = SMod:upper()

  local VMod = 0x00 -- Цикл по модификаторам
  for k, v in pairs(keys.VKEY_Mods) do
    if keys.SKEY_Mods[k] and
       SMod:find(keys.SKEY_Mods[k], 1, true) then
      VMod = bor(VMod, v)
    end
  end
  --logShow({ hex(VMod), hex(VKey) }, Key)

  return bor(VMod, VKey)
end ---- SKeyToVKey

-- Преобразование значения VK_ клавиши в "строку".
function unit.VKeyToSKey (Key) --> (string)
  local Keys, SKey = keys.VKEY_Keys

  local VMod, VKey = ModVKey(Key)

  if inseg(VKey, 0x30, 0x39) or inseg(VKey, 0x41, 0x5A) then
    SKey = unit.VKeyToChar(VKey)
  end
  if not SKey then SKey = tfind(Keys, VKey) or "" end
  if VMod == 0 then return SKey end -- Одна клавиша

  local SMod = "" -- Цикл по модификаторам
  for k, v in pairs(keys.VKEY_Mods) do
    if keys.SKEY_Mods[k] and ismod(VMod, v) then
      --logShow(hex(VMod), SMod)
      SMod = SMod..keys.SKEY_Mods[k]
    end
  end

  return SMod..'+'..SKey
end ---- VKeyToSKey

--------------------------------------------------------------------------------
return unit
--------------------------------------------------------------------------------
