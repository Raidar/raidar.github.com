-- Shmuel Zeigerman <shmuz@013net.net>
-- Попробовал поиграться с меню, сразу наткнулся на несколько дефектов.
-- Привожу их в виде трёх тестов. Сравнивать можно с far.Menu.

--------------------------------------------------------------------------------
--local _G = _G

local Menu = require "Rh_Scripts.RMenu.RectMenu"

--------------------------------------------------------------------------------
local items, shared

-- test 0: Ошибок быть не должно -- FIXED
Menu({}, {})
--far.Menu({}, {})

-- test 1: Плохая отрисовка рамки -- FIXED
Menu({Title="Menu 1"}, {{text="abc"}})
--far.Menu({Title="Menu"}, {{text="abc"}})

-- test 2: Непонятные подчёркивания в первом пункте меню. -- this is DEBUG
Menu({Title="Menu 2"}, {{text="abc"}, {text="abcdef"}})
far.Menu({Title="Menu"}, {{text="abc"}, {text="abcdef"}})

-- test 3: Отличия от far.Menu (не баги, но всё-таки ...)
-- - меньшая высота меню (видно 15 пунктов; в far.Menu - 19) -- FIXED
-- - один пробел слева (в far.Menu - два) -- CHANGED / FIXED
-- - скроллбар расположен внутри рамки (в far.Menu - на рамке) -- CHANGED
-- - нестандартная реакция на клавиши End и Home -- FIXED
-- [[
items = {}
for k=1,50 do items[k] = {text="item3 ".. k} end
Menu({}, items)
--far.Menu({}, items)

items = {}
for k=1,3 do items[k] = {text="item_checked ".. k, checked = true} end
Menu({}, items)
--far.Menu({}, items)
--]]

-- test 4: Все пункты "выбраны" одновременно (баг). -- FIXED
-- [[
items = {}
shared = {text="hello 4"}
for k=1,3 do items[k] = shared end
Menu({}, items)
--far.Menu({}, items)
--]]

-- test 5: Плохое позиционирование -- FIXED
Menu({Title="Menu 5", SelectIndex = 0}, {{text="abc"}})
--far.Menu({Title="Menu 5", SelectIndex = 0}, {{text="abc"}})

-- test 6: Нет ни одного доступного пункта. -- FIXED
-- [[
items = {}
shared = {text="hello 6", separator = true}
for k=1,3 do items[k] = shared end
Menu({}, items)
--far.Menu({}, items)
--]]
--------------------------------------------------------------------------------
