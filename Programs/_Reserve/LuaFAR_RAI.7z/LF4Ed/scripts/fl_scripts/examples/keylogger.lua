local far2dialog=require 'far2.dialog'

local flags=far.Flags
local width=80

local diDat = (far.LuafarVersion(true)) == 3 and 11 or 10

local items = far2dialog.NewDialog()
items._        = { "DI_DOUBLEBOX",    3,1, width+6, 5, 0,0,0,0, "Key logger" }
items.dec      = { "DI_TEXT",         4,3,0,3,         0,0,0,0, ''          }

local str = ''
local function dlg_handler (handle, msg, p1, p2)
    if msg == flags.DN_CONTROLINPUT then
        local VirKey = far.ParseInput(p2) -- FAR23
        if not VirKey then return end

        local key = far.InputRecordToName(VirKey) or ""
        str = str..' '..key
        items.dec[diDat] = str:sub(-width)
        far.SetDlgItem(handle, 1, items.dec)

        if key == 'Esc' then
          far.SendDlgMessage(handle, flags.DM_CLOSE, p2)
        end
    end
end

local Guid = win.Uuid("22b07e07-c09f-4a0a-864a-8523f3a1c5ce")
local function keylogger ()
    far.Dialog(Guid, 2,5, 2+width+8,11, nil, items, 0, dlg_handler)
end

keylogger()
