//@@ filename=far.EditorGetInfo().FileName:match('.+[/\\]([^%.]+)')
#include "@@return filename@@.h"

//______________________________________________________________________________
@@return filename@@::@@return filename@@(){
    @@here()@@

}

//______________________________________________________________________________
@@return filename@@::~@@return filename@@(){


}
