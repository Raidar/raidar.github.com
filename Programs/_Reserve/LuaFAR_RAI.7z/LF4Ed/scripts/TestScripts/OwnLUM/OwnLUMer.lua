--[[ OwnLUM settings ]]--
--[[ ����ன�� OwnLUM ]]--

--------------------------------------------------------------------------------
local LUM_Path = "scripts\\TestScripts\\OwnLUM\\"

local DefData = {
  Basic = {
    LuaUMName = "OwnLUM",
    LuaUMPath = LUM_Path,
  }, -- Basic
  Files = {
    FilesPath = LUM_Path,
    MenusFile = "LumBinds.lua",
    MenusPath = LUM_Path,
    LuaScPath = LUM_Path,
  }, -- Files
  UMenu = {
    MenuTitleBind = true,
    CompoundTitle = false,
    BottomHotKeys = false,
    CaptAlignText = true,
    TextNamedKeys = false,
    FullNamedKeys = false,
    ShowErrorMsgs = false,
    --ShowErrorMsgs = true,
    ReturnToUMenu = false,
    --ReturnToUMenu = true,
  }, -- UMenu
} -- DefData

return require("Rh_Scripts.LuaUM.LumCfg").Configure(DefData)
--------------------------------------------------------------------------------
