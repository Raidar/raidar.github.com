--[[ Macros testing ]]
--[[ ������������ �������� ]]

--[[ uses:
  LuaFAR,
  Rh Utils.
--]]
--------------------------------------------------------------------------------
--[[ Used modules and locals ]]--

--local luaUt = require "Rh_Scripts.Utils.LuaUtils"
--local farUt = require "Rh_Scripts.Utils.FarUtils"
local macUt = require "Rh_Scripts.Utils.Macro"

----------------------------------------
-- [[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local Run = macUt.Run
--[[ �������� ������� ]]--
function TestMacroTPL (args)
  Text = args[1]
  assert(Text and Text ~= "")
  local Macro = Run.Make(Text)
  logShow(Macro, Text)

  return Run.Play(Macro)
end ----

--------------------------------------------------------------------------------
