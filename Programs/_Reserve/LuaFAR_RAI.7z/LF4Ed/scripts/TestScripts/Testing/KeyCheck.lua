--[[ ������ � ��������� ]]

--------------------------------------------------------------------------------
--[[ Used modules and locals ]]--

local luaUt = require "Rh_Scripts.Utils.luaUtils"
--local farUt = require "Rh_Scripts.Utils.farUtils"
--local rhbnd = require "Rh_Scripts.Utils.BindUtil"
--local rhutl = require "Rh_Scripts.Utils.Rh_Utils"
local keyUt = require "Rh_Scripts.Utils.KeyUtils"

local far_Msg = far.Message

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local SKeyToName = keyUt.SKeyToName
local NameToSKey = keyUt.NameToSKey

--[[ �������� ������� �������� �����-������� ]]--
function CheckStrKey()
  local SStrs = {  "", "a", "A", "C+", "C+A",
    "CS+a", "LC+a", "LCS+A", "LCRS+A", "LCRS+a" }
  local LStrs = {  "", "a", "A", "Ctrl-", "Ctrl-A",
    "Ctrl-Shift+a", "LCtrl+A", "LCtrl-Shift+A", "LCtrl-RShift+A" }
  local XStrs = {  "", "a", "A", "Ctrl", "CtrlA",
    "CtrlShiftA", "LCtrlA", "LCtrlShiftA", "LCtrlRShiftA" }
  local Msg = ""
  for i, s in ipairs(SStrs) do
    --[[local MKey, AKey = s:match("([^+]*)+([^+]*)")
    Msg = Msg..tostring(i)..": "..s.." = "..
          tostring(MKey).."|"..tostring(AKey).."\n"--]]
    Msg = Msg..tostring(i)..": "..s.." = "..SKeyToName(s).."\n"
  end
  far_Msg(Msg, "Str to Text Key Parse", nil, 'l')
  local Msg = ""
  for i, s in ipairs(LStrs) do
    Msg = Msg..tostring(i)..": "..s.." = "..NameToSKey(s).."\n"
  end
  far_Msg(Msg, "Text to Str Key Parse", nil, 'l')
  local Msg = ""
  for i, s in ipairs(XStrs) do
    Msg = Msg..tostring(i)..": "..s.." = "..NameToSKey(s,"").."\n"
  end
  far_Msg(Msg, "NoSep Text to Str Key Parse", nil, 'l')
  return
end ---- CheckStrKey

--[[ �������� ConvertHotKey ] ]--
function CheckCvtHotKey()
  local Strs = {
    -- ����������
    "A", "Ctrl+A", "Alt+A", "Shift+A",
    "Ctrl+Shift+A", "Ctrl+Alt+A", "Alt+Shift+A",
    "Ctrl+Alt+Shift+A",
    -- ������������
    "", "A+B", "A+Ctrl", "Ctrl" }
  local Msg = ""
  for i, s in ipairs(Strs) do
    Msg = Msg..tostring(i)..": "..s.." = "..
          tostring(rhplg.ConvertUserHotkey(s)).."\n"
  end
  return far_Msg(Msg, "HotKey Convert", nil, 'l')
end ---- CheckCvtHotKey
--]]

--------------------------------------------------------------------------------
--logShow({...}, "...", 1)
local args = { ... }
--local args = select(1, ...)
return getfenv()[args[1]](args[2])
--------------------------------------------------------------------------------
