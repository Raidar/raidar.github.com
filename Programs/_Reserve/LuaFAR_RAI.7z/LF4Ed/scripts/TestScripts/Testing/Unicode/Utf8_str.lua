
----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local vstring = far.LuafarVersion(true) < 2 and string or unicode.utf8
if far.LuafarVersion(true) < 2 then
  unicode = { utf8 = string }
end

--string = vstring
--string.sub = vstring.sub
--for k, v in pairs(vstring) do string[k] = v end -- for

--local stringMT = debug.getmetatable(string)

--logShow(string, tostring(string == vstring), 1)
--logShow(string, tostring(string.sub == vstring.sub), 1)
--logShow(stringMT, "string MT", 1)
--logShow(unicode.utf8, "unicode utf8", 1)

debug.setmetatable("", { __index = unicode.utf8 })
--------------------------------------------------------------------------------
--module(...)

--------------------------------------------------------------------------------
--local s = "Проверка"
local s = require "Rh_Scripts.Testing.OEM_file"

local t = {
  s:sub(1, 3),
  string.sub(s, 1, 3),
  unicode.utf8.sub(s, 1, 3),
  vstring.sub(s, 1, 3),
} --- t

far.Message(table.concat(t, '\n'), "Test Unicode string")

--------------------------------------------------------------------------------
