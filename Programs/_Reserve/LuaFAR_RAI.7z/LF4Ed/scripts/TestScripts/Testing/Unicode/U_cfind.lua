--[[ Selene Unicode ]]--
--[[ �஢�ઠ cfind ]]--

local Def = far.String.OemToUtf8

local farMsg = far.Message

--------------------------------------------------------------------------------

-- Add function unicode.utf8.cfind:
-- same as find, but offsets are in characters rather than bytes
local usub, ssub = unicode.utf8.sub, string.sub
local ulen, slen = unicode.utf8.len, string.len
local ufind = unicode.utf8.find
local cfind = function (s, patt, init, plain)
  init = init and slen(usub(s, 1, init-1)) + 1
  local t = { ufind(s, patt, init, plain) }
  if t[1] == nil then return nil end
  return ulen(ssub(s, 1, t[1]-1)) + 1, ulen(ssub(s, 1, t[2])), unpack(t, 3)
end

local s = Def"�஢�ઠ �㭪樨 1: cfind"
--local ss = "%w%s"
--local ss = "%c"

local ss = Def"�㭪樨"
--farMsg(usub(s, 1, 0), "usub")
farMsg(cfind(s, ss, 1, true), ss)
ss = Def"�஢�ઠ"
farMsg(cfind(s, ss, 1, true), ss)
ss = Def"��ઠ"
farMsg(cfind(s, ss, 1, true), ss)
--ss = "%w%s"
ss = Def"%w�"
farMsg(cfind(s, ss), ss)
ss = "%c"
farMsg(cfind(s, ss), ss)
ss = "%p"
farMsg(cfind(s, ss), ss)
--farMsg("'"..ssub(s, 1, 0).."'", "ssub")

--------------------------------------------------------------------------------
