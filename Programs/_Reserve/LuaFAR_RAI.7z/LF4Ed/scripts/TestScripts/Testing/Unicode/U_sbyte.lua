--[[ Selene Unicode ]]--
--[[ �����⭮� �।�⠢����� ]]--

local Def = win.OemToUtf8

local sbyte = string.byte

----------------------------------------
-- [[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local s, ss = "", ""

s = Def"��ॢ��"
ss = Def"[��]"

local us = win.Utf8ToUtf16(s)
local uss = win.Utf8ToUtf16(ss)

local t = {
  s = s,
  ss = ss,
  s_8 = { sbyte(s, 1, -1) },
  ss_8 = { sbyte(ss, 1, -1) },
  s_16 = { sbyte(us, 1, -1) },
  ss_16 = { sbyte(uss, 1, -1) },
} --- t

logShow(t, ss, "d2 x2")

--------------------------------------------------------------------------------
