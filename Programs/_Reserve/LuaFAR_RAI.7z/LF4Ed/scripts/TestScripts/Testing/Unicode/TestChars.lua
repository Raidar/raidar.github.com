--[[ Selene Unicode ]]--
--[[ Проверка символов ]]--

----------------------------------------
-- [[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local t = {
  "te&xt...",
  "te&xt…",
  "`",
  "~",
} ---

--far.Message(table.concat(t, '\n'), "concat")

--logShow(table.concat(t, '\n'), "concat")

far.Show(unpack(t))

local Props = { Title = "Check chars" }

local Items = {} ---

for k=1, #t do
  Items[#Items+1] = { text = t[k] }
end --

far.Menu(Props, Items)

--------------------------------------------------------------------------------
