--[[ Работа с LuaFAR ]]

--------------------------------------------------------------------------------
--[[ Used modules and locals ]]--

local luaUt = require "Rh_Scripts.Utils.luaUtils"
local farUt = require "Rh_Scripts.Utils.farUtils"

local far_Msg = far.Message

----------------------------------------
-- [[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
--[[ Проверка горячей буквы в тексте ]]--
function CheckHotChar()
  local Strs = {
    "", "Text", "&Text", "T&ext", "Tex&t", "Text&",
    "&", "&&", "&&Text", "T&&ext", "Tex&&t", "Text&&",
    "&&&", "&&&Text", "T&&&ext", "Tex&&&t", "Text&&&",
    "&&&&", "&&&&Text", "T&&&&ext", "Tex&&&&t", "Text&&&&",
    "&&&&&", "&&&&&Text", "T&&&&&ext", "Tex&&&&&t", "Text&&&&&",
    "_", "Te xt", "&Te xt", "T&e xt", "Te &xt", "Te x&t", "Te xt&",
    "&Hello, world!", "Пример &Hello, world!", "Example &Hello, world!",
  }
  local Len = #Strs
  local Msg, Msg1 = "", ""
  local Result
  for i, s in ipairs(Strs) do
    local TextB, TextH, TextE = farUt.ParseHotText(s)
    --local TextB, TextH, TextE = s:match("([^&]*)&([^&])([^&]*)")
    --local TextB, TextH, TextE = s:match("([^&]*)&(.)([^&]*)")
    Msg = Msg..tostring(i)..": "..s.." = "..
          tostring(TextB).."|"..
          tostring(TextH).."|"..
          tostring(TextE).."\n"
    if i == math.ceil(Len / 2) then Msg1, Msg = Msg, "" end
  end
  local Msg2 = Msg
  far_Msg(Msg1, "Hot Char 1", nil, 'l')
  far_Msg(Msg2, "Hot Char 2", nil, 'l')
  return true
end ---- CheckHotChar

--[[ Флаги LuaFAR ]]--
function CheckLuaFarFlags()
  logShow(far.Flags, "LuaFAR Flags")
end ---- CheckLuaFarFlags

--[[ FAR Language ]]--
function CheckFarLanguage()
  logShow(farUt.Language(), "FAR Language")
end ---- CheckFarLanguage

--[[ Palette Color ]]--
function CheckPaletteColor()
  local ColorIndex = 0
  logShow(farUt.IndexColor(ColorIndex), "Color #: "..ColorIndex)
end ---- CheckPaletteColor

--[[ CPluginStartupInfo ] ]--
function CheckCPluginStartupInfo()
  local Info = far.CPluginStartupInfo()
  local s = Info.FARSTANDARDFUNCTIONS
  logShow(tostring(Info), "CPluginStartupInfo")
end ---- CheckCPluginStartupInfo
--]]

--------------------------------------------------------------------------------
local args = ...
--local args = select(1, ...)
return getfenv()[args[1]](args[2])
--------------------------------------------------------------------------------
