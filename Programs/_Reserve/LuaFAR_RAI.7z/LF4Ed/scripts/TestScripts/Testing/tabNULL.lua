--[[ ����� � ���⮩ ⠡��楩 ]]--
--------------------------------------------------------------------------------

----------------------------------------
local tNULL = luaUt.tNULL

----------------------------------------
local luaUt = require "Rh_Scripts.Utils.luaUtils"

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
--logShow(tNULL, "tNULL")
--logShow(tNULL.value, "tNULL.value")
--tNULL.value = "value"
logShow(getmetatable(tNULL), "tNULL mt")

--------------------------------------------------------------------------------
