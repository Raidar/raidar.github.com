--[[ ������ � Lua ]]

local luaUt = require "Rh_Scripts.Utils.luaUtils"
--local farUt = require "Rh_Scripts.Utils.farUtils"

local far_Msg = far.Message

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
--[[ ���������� ���������: _G ]]--
function CheckLuaGlobal()
  local Msg = ""
  for n in pairs(_G) do Msg = Msg..'\n'..tostring(n) end
  far_Msg(Msg, "Global Env _G", nil, 'l')
end ---- CheckLuaGlobal

--[[ ���� Lua � package ]]--
function CheckLuaPathes()
  local Msg = "Path:\n"..tostring(package.path).."\n\n"..
             "CPath:\n"..tostring(package.cpath)
  far_Msg(Msg, "package Pathes", nil, 'l')
end ---- CheckLuaPathes

--[[ ���������� Far ]]
function CheckLuaFar()
  local Msg = ""
  for n in pairs(_G.far) do Msg = Msg..'\n'..tostring(n) end
  far_Msg(Msg, "far package", nil, 'l')
end ---- CheckLuaFar

local hex = luaUt.hex

--[[ CIO Lib ]]--
function CheckCIO_Lib()
  local cio = require "cio"
  --logShow(cio, "CIO", 1)
  --logShow(cio.title(), "Title")
  --logShow(cio.inputcp(), "Input CP")
  --logShow(cio.outputcp(), "Output CP")
  --local HiV, LoV = cio.kblayout()
  --logShow(hex(HiV)..'\n'..hex(LoV), "KB Layout")
  logShow(hex(cio.kblayout()), "KB Layout")
  --logShow(cio.kblayoutname(), "KB Layout Name")
  --logShow(cio.windowrect(), "Win Rect")
  --logShow(cio.maxwindow(), "Max Win")
  --logShow(cio.buffersize(), "Buffer Size")
  --cio.writeln("cd ..")
end ---- CheckCIO_Lib

function StrIndex (Str, Index)
  return Str:sub(Index, Index)
end

--[[ String as table ]]--
function CheckStringAsTable()
  local Str = "abcdefgh"
  local mt = getmetatable(Str)
  --logShow(mt, Str, 1)
  --setmetatable(mt, { __index = StrIndex })
  --logShow(mt, Str, 1)
  --logShow(getmetatable(mt), Str, 1)
  --setmetatable(string, mt)
  --logShow(Str[1], Str)
end ---- CheckStringAsTable

--[[ Dir List ] ]--
function CheckDirList()
  enh.AddLuaFarMenus("scripts/", {})
  --enh.AddLuaFarMenus("scripts/Rh_Scripts/", {})
end ---- CheckDirList
--]]

--------------------------------------------------------------------------------
--logShow({...}, "...", 1)
--[[
local call = ...
logShow(loadstring(call), "...")
logShow(getfenv(1), "getfenv(1)", "d2 _")
if call then
  Env = setfenv(loadstring(call), getfenv(1))
  logShow(Env, "Env", "d2 _")
end
--]]

local args = { ... }
--local args = select(1, ...)
return getfenv()[args[1]](args[2])
--------------------------------------------------------------------------------
