local Menu = far.Menu

local Items = {
  { text="&User Menu" },
  { text="&Other Menu" },
  { text="&Test Menu" },
  { text="Additional &Menu" },
} -- Items

Menu({Title="Menu Block"}, Items)
--------------------------------------------------------------------------------
