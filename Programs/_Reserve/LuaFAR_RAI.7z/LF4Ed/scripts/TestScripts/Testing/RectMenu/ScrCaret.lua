--[[ �������� ������ ScrollCaret ]]--

--------------------------------------------------------------------------------
local _G = _G

local luaUt = require "Rh_Scripts.Utils.luaUtils"
local farUt = require "Rh_Scripts.Utils.farUtils"

local max2, min2 = luaUt.max2, luaUt.min2
local divf, divr = luaUt.divf, luaUt.divr

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
-- ������ ���������� ������� ���������.
local function ScrollCaret (ALen, Cat, Count) --> (Pos, Len)
  local Len = divr(ALen, Count)
  Len = max2(1, Len)
  local Pos = divr(ALen * (Cat - 1), Count) + 1
  Pos = min2(ALen, Pos)
  if Count > 1 then Len = min2(Len, ALen - Pos + 1) end
  --logShow(tostring(Pos)..'\n'..tostring(Len),
  --        tostring(Cat)..' / '..tostring(Count)..' : '..tostring(ALen))
  return Pos, Len, Pos + Len - 1
end -- ScrollCaret

local Pos_Fmt = "%#2d => %#2d: "
local Car_Fmt = "<%#2d |%#2d| %#2d>"

local function CheckCaret (ALen, Count)
  local t = { Count = Count }
  local cPos, cLen, cEnd
  for Cat = 1, Count do
    cPos, cLen, cEnd = ScrollCaret(ALen, Cat, Count)
    t[#t+1] = Pos_Fmt:format(cPos, Cat)..
              Car_Fmt:format(ScrollCaret(ALen, Cat, Count))
  end
  return t
end -- CheckCaret

local function CheckCaretInfo ()
  local ALen = 13
  --local ALen = 58
  --local ALen = 80
  --local ALen = 88
  local t
  --local ALen, Count = 80, 2
  --local t = CheckCaret(ALen, Count)
  --logShow(t, "CheckCaret")
  local flog = dbg.open("ScrCaret.txt")
  --flog:log(table.concat(Msg, '\n'))
  flog:logtab({ ALen = ALen })
  for Count = 1, 20 do
    t = CheckCaret(ALen, Count)
    flog:logtab(t, "\nScroll Caret", 2, "q")
  end
  flog:close()
end -- CheckCaretInfo

--------------------------------------------------------------------------------
return CheckCaretInfo()
--------------------------------------------------------------------------------
