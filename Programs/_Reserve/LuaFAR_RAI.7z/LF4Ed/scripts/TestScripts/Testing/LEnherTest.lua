--[[ �������� lenher.dll ]]

--------------------------------------------------------------------------------
--[[ Used modules and locals ]]--

local lenher = require "lenher"

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
--[[ �������� createtable ]]--

local function createtable (narr, nrec)
  return lenher.createtable(narr, nrec)
--[[
  return loadstring("return {"..
                    ("nil,"):rep(narr)..
                    ("[0] = nil,"):rep(nrec).."}")()
--]]
end ---- createtable

function TestCreateTable ()
  local t = createtable(3, 0)
  logShow({ t }, "empty table #: "..#t)
  --logShow({ t }, "empty table #: "..tostring(#t))
  t[1] = 1
  t[2] = "string"
  t[3] = "true"
  logShow(t, "filled table #: "..#t)
end ---- TestCreateTable

return TestCreateTable()
--------------------------------------------------------------------------------
