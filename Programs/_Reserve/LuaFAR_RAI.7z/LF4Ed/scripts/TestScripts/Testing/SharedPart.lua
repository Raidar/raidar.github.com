--[[ ���� ��饩 ��� ���� ��ப ]]--

----------------------------------------
-- [[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local s1 = "abcdefgh"
local s2 = "abcxyz"
local CharEnum = "%w_"
local WordCharsSet = ("[%s]") :format(CharEnum)
local WordSeparSet = ("[^%s]"):format(CharEnum)

local Pattern = ("^(%s+)%s*\n%%1%s*"):format(WordCharsSet, WordCharsSet, WordCharsSet)
--local Pattern = ("^(%s+)%s*%%z%%1%s*"):format(WordCharsSet, WordCharsSet, WordCharsSet)

local t = {
  s1 = s1,
  s2 = s2,
  --res = { (s1..'\000'..s2):find(Pattern) },
  --res = { (s1..'\000'..s2):match(Pattern) },
  res = { (s1..'\n'..s2):match(Pattern) },

} ---

--logShow(t, "Common Parts")
--------------------------------------------------------------------------------
