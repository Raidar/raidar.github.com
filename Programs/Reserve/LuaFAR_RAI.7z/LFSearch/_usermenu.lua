--[[ Menu Extending ]]--

lfsearch.SetDebugMode(1)

----------------------------------------
-- Add LuaFAR context features first only!!!
--require "context.initiate"               -- LFc initiate
--MakeResident(require "context.resident") -- LFc resident

----------------------------------------
--[[
AddCommand("test", "scripts/selftest", "far", "lua")

AddToMenu ("e", "5. Self-test", nil, "scripts/selftest", "far", "lua")
AddToMenu ("e", ":sep:User scripts")
AddToMenu ("e", "URLs", nil, "scripts/presets", "url")
AddToMenu ("e", "Credit Card numbers", nil, "scripts/presets", "creditcard")
--]]

----------------------------------------
local DataFile = "scripts/Rh_Presets/Rh_Presets"
local Data = require "scripts.Rh_Presets.Rh_Presets"
--far.Show(unpack(Data))
--far.Show(Data[21].key, Data[22].key, Data[23].key, Data[24].key)
--far.Show(Data[1].name, Data[2].name, Data[3].name, Data[4].name, Data[5].name)

AddToMenu(":sep:Rh Presets")

for k = 1, #Data do
  local t = Data[k]
  AddToMenu(t.area or "e", t.text, t.key, DataFile, t.name)
end
----------------------------------------

--AddCommand("test", "scripts/selftest", {"far","lua","oniguruma","pcre"})

--------------------------------------------------------------------------------
