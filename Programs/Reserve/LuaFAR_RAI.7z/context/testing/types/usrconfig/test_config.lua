
return {
    cfg_policy = 'extend', -- update|extend|asmeta|none
    field2 = '2a',
    field3 = '3a',
    field4 = '4a'
} --
