--[[ lfa_config ]]--

--------------------------------------------------------------------------------

----------------------------------------
local context = context
--local context, ctxdata = context, ctxdata

--------------------------------------------------------------------------------
local lfa_config = context.use.lfa_config

-- Установка параметров редактора при смене типа файла.
function lfa_config.changeParameters (newtype, flag)
  if not flag then return end
  lfa_config.setEditorParameters(true)
end

---------------------------------------- main
local args = (...)
if type(args) ~= 'table' then args = {} end

local arg = args[1]
if arg == 'chooseCurrentType' then
  context.manage.chooseCurrentType()
end
--------------------------------------------------------------------------------
