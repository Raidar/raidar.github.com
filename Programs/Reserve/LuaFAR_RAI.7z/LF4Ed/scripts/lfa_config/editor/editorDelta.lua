--[[ lfa_config ]]--

--------------------------------------------------------------------------------

----------------------------------------
local F = far.Flags

----------------------------------------
local context = context
--local context, ctxdata = context, ctxdata

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local lfa_config = context.use.lfa_config

local function max2 (x, y) --> (number)
  return y <= x and x or y
end

local far_AdvControl = far.AdvControl

function lfa_config.editorGetDelta (Info)
  local Info = Info or editor.GetInfo()

  local Rect = far_AdvControl(F.ACTL_GETFARRECT)
  local CurPos = far_AdvControl(F.ACTL_GETCURSORPOS)

  local Result = {
    Rect = Rect,
    Cursor = CurPos,
    DPosX = max2(CurPos.X - (Info.CurTabPos - Info.LeftPos), 0),
    DPosY = max2(CurPos.Y - (Info.CurLine - Info.TopScreenLine), 0),
    --DPosY = CurPos.Y - (Info.CurLine - Info.TopScreenLine),

    DSizeX = max2(Rect.Right - Rect.Left + 1 - Info.WindowSizeX, 0),
    DSizeY = max2(Rect.Bottom - Rect.Top + 1 - Info.WindowSizeY, 0),
    --DSizeY = Rect.Bottom - Rect.Top + 1 - Info.WindowSizeY,
  } ---
  Result.EPosX = max2(Result.DSizeX - Result.DPosX, 0)
  Result.EPosY = max2(Result.DSizeY - Result.DPosY, 0)

  --logShow({ DPos = { DPosX, DPosY }, DSize = { DSizeX, DSizeY } }, "Delta")

  return Result
end ---- editorGetDelta
--------------------------------------------------------------------------------
