--[[ lfa_config ]]--

----------------------------------------
--[[ description:
  -- Editor vision configuration.
  -- Конфигурация вида редактора.
--]]
----------------------------------------
--[[ uses:
  nil.
  -- group: Config, Datas.
--]]
--------------------------------------------------------------------------------
local cfg = {
  --_meta_ = { basis = 'user', merge = 'none' },
  --_meta_ = { basis = 'user', merge = 'asmeta' },
  _meta_ = { basis = 'user', merge = 'expand' },
  --_meta_ = { basis = 'user', merge = 'update' },

  default = {
    --ShowLineNumbers = false, -- DEBUG
    --ShowBookmarks = false, -- DEBUG
    EmphInterval = 10,

    BookmarkText = '▻ $bm',

    Color         = 'gray on black',
    EmphColor     = 'silver on black',
    FillColor     = 'silver on cyan',
    --BookmarkColor = 'pink on black',
    BookmarkColor = 'green on black',

    ShowRightMargin   = true,
    RightMarginPos    = 81,
    TextCoversMargin  = true,
    RightMarginColor  = 'gray on black',

    ShowEndOfLine     = false,
    --ShowEndOfLine     = true,
    ShowEndOfFile     = true,
    --ShowLastLine      = false,
    ShowLastMargin    = true,
    --EndOfLineColor    = 'silver on land',
    EndOfLineColor    = 'silver on black',
    EndOfFileColor    = 'silver on maroon',
    LastLineColor     = 'silver on black',
    LastMarginColor   = 'silver on black',
  }, --
  none = { inherit = 'default' },

  --text = {},

  --plain = {},

  sub_assa = {
    RightMarginPos = 100,
  },

  --source = {
    --Color     = 'gray on blue',
    --EmphColor = 'white on blue',
  --},

  --pascal = {},
--[[
  packed = {
    ShowRightMargin = false,

    ShowEndOfLine   = false,
    ShowEndOfFile   = false,
    ShowLastLine    = false,
    ShowLastMargin  = false,
  },

  mixed = {
    ShowRightMargin = false,

    ShowEndOfLine   = false,
    ShowEndOfFile   = false,
    ShowLastLine    = false,
    ShowLastMargin  = false,
  },
--]]

} --- cfg

return cfg
--------------------------------------------------------------------------------
