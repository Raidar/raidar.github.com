--[[ lfa_config ]]--

----------------------------------------
--[[ description:
  -- Editor configuration.
  -- Конфигурация редактора.
--]]
----------------------------------------
--[[ uses:
  nil.
  -- group: Config, Datas.
--]]
--------------------------------------------------------------------------------
--[=[
Options:
    Quit = true,               -- close editor (true/false)
    AutoIndent = true,         -- use AutoIndent or not (true/false)
    CharCodeBase = 'oct',      -- 'oct'/'dec'/'hex' (string)
    CodePage = 'utf8',         -- codepage number or shortname (number or string, 'utf8'/'utf16le'/'utf18be'/'ansi'/'oem'/'koi8r'/'7bit')
    SetBom = true,             -- write/not write BOM when saving in utf/unicode (true/false)
    NewFileEOL = 'win'         -- EOL symbol for the new file (string, 'win'/'unix'/'mac')
                               -- win for '\r\n'
                               -- unix for '\n'
                               -- mac for '\r'
    CursorBeyondEOL = false,   -- allow cursor to be beyond the EOL (true/false)
    ExpandTabs = 'no',         -- expand tabs (string, 'no'/'new'/'all')
    Lock = true,               -- lock editor, forbid modification (true/false)
    SavePosition = false,      -- save file position (true/false)
    ShowWhiteSpace=true,       -- Turn on/off whitespace (true/false)
    TabSize = 10,              -- tab size (number)
    WordDiv = [[!%^&*()+|{}:"<>?`-=\[];',./~@]], -- set word div (string)
                               -- ATTENTION: use [[ and ]] instead of " and " to avoid escape sequences
    AddWordDiv = '+',          -- add symbols to previously set or default worddiv (string)
                               -- ATTENTION: use [[ and ]] instead of " and " to avoid escape sequences
    RemoveWordDiv = {'%+', '%-'},-- remove symbols from previously set or default worddiv (table of strings)
                               -- ATTENTION: each RemoveWordDiv string is lua regexp search string
                               -- i.e. use '%(' instead of '('. List of escaped symbols: ^$()%.[]*+-?
    inherit = 'cpp'            -- inherit nonset options from the type inherit (string or false)

    ShowMargin = false,        -- show left margin with line numbers (true/false)
    ColorizeElements = false,  -- use colorizing of right margin, EOL, EOF (true/false)
]=]
--[=[
  WordSeparators = {
    value = [[!%^&*()+|{}:"<>?`-=\[];',./~@]], -- Replaced value
    add   = '',                                -- Added characters
    del   = '[%+%-]',                          -- Deleted pattern (for gsub)
  }, --
--]=]
--------------------------------------------------------------------------------
local cfg = {

  default = {
    --inherit = nil,

    --Lock = false,
    --CodePage = 'utf8',
    --SetBom = true,
    --NewFileEOL = 'win',
    --CharCodeBase = 'hex',

    SavePosition = true,
    --CursorBeyondEOL = true,
    --ShowWhiteSpace = false,

    --AutoIndent = false,
    --TabSize = 4,
    --ExpandTabs = 'no',
    --WordDiv = [[!%^&*()+|{}:"'`<>?-=\/[];,.~@#$]],
    --AddWordDiv = '',
    --RemoveWordDiv = {'',''},

    ShowMargin = false,
    --ShowMargin = true,
    ColorizeElements = true,
  }, --
  none = { inherit = 'default' },

  common = {
    --useMargin = true,       -- Поля области редактора
    useLineation = true,    -- Линеация - нумерация линий файла
    useBookmarks = true,    -- Закладки - показ закладок
  }, --

--[=[
  text = {
  },

  plain = {
    --WordDiv = [[.,!?:;"']],
  },
--]=]

  source = {
    --SetBom = false,
    --CharCodeBase = 'hex',

    CursorBeyondEOL = true,

    AutoIndent = true,
    --TabSize = 4,
    --ExpandTabs = 'no',
  },

  fortran = {
    ExpandTabs = 'all'
  },

  python = {
    TabSize = 4,
    ExpandTabs = 'all',
  },

  make_cc = {
    ExpandTabs = 'no',
  },

  packed = {
    Lock = true,
    CharCodeBase = 'hex',

    --SavePosition = false,
    ShowWhiteSpace = true,

    TabSize = 1,
    ExpandTabs = 'no',
  },

  mixed = {
    Lock = true,
    CharCodeBase = 'hex',

    --SavePosition = false,
    ShowWhiteSpace = true,

    TabSize = 1,
    ExpandTabs = 'no',
  },

} --- cfg

return cfg
--------------------------------------------------------------------------------
