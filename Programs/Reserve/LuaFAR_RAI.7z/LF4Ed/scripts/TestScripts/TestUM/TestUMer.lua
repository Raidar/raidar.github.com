--[[ TestUM settings ]]--
--[[ ��������� TestUM ]]--

--------------------------------------------------------------------------------

local LUM_Path = "scripts\\TestScripts\\TestUM\\"

local DefData = {
  Basic = {
    LuaUMName = "TestUM",
    LuaUMPath = LUM_Path,
    --DefUMPath = "scripts\\Rh_Scripts\\LuaUM\\",
    --BindsFile = "LumBinds.lua",
    --AliasFile = "LumAlias.lui",
    --UMenuFile = "U_NoMenu.lum",
  }, -- Basic
  Files = {
    FilesPath = LUM_Path,
    MenusFile = "LutBinds.lua",
    MenusPath = LUM_Path,
    LuaScPath = LUM_Path,
  }, -- Files
  UMenu = {
    MenuTitleBind = true,
    CompoundTitle = true,
    BottomHotKeys = true,
    CaptAlignText = true,
    TextNamedKeys = true,
    FullNamedKeys = true,
    KeysAlignText = true,
    ShowErrorMsgs = true,
    --ShowErrorMsgs = false,
    ReturnToUMenu = false,
    --ReturnToUMenu = true,
  }, -- UMenu
} --- DefData

return require("Rh_Scripts.LuaUM.LumCfg").Configure(DefData)
--------------------------------------------------------------------------------
