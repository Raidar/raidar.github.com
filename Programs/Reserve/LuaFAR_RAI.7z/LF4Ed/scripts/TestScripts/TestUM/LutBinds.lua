--[[ TestUM ]]--

----------------------------------------
--[[ description:
  -- Binding type to menu.
  -- Привязка типа к меню.
--]]
--------------------------------------------------------------------------------

----------------------------------------
--local context = context

local locale = require 'context.utils.useLocale'

--------------------------------------------------------------------------------

---------------------------------------- Locale
local Custom = {
  label = "LumBinds",
  name = "lum",
  path = "Rh_Scripts.LuaEUM.config.",
  locale = { kind = 'require' },
} ---
local L, e1, e2 = locale.localize(Custom)
if L == nil then
  return locale.showError(e1, e2)
end

---------------------------------------- Data
local Data = {

  ["@"] = { -- Информация
    Author = "Aidar",
    pack = "TestScripts",
    text = "TestUM"
  },

  Default = { Caption = L.MainMenu,
              After = "UMConfig" },

  none   = { Menu = "UM_Def" },

  --text   = { Menu = "UM_Def" },
  --text   = { Menu = "UMTest1;UM_Def;" },
  --text   = { Menu = "UMTest1;UMTest2;UM_Def" },
  --text   = { Menu = "UM_Def" },
  --text   = { Menu = "UM_Def" },
  --text   = { Menu = "UM_Def" },

  --html   = { Menu = "UMTest1;UM_Def" },
  pascal = { Menu = "UMTest2;UM_Def" },
} ---

return Data
--------------------------------------------------------------------------------
