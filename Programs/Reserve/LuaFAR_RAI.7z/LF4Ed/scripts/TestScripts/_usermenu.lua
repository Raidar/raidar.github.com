--[[ �������� ������������ Lua � LuaFar ]]--

--[[ 1. ��������� ���� ]]
local ScriptPath = "scripts/TestScripts/"
local TestUMPath = ScriptPath.."TestUM/"

local utils = require 'context.utils.useUtils'
PluginPath = utils.PluginPath -- ���� �� �������

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]
--logShow(_G, "_G", "d1 _/.")
--logShow(getfenv(), "getfenv", 1)
----------------------------------------

--[[ 2. ���������� ������� ���� ]]

  -- -- -- -- --
AddToMenu("epc", ":sep:Test Scripts")
-- Rh Lua User Menu.
AddToMenu("e", "&QTest User Menu", nil, TestUMPath.."TestUM")
AddToMenu("c", "&QTest LUM for Editor", nil, TestUMPath.."TestUM", "Config")

-- Example of Own User Menu.
--AddToMenu("e", "O&wn User Menu", nil, ScriptPath.."OwnLUM/OwnLUM")
--AddToMenu("c", "O&wn User Menu", nil, ScriptPath.."OwnLUM/OwnLUM", "Config")

local TestingPath = ScriptPath.."Testing/"
--AddToMenu("evp", "Testing Dialog", nil, TestingPath.."TestDlg")
  -- List Menu.
--AddToMenu("p", "List Menu", nil, TestingPath.."RhSelfMenu", "ShowListMenu")

  -- -- -- -- --
--AddToMenu("p", ":sep:")
--AddToMenu("p", ":sep: -- Keys")
  -- Str Key Parse.
--AddToMenu("p", "Str Key Parse", nil, TestingPath.."KeyCheck", "CheckStrKey")
  -- ConvertHotKey function.
--AddToMenu("evp", "Convert&HotKey", nil, TestingPath.."KeyCheck", "CheckCvtHotKey")

  -- -- -- -- --
--AddToMenu("p", ":sep:")
  -- CPluginStartupInfo.
--AddToMenu("p", "CPluginStartupInfo", nil, TestingPath.."LuaCheck", "CheckCPluginStartupInfo")
  -- Dir List.
--AddToMenu("p", "Dir List", nil, TestingPath.."LuaCheck", "CheckDirList")
  -- Global environment.
--AddToMenu("p", "Global Env _&G", nil, TestingPath.."LuaCheck", "CheckLuaGlobal")
  -- Path vars in package.
--AddToMenu("p", "package &Pathes", nil, TestingPath.."LuaCheck", "CheckLuaPathes")
  -- Checking far.
--AddToMenu("p", "fa&r package", nil, TestingPath.."LuaCheck", "CheckLuaFar")
  -- CIO Lib.
--AddToMenu("p", "CIO Library", nil, TestingPath.."LuaCheck", "CheckCIO_Lib")
  -- String as table.
--AddToMenu("p", "String as table", nil, TestingPath.."LuaCheck", "CheckStringAsTable")

  -- -- -- -- --
--AddToMenu("p", ":sep: -- Others")
  -- Hot Char in text.
AddToMenu("p", "Hot Char in text", nil, TestingPath.."FarCheck", "CheckHotChar")
  -- far.Flags.
--AddToMenu("p", "LuaFAR Flags", nil, TestingPath.."FarCheck", "CheckLuaFarFlags")
  -- FAR language.
--AddToMenu("p", "FAR Language", nil, TestingPath.."FarCheck", "CheckFarLanguage")
  -- Palette color.
--AddToMenu("p", "Palette Color", nil, TestingPath.."FarCheck", "CheckPaletteColor")
  -- File/Full path parser.
--AddToMenu("p", "Name Parser", nil, TestingPath.."UtlCheck", "CheckParseName")
  -- End slash clear.
--AddToMenu("p", "End Slash Clear", nil, TestingPath.."UtlCheck", "CheckEndSlash")
  -- Ilk Sep Join Key.
--AddToMenu("p", "Ilk Sep Join Key", nil, TestingPath.."UtlCheck", "CheckIlkSepKey")
  -- XLat Binding.
AddToMenu("p", "XLat Binding", nil, TestingPath.."UtlCheck", "CheckXLatBinding")
  -- Macro TPL.
AddToMenu("p", "Macro TPL", nil, TestingPath.."UtlCheck", "CheckMacroTPL")
  -- Character Column/Row.
--AddToMenu("e", "Char Column", nil, TestingPath.."CharLn", "CharLine")

--[[ 3. ���������� ������������ ]]

--------------------------------------------------------------------------------
