--[[ ��������� �������� ]]--

--------------------------------------------------------------------------------

local FC_ = far.Colors

local rhkey = require "Rh_Scripts.Utils.KeyUtils"

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local PosInfo = { -- ���������� ������� �������
  CurLine   = Info.CurLine,
  CurPos    = Info.CurPos,
  CurTabPos = Info.CurTabPos,
  TopScreenLine = Info.TopScreenLine,
  LeftPos       = Info.LeftPos,
  Overtype  = Info.Overtype,
} ---

-- ��������� ������ ��������� � ������������� ���������.
function MsgX (Data, Indexes, DefMsgs, ...)
  --logShow(Indexes)
  if not Indexes then return "" end
  if type(Indexes) == "string" then Indexes = { Indexes } end
  local Message = Msg(Data, Indexes[1], DefMsgs)
  for k = 2, #Indexes do
    logShow(Message, Indexes[k])
    --logShow(Msg(Data, Indexes[k], DefMsgs), Indexes[k])
    local MsgI = Msg(Data, Indexes[k], DefMsgs)
    Message = Message:format(MsgI)
    --Message = Message:format(Msg(Data, Indexes[k], DefMsgs))
  end

  return Message:format(...)
end ---- MsgX

local function LUM_DlgTypes (CfgData)
  local DlgTypes = {}
  DlgTypes.Basic = {
    DefUMPath = "edt",
    BindsFile = "edt",
    AliasFile = "edt",
    UMenuFile = "edt",
    LuaUMPath = "edt",
  }
  DlgTypes.Files = {
    FilesPath = "edt",
    MenusFile = "edt",
    MenusPath = "edt",
    LuaScPath = "edt",
  }
  DlgTypes.UMenu = {
    MenuTitleBind = "chk",
    CompoundTitle = "chk",
    BottomHotKeys = "chk",
    CaptAlignText = "chk",
    TextNamedKeys = "chk",
    FullNamedKeys = "chk",
  }

  return DlgTypes
end ---- LUM_DlgTypes

-- From RectMenu

  --[[ -- OLD: �����. �������.
  -- ��������� ���������� ������.
  local function FindCell (Row, Col, dRow, dCol) --> (Index, {Row, Col})
    while not IsIndex(Index) do
      Row, Col = Row + dRow, Col + dCol
      if IsCatOut(Row, Data.Rows) then return nil end
      if IsCatOut(Col, Data.Cols) then return nil end
      Index = AMap[Row][Col]
    end
    return Index, aCell
  end -- FindCell
  --]]
  --[[ -- OLD: �����. �������.
  local function WrapCell (Row, Col, dRow, dCol) --> (Row, Col)
    local Rows, Cols = Data.Rows, Data.Cols
    if dRow ~= 0 then
      if Row > Rows or (Row == Rows and AMap[Row][Col] == 0) then Row = 1
      elseif Row < 1 then Row = Rows end
    end
    if dCol ~= 0 then
      if Col > Cols or (Col == Cols and AMap[Row][Col] == 0) then Col = 1
      elseif Col < 1 then Col = Cols end
    end
    return Row, Col
  end -- WrapCell
  --]]

local bit = bit64

function ShowListMenu ()
  local Items = { ItemsNumber = 1 }
  for k = 1, 30 do
    Items[k] = { Flags = 0, text = "Item "..tostring(k) }
  end
  local D = dialog.NewDialog() -- ����� ����
  D._          = {"DI_DOUBLEBOX",  3, 1,  50, 10, 0, 0, 0, 0, "List Menu"}
  local I, H, W = D._[2], D._[5], D._[4] -- Indent, Height, Width
  local M = bit.rshift(D._[4], 1) -- 1/2 * floor(D._[4]) -- Width/2
  --local T = M + bit.rshift(D._[4], 2) -- M + 1/4 * floor(D._[4]) -- Width*3/4
  D.lbxListMenu = {"DI_LISTBOX",   I, 1,   M,   H, 0, Items, 0, 0, ""} -- "List Menu"
  D.lbxListMenu2= {"DI_LISTBOX", M+1, 1,   W,   H, 0, Items, 0, 0, ""} -- "List Menu"
  local D_Flags = { FDLG_SMALLDIALOG = 1, FDLG_NODRAWSHADOW = 1, FDLG_NODRAWPANEL = 1 }
  local Result = far.Dialog(nil, -1, -1, D._[4]+4, D._[5]+2, nil, D, D_Flags) -- FAR3: GUID
  --far.Message(Result)
end ---- ShowListMenu
--------------------------------------------------------------------------------
    --[[
    local Msg =  "Left = "   .. tostring(R.Left) .. '\n'
    Msg = Msg .. "Top = "    .. tostring(R.Top) .. '\n'
    Msg = Msg .. "Right = "  .. tostring(R.Right) .. '\n'
    Msg = Msg .. "Bottom = " .. tostring(R.Bottom) .. '\n'
    logShow(Msg, "Dlg Rect")--]]
--------------------------------------------------------------------------------
-- RhIni.lua
        -- [[-- TODO: ��������� ��� � ������ ������.
        -- ���������� ����������� ����� �������� �����.
        if Value then 
          local Anno = Value:find("%s%;.*$") -- ������� �� �����
          if Anno then Value = Value:sub(1, Anno-1) end
        end
        --]]
--------------------------------------------------------------------------------

function cfgcall (newcfg, f, ...) --> (result, error | nil, error)
  newcfg = newcfg or { RequireWithReload = false, ReturnToMainMenu = false }
  local oldcfg = lf4ed.config(newcfg)
  local isOk, Result, SError = pcall(f, ...)
  lf4ed.config(oldcfg)
  if isOk then return Result, SError else return nil, Result end
end ---- cfgcall

--------------------------------------------------------------------------------
