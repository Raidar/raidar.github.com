--[[ �������� ������ PosToCat ]]--

--------------------------------------------------------------------------------
local _G = _G

local luaUt = require "Rh_Scripts.Utils.luaUtils"
local farUt = require "Rh_Scripts.Utils.farUtils"

local bit = bit64
local bshr = bit.rshift

local max2, min2 = luaUt.max2, luaUt.min2
local divf, divr = luaUt.divf, luaUt.divr

----------------------------------------
-- [[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
-- ������ ���������� ������� ���������.
local function ScrollCaret (ALen, Cat, Count) --> (Pos, Len)
  local Len = divr(ALen, Count)
  Len = max2(1, Len)
  local Pos = divr(ALen * (Cat - 1), Count) + 1
  Pos = min2(ALen, Pos)
  if Count > 1 then Len = min2(Len, ALen - Pos + 1) end
  --logShow(tostring(Pos)..'\n'..tostring(Len),
  --        tostring(Cat)..' / '..tostring(Count)..' : '..tostring(ALen))
  return Pos, Len, Pos + Len - 1
end -- ScrollCaret

--------------------------------------------------------------------------------
local function PosToCat1 (ALen, Pos, Cats) --> (number)
  return min2(divr(Pos * Cats.Alter, ALen) + Cats.Min, Cats.Max)
end --
local function PosToCat2 (ALen, Pos, Cats) --> (number)
  if ALen == 1 then return 1 end
  return min2(divr((Pos - 1) * Cats.Alter, ALen - 1) + Cats.Min, Cats.Max)
end --

local function PosToCat (ALen, Pos, Cats, CaretLen) --> (number)
  --logShow({ Len, Cats }, Pos, 2)
  if ALen == 1 then return 1 end
  --[[ -- i4
  local APart = bshr(ALen, 2)
  if Pos > APart and Pos < 3*APart then
    Pos = max2(1, Pos - bshr(CaretLen, 1))
  end -- if
  --]]
  --[[ -- d4
  local APart = bshr(ALen, 2)
  if Pos < APart then
    Pos = max2(1, Pos - bshr(CaretLen, 1))
  elseif Pos >= 3*APart then
    --Pos = max2(1, Pos - bshr(CaretLen, 1))
    Pos = max2(1, Pos - CaretLen)
  end -- if
  --]]
  --[[ -- d2
  if Pos < bshr(ALen, 1) then
    Pos = max2(1, Pos - bshr(CaretLen, 1))
  else
    Pos = min2(ALen, Pos + bshr(CaretLen, 1))
  end -- if
  --]]
  --Pos = max2(1, Pos - bshr(CaretLen, 1))    -- m
  --Pos = min2(ALen, Pos + bshr(CaretLen, 1)) -- p -- bad
  --Pos = max2(1, Pos - divr(Pos * CaretLen, ALen))
  --Pos = max2(1, Pos - divr(Pos * (CaretLen - 1), ALen) - 1)
  --Pos = max2(1, Pos - divr(Pos * (CaretLen - 1), ALen)) - 1
  --Pos = max2(1, Pos - divr((Pos - 1) * CaretLen, ALen - 1)) -- bad
  ----
  --return min2(divr(Pos * Cats.Alter, ALen) + Cats.Min, Cats.Max)
  --return min2(divr(Pos * Cats.Alter, ALen - 1) + Cats.Min, Cats.Max)
  --return min2(divr((Pos - 1) * Cats.Alter, ALen - 1) + Cats.Min, Cats.Max)
  --return min2(divr((Pos - 1) * Cats.Alter + ALen - Pos, ALen - 1) + Cats.Head, Cats.Max)
  --return min2(divr(Pos * (Cats.Alter - 1), ALen) + Cats.Min, Cats.Max)
  return min2(divr((Pos - 1) * (Cats.Alter - 1), ALen - 1) + Cats.Min, Cats.Max)
end --

local Pos_Fmt = "%#2d => %#2d: "
local Car_Fmt = "<%#2d |%#2d| %#2d>"

local function CheckPosit (ALen, Cats)
  local Count = Cats.Alter
  local t, u = { Count = Count }
  local Cat, Cat1, Cat2
  local cPos, cLen, cEnd
  for Pos = 1, ALen do
    cPos, cLen, cEnd = ScrollCaret(ALen, 1, Count)
    Cat  = PosToCat(ALen, Pos, Cats, cLen)
    Cat1 = PosToCat1(ALen, Pos, Cats, cLen)
    Cat2 = PosToCat2(ALen, Pos, Cats, cLen)
    cPos, cLen, cEnd = ScrollCaret(ALen, Cat, Count)
    --cPos, cLen, cEnd = ScrollCaret(ALen, Cat1, Count)
    --cPos, cLen, cEnd = ScrollCaret(ALen, Cat2, Count)
    u = Pos_Fmt:format(Pos, Cat)..
        Car_Fmt:format(cPos, cLen, cEnd)
    if Pos < cPos or Pos > cEnd then
      t[#t+1] = u
    end
  end
  return t
end -- CheckPosit

local function CheckPositInfo ()
  --local ALen = 58
  local ALen = 13
  local Cats = {
    Head = 0, Foot = 0,
    Min = 0, Max = 0,
    Count = 0, Alter = 0,
    All = 0, Sole = 0
  } ---
  --local ALen = 88
  local t
  --local ALen, Count = 80, 2
  --local t = CheckCaret(ALen, Count)
  --logShow(t, "CheckCaret")
  local flog = dbg.open("ScrPosit.txt")
  --ft:log(table.concat(Msg, '\n'))
  Cats.Min = Cats.Head + 1
  Cats.Count = Cats.Head + Cats.Foot
  flog:logtab({ ALen = ALen })
  for Alter = 1, 20 do
  --for Alter = 20, 40 do
    Cats.Alter = Alter
    Cats.All = Cats.Count + Alter
    Cats.Max = Cats.All - Cats.Foot
    Cats.Sole = Cats.Max + 1
    t = CheckPosit(ALen, Cats)
    flog:logtab(t, "\nScroll Posit", 2, "#q")
  end
  flog:close()
end -- CheckPositInfo

--------------------------------------------------------------------------------
return CheckPositInfo()
--------------------------------------------------------------------------------
