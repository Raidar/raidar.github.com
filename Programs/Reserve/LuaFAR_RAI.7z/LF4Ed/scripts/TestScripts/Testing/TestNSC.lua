--[[ Тестирование dialog ]]

--------------------------------------------------------------------------------
-- Пример кода для подключения в _usermenu.lua:
--AddToMenu("evp", "Testing Dialog", nil, "scripts/TestDlg.lua")
--------------------------------------------------------------------------------

local dialog = require "far2.dialog"

local sText = "Текст"
--local sAccText = "Те́кст"
local sAccText = "Те́кст"
local sAText1 = "Те"
local sATextA = "́"
--local sATextA = " ́ "
local sAText2 = "кст"

function TestDlg ()
  local D = dialog.NewDialog() -- Форма окна
  D._     = {"DI_DOUBLEBOX",  3, 1, 14,  5, 0, 0, 0,   0, "Testing dialog"}
  D.edt   = {"DI_TEXT",       5, 2, 10,  0, 0, 0, nil, 0, sText}
  D.edt   = {"DI_TEXT",       5, 3, 10,  0, 0, 0, nil, 0, sAccText}
  return D
end ---- TestDlg

local ShowMsg = far.Message

local function SendDlgClose (hDlg)
  far.SendDlgMessage(hDlg, "DM_CLOSE", -1, 0)
end

local K = far.Keys
local F = far.Flags

function TestDialog (args, ...)

  local NoDlgClose

  -- ОБРАБОТЧИК НАЖАТИЯ КЛАВИШИ:
  local function DlgCtrlEvent (hDlg, ProcItem, Input) --> (bool)

    local StrKey = far.InputRecordToName(Input) or ""

    -- Обработка Enter для проверки.
    if StrKey == "Enter" then
      --NoDlgClose = true
      SendDlgClose(hDlg); return true
      --SendDlgClose(hDlg); return false
      --return true
      --return false
    end

    far.Text(20, 20, 20, sText)
    far.Text(20, 19, 20, ("%#08x"):format(FarKey))
    far.Text(20, 21, 20, sAccText)
    if FarKey == 0x31 then
      far.Text(20, 22, 20, sAText1)
      far.Text(20, 22, 20, nil)
    end
    if FarKey == 0x32 then
      far.Text(22, 22, 20, sATextA)
      far.Text(22, 22, 20, nil)
    end
    if FarKey == 0x33 then
      far.Text(23, 22, 20, sAText2)
      far.Text(23, 22, 20, nil)
    end
    return false
  end -- DlgCtrlEvent

  local function DlgClose (hDlg, ProcItem, NoUse) --> (bool)
    --ShowMsg(ProcItem, NoUse)
    -- Закрытие только при правильном выборе пункта меню:
    if NoDlgClose then NoDlgClose = false; return false else return true end
  end -- DlgClose

  -- Обработчик событий диалога.
  local function DlgProc (hDlg, msg, param1, param2)
    -- Ссылки на обработчики событий:
    local Procs = {
      [F.DN_CONTROLINPUT] = DlgCtrlEvent,
      [F.DN_CLOSE]        = DlgClose,
    }
    if Procs[msg] then return Procs[msg](hDlg, param1, param2) end
    --[[ -- For Debug:
    if Procs[msg] then
      local Result = Procs[msg](hDlg, param1, param2)
      --if msg == F.DN_KEY then ShowMsg(Result, "DlgProc Result") end
      return Result
    end
    --]]
  end -- DlgProc

  local D = TestDlg()
  local Flags = { FDLG_SMALLDIALOG = 1, FDLG_NODRAWSHADOW = 1 }
  local Result = far.Dialog(nil, -1, -1, D._[4]+4, D._[5]+2, nil, D, Flags, DlgProc) -- FAR3: GUID
  ShowMsg(Result, "dialog Result")
end ---- TestDialog

--------------------------------------------------------------------------------
return TestDialog(...)
--------------------------------------------------------------------------------
