--[[ Selene Unicode ]]--
--[[ Проверка find / cfind ]]--

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------

local s = {
  "Пример &Hello, world!",
  "Example &Hello, world!",
}
local ss = "&" -- plain find
--local ss = "%w%s"
--local ss = "%c"

local findpos, findend = s[1]:cfind(ss, 1, true)
far.Message(tostring(findpos)..'|'..tostring(findend), s[1])

local findpos, findend = s[2]:cfind(ss, 1, true)
far.Message(tostring(findpos)..'|'..tostring(findend), s[2])

--------------------------------------------------------------------------------
