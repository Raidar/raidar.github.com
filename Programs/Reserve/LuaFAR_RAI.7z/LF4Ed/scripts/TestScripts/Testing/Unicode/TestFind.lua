--[[ Selene Unicode vs. OEM ]]--
--[[ �஢�ઠ find ]]--[[ �������� find ]]--

----------------------------------------
-- [[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------

local s = "�஢�ઠ �㭪樨 1: find"
local ss = "�㭪樨" -- plain find
--local ss = "%w%s"
--local ss = "%c"

local findpos, findend = s:find(ss)
--local ssub = string.sub
--findpos, findend = ssub(s, 1, findpos):len(), ssub(s, 1, findend):len()

local utf8 = unicode.utf8
--local utf8 = {}
--for k, v in pairs(unicode.utf8) do utf8[k] = v end
local ssub, slen = string.sub, string.len
local bfind, ulen = utf8.find, utf8.len
--local bfind, ulen = unicode.utf8.find, unicode.utf8.len
local function _find (s, pattern, init, plain)
  local fpos, fend, fcaps = bfind(s, pattern,
                                  slen(ssub(s, 1, init or 1)), plain)
  if not fpos then return end
  return ulen(ssub(s, 1, fpos)), ulen(ssub(s, 1, fend)), fcaps
end -- _find
--utf8.find = _find
--getmetatable("").__index = utf8
--debug.setmetatable("", { __index = utf8 }) -- OLD

--local findpos, findend = _find(s, ss)

--[[ -- plain find
local t = {
  ss = ss,
  findpos = findpos,
  findend = findend,
  len = s:len(),
  sub = s:sub(findpos, findend),
  sub_char = s:sub(10, 16),
  sub_byte = s:sub(18, 31),
  str_sub = string.sub(s, 10, 16),
} --- t
--]]

local t = {
  ss = ss,
  findpos = findpos,
  findend = findend,
  len = s:len(),
  sub = s:sub(findpos, findend),
} --- t

--logShow(t, s)

-- TEST cfind
--[[
logShow(string, "string", 1)
local meta_index = getmetatable("").__index
logShow(meta_index, "meta_index", 1)
logShow(s:cfind("�%l"), "cfind", 1)
--]]

--------------------------------------------------------------------------------
