
--------------------------------------------------------------------------------
local abs = math.abs

----------------------------------------
--[[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local t = {
  'Название',
  'название',
  'наличии',
  'названия',
  'Названий',
  'Набор',
  'Научное',
  'Научно',
  'Набранный';
  n=9,
  Stat = { -- Статистика встречаемости:
    ['названия']  = { Line=29, Count=1, Slot=1 },
    ['название']  = { Line=8, Count=4, Slot=2 },
    ['наличии']   = { Line=12, Count=1, Slot=1 },
    ['Научно']    = { Line=176, Count=1, Slot=1 },
    ['Набранный'] = { Line=193, Count=1, Slot=1 },
    ['Название']  = { Line=8, Count=1, Slot=1 },
    ['Набор']     = { Line=120, Count=1, Slot=1 },
    ['Научное']   = { Line=172, Count=1, Slot=1 },
    ['Названий']  = { Line=54, Count=1, Slot=1 },
  }, -- Stat
  Link = { Line=11, Down=1, Up=1 }, -- Link
} ---

-- Сортировка таблицы строк по частотности.
local function SortByFreq (t) --> (table)
  local f = t.Stat
  local f1, f2
  -- Сравнение слов по статистике:
  local function StatCmp (w1, w2) --> (bool)
    f1, f2 = f[w1], f[w2]
    return f1.Count >  f2.Count or
           f1.Count == f2.Count and (abs(f1.Line) < abs(f2.Line) or
           f1.Line  == f2.Line  and f1.Slot < f2.Slot) --or false
  end --
  table.sort(t, StatCmp)

  return t
end -- SortByFreq

logShow(t, "SortByFreq", 2)
SortByFreq(t)
logShow(t, "SortByFreq", 2)

--------------------------------------------------------------------------------
