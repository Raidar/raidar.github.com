local random = math.random

-- �����⮢�� ���ᨢ� �ᥫ.
local n = 1000000
math.randomseed(n)

local t = {}
for k = 1, n do
  --t[k] = k
  t[k] = random(n)
end

local luaUt = require "Rh_Scripts.Utils.luaUtils"

local max = math.max
local max2 = luaUt.max2

local function max3 (a, b)
  return max(a, b)
end ----

local function max4 (a, b)
  local r = max(a, b)
  return r
end ----

--local fmax = max
--local fmax = max2
--local fmax = max3
local fmax = max4

local useprofiler = false
--local useprofiler = true

if useprofiler then
  require "profiler" -- Lua Profiler
  profiler.start("max2max.log")
end

-- ���᫥��� �㭪樨.
local m = 0
for k = 1, n do
  m = fmax(m, t[k])
  --m = fmax(t[k], m)
end

if useprofiler then profiler.stop() end
