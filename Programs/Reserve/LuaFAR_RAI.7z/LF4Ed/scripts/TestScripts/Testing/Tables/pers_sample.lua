--It is used like this:

local persistence = require "TestScripts.Testing.Tables.persistence"

    t_original = {1, 2, ["a"] = "string", b = "test", {"subtable", [4] = 2}};
    persistence.store("storage.lua", t_original);
    t_restored = persistence.load("storage.lua");

--[[
Example output (storage.lua):

    -- Persistent Data
    return {
    	[1] = 1;
    	[2] = 2;
    	[3] = {
    		[1] = "subtable";
    		[4] = 2;
    	};
    	["a"] = "string";
    	["b"] = "test";
}
--]]
