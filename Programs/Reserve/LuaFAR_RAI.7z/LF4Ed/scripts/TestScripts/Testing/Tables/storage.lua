-- Persistent Data
local multiRefObjects = {

} -- multiRefObjects
local obj1 = {
	[1] = 1;
	[2] = 2;
	[3] = {
		[1] = "subtable";
		[4] = 2;
	};
	["a"] = "string";
	["b"] = "test";
}
return obj1
