
function CharLine()

local c = ' '

for i = 128, 159 do
--for i = 128, 255 do
  c = string.char(i)
  --c = c .. ',' .. c
  --c = editor.OEMToEditor(c)
  --c = editor.EditorToOEM(c)
  editor.InsertText(c)
  editor.InsertText(' ')
  --editor.InsertText('\r')
end

editor.InsertText(editor.EditorToOEM('-- �'))
editor.InsertText(editor.OEMToEditor(' / �'))

end ---- CharLine

--print("\a")

return CharLine()
