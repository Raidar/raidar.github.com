--[[ LuaFAR for Editor ]]--
--[[ Selene Unicode vs. OEM ]]--
--[[ ������ ᮮ⢥��⢨� ]]--[[ ������� ������������ ]]--

--------------------------------------------------------------------------------
local isUnicode = far.LuafarVersion(true) >= 2

local None  = { a = 0, c = 0, d = 0, l = 0, p = 0, s = 0, u = 0, w = 0, x = 0, Upper = 0, Lower = 0 }
local Ctrl  = { a = 0, c = 1, d = 0, l = 0, p = 0, s = 0, u = 0, w = 0, x = 0, Upper = 0, Lower = 0 }
local Space = { a = 0, c = 0, d = 0, l = 0, p = 0, s = 1, u = 0, w = 0, x = 0, Upper = 0, Lower = 0 }
local DiHex = { a = 0, c = 0, d = 1, l = 0, p = 0, s = 0, u = 0, w = 1, x = 1, Upper = 0, Lower = 0 }
local UpHex = { a = 1, c = 0, d = 0, l = 0, p = 0, s = 0, u = 1, w = 1, x = 1, Upper = 0, Lower = 0 }
local LoHex = { a = 1, c = 0, d = 0, l = 1, p = 0, s = 0, u = 0, w = 1, x = 1, Upper = 0, Lower = 0 }
local Upper = { a = 1, c = 0, d = 0, l = 0, p = 0, s = 0, u = 1, w = 1, x = 0, Upper = 0, Lower = 0 }
local Lower = { a = 1, c = 0, d = 0, l = 1, p = 0, s = 0, u = 0, w = 1, x = 0, Upper = 0, Lower = 0 }
local Punct = { a = 0, c = 0, d = 0, l = 0, p = 1, s = 0, u = 0, w = 0, x = 0, Upper = 0, Lower = 0 }
local Symbo = None
local PuSym = isUnicode and Symbo or Punct

local CharFinds = {
   Default = None, -- By def

  [032] = Space, -- Space
  [033] = Punct, -- !
  [034] = Punct, -- "
  [035] = Punct, -- #
  [036] = PuSym, -- $
  [037] = Punct, -- %
  [038] = Punct, -- &
  [039] = Punct, -- '
  [040] = Punct, -- (
  [041] = Punct, -- )
  [042] = Punct, -- *
  [043] = PuSym, -- +
  [044] = Punct, -- ,
  [045] = Punct, -- -
  [046] = Punct, -- .
  [047] = Punct, -- /

  [048] = DiHex, -- 0
  [049] = DiHex, -- 1
  [050] = DiHex, -- 2
  [051] = DiHex, -- 3
  [052] = DiHex, -- 4
  [053] = DiHex, -- 5
  [054] = DiHex, -- 6
  [055] = DiHex, -- 7
  [056] = DiHex, -- 8
  [057] = DiHex, -- 9
  [058] = Punct, -- :
  [059] = Punct, -- ;
  [060] = PuSym, -- <
  [061] = PuSym, -- =
  [062] = PuSym, -- >
  [063] = Punct, -- ?

  [064] = Punct, -- @
  [065] = UpHex, -- A
  [066] = UpHex, -- B
  [067] = UpHex, -- C
  [068] = UpHex, -- D
  [069] = UpHex, -- E
  [070] = UpHex, -- F
  [071] = Upper, -- G
  [072] = Upper, -- H
  [073] = Upper, -- I
  [074] = Upper, -- J
  [075] = Upper, -- K
  [076] = Upper, -- L
  [077] = Upper, -- M
  [078] = Upper, -- N
  [079] = Upper, -- O

  [080] = Upper, -- P
  [081] = Upper, -- Q
  [082] = Upper, -- R
  [083] = Upper, -- S
  [084] = Upper, -- T
  [085] = Upper, -- U
  [086] = Upper, -- V
  [087] = Upper, -- W
  [088] = Upper, -- X
  [089] = Upper, -- Y
  [090] = Upper, -- Z
  [091] = Punct, -- [
  [092] = Punct, -- \
  [093] = Punct, -- ]
  [094] = PuSym, -- ^
  [095] = Punct, -- _

  [096] = PuSym, -- `
  [097] = LoHex, -- a
  [098] = LoHex, -- b
  [099] = LoHex, -- c
  [100] = LoHex, -- d
  [101] = LoHex, -- e
  [102] = LoHex, -- f
  [103] = Lower, -- g
  [104] = Lower, -- h
  [105] = Lower, -- i
  [106] = Lower, -- j
  [107] = Lower, -- k
  [108] = Lower, -- l
  [109] = Lower, -- m
  [110] = Lower, -- n
  [111] = Lower, -- o

  [112] = Lower, -- p
  [113] = Lower, -- q
  [114] = Lower, -- r
  [115] = Lower, -- s
  [116] = Lower, -- t
  [117] = Lower, -- u
  [118] = Lower, -- v
  [119] = Lower, -- w
  [120] = Lower, -- x
  [121] = Lower, -- y
  [122] = Lower, -- z
  [123] = Punct, -- {
  [124] = PuSym, -- |
  [125] = Punct, -- }
  [126] = PuSym, -- ~
  [127] = Ctrl,  -- DEL

  [128] = Upper, -- � 0410
  [129] = Upper, -- �
  [130] = Upper, -- �
  [131] = Upper, -- �
  [132] = Upper, -- �
  [133] = Upper, -- �
  [134] = Upper, -- �
  [135] = Upper, -- �
  [136] = Upper, -- �
  [137] = Upper, -- �
  [138] = Upper, -- �
  [139] = Upper, -- �
  [140] = Upper, -- �
  [141] = Upper, -- �
  [142] = Upper, -- �
  [143] = Upper, -- � 041F

  [144] = Upper, -- � 0420
  [145] = Upper, -- �
  [146] = Upper, -- �
  [147] = Upper, -- �
  [148] = Upper, -- �
  [149] = Upper, -- �
  [150] = Upper, -- �
  [151] = Upper, -- �
  [152] = Upper, -- �
  [153] = Upper, -- �
  [154] = Upper, -- �
  [155] = Upper, -- �
  [156] = Upper, -- �
  [157] = Upper, -- �
  [158] = Upper, -- �
  [159] = Upper, -- � 042F

  [160] = Lower, -- � 0430
  [161] = Lower, -- �
  [162] = Lower, -- �
  [163] = Lower, -- �
  [164] = Lower, -- �
  [165] = Lower, -- �
  [166] = Lower, -- �
  [167] = Lower, -- �
  [168] = Lower, -- �
  [169] = Lower, -- �
  [170] = Lower, -- �
  [171] = Lower, -- �
  [172] = Lower, -- �
  [173] = Lower, -- �
  [174] = Lower, -- �
  [175] = Lower, -- � 043F

  [176] = Symbo, -- 2591 Light Shade
  [177] = Symbo, -- 2592 Medium Shade
  [178] = Symbo, -- 2593 Dark Shade
  [179] = Symbo, -- 2502 V1
  [180] = Symbo, -- 2524 V1-L1
  [181] = Symbo, -- 2561 V1-L2
  [182] = Symbo, -- 2562 V2-L1
  [183] = Symbo, -- 2556 D2-L1
  [184] = Symbo, -- 2555 D1-L2
  [185] = Symbo, -- 2563 V2-L2
  [186] = Symbo, -- 2551 V2
  [187] = Symbo, -- 2557 D2-L2
  [188] = Symbo, -- 255D U2-L2
  [189] = Symbo, -- 255C U2-L1
  [190] = Symbo, -- 255B U1-L2
  [191] = Symbo, -- 2510 D1-L1

  [192] = Symbo, -- 2514 U1-R1
  [193] = Symbo, -- 2534 U1-H1
  [194] = Symbo, -- 252C D1-H1
  [195] = Symbo, -- 251C V1-R1
  [196] = Symbo, -- 2500 H1
  [197] = Symbo, -- 253C V1-H1
  [198] = Symbo, -- 255E V1-R2
  [199] = Symbo, -- 255F V2-R1
  [200] = Symbo, -- 255A U2-R2
  [201] = Symbo, -- 2554 D2-R2
  [202] = Symbo, -- 2569 U2-H2
  [203] = Symbo, -- 2566 D2-H2
  [204] = Symbo, -- 2560 V2-R2
  [205] = Symbo, -- 2550 H2
  [206] = Symbo, -- 256C V2-H2
  [207] = Symbo, -- 2567 U1-H2

  [208] = Symbo, -- 2568 U2-H1
  [209] = Symbo, -- 2564 D1-H2
  [210] = Symbo, -- 2565 D2-H1
  [211] = Symbo, -- 2559 U2-R1
  [212] = Symbo, -- 2558 U1-R2
  [213] = Symbo, -- 2552 D1-R2
  [214] = Symbo, -- 2553 D2-R1
  [215] = Symbo, -- 256B V2-H1
  [216] = Symbo, -- 256A V1-H2
  [217] = Symbo, -- 2518 U1-L1
  [218] = Symbo, -- 250C D1-R1
  [219] = Symbo, -- 2588 FB
  [220] = Symbo, -- 2584 DB
  [221] = Symbo, -- 258C LB
  [222] = Symbo, -- 2590 RB
  [223] = Symbo, -- 2580 UB

  [224] = Lower, -- � 0440
  [225] = Lower, -- �
  [226] = Lower, -- �
  [227] = Lower, -- �
  [228] = Lower, -- �
  [229] = Lower, -- �
  [230] = Lower, -- �
  [231] = Lower, -- �
  [232] = Lower, -- �
  [233] = Lower, -- �
  [234] = Lower, -- �
  [235] = Lower, -- �
  [236] = Lower, -- �
  [237] = Lower, -- �
  [238] = Lower, -- �
  [239] = Lower, -- � 044F

  [240] = Upper, -- � 0401
  [241] = Lower, -- � 0451
  [242] = Upper, -- � 0404
  [243] = Lower, -- � 0454
  [244] = Upper, -- � 0407
  [245] = Lower, -- � 0457
  [246] = Upper, -- � 040E
  [247] = Lower, -- � 045E

  [248] = PuSym, -- � 00B0 Degree Sign ?
  [249] = Symbo, -- � 2219 Bullet Operator ?
  [250] = Punct, -- � 00B7 Middle Dot
  [251] = Symbo, -- � 221A Square Root
  [252] = Symbo, -- � 2116 Numero Sign
  [253] = PuSym, -- � 00A4 Currency Sign
  [254] = Symbo, -- � 220E End Of Proof ???
  --[255] = Symbo, -- ???
  [255] = Space, -- ??? No-Break Space ???

} --- CharFinds

--for k = 0x41, 0x5A

return CharFinds
--------------------------------------------------------------------------------
