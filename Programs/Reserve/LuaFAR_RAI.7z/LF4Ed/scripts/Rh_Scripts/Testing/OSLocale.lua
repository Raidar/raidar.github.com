--[[ Проверка работы os.setlocale ]]--

--------------------------------------------------------------------------------
--local _G = _G

----------------------------------------
local logShow = context.ShowInfo

--------------------------------------------------------------------------------

local cats = { "all", "collate", "ctype", "monetary", "numeric", "time" }

--setlocale("en_US.UTF-8") ??

local function CheckOSLocale ()
  --local loc = os.setlocale("")
  --local loc = os.setlocale("Russian_Russia.866")
  --local loc = os.setlocale("Russian_Russia.OEM")
  local loc = os.setlocale(nil, cats[1])
  logShow(loc, "Locale", 2)
end -- CheckOSLocale

--------------------------------------------------------------------------------
return CheckOSLocale()
--------------------------------------------------------------------------------
