far.Show(
  regex.match("abc\r", "/$/m") == "\r",
  regex.match("abc\n", "/$/m") == "\n",
  regex.match("abc\r\n", "/$/m") == "\r\n",
  string.byte(regex.match("abc\r\n\r\n", "/^$/m")),
  regex.match("abc\r\n\r\n", "/^$/m") == "\r\n"
  )

far.Show(
  regex.match("abc\r\r", "/^$/m") == "\r",
  regex.match("abc\n\n", "/^$/m") == "\n",
  string.byte(regex.match("abc\r\n", "/^$/m")),
  regex.match("abc\r\n", "/^$/m") == "\r\n",
  string.byte(regex.match("abc\r\n\r\n", "/^$/m")),
  regex.match("abc\r\n\r\n", "/^$/m") == "\r\n")
