--[[ Test GetDirList ]]--

----------------------------------------
-- [[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

local t = far.GetDirList("D:/Programs/Far3/Profile/plugins/LF4Ed/scripts")
--local t = far.GetDirList("D:/Programs/Far3/Profile/plugins/LF4Ed/scripts/Rh_Scripts")
--local t = far.GetDirList("D:/Programs/Far2/Personals/LF4Ed/scripts")
--far.Message(#t, "GetDirList")
logShow(t, "GetDirList")

--------------------------------------------------------------------------------
