--[[ DateTime Info ]]--

----------------------------------------
--[[ description:
  -- Show date/time information.
  -- Показ информации о дате/времени.
--]]
----------------------------------------
--[[ uses:
  LuaFAR.
  -- group: Samples.
--]]
--------------------------------------------------------------------------------

----------------------------------------
--local context = context
local logShow = context.ShowInfo

local numbers = require 'context.utils.useNumbers'

local divf  = numbers.divf
local divm  = numbers.divm
local round = numbers.round

----------------------------------------
local datim = require "Rh_Scripts.Utils.DateTime"
local cfgTerra = require "Rh_Scripts.Utils.DateTime.Terra"
local cfgPern  = require "Rh_Scripts.Utils.DateTime.Pern"
local cfgHekso = require "Rh_Scripts.Utils.DateTime.Hekso"

--local cfgWorld = cfgTerra
--local cfgWorld = cfgPern
local cfgWorld = cfgHekso
local c = datim.newConfig(cfgWorld.TConfig)
--local c = datim.newConfig(cfgWorld ~= cfgTerra and cfgWorld.TConfig)

--------------------------------------------------------------------------------
local Info = {}
local SepLine = "─────────────────────"
local DateFmt = "%04d-%02d-%02d"
local TimeFmt = "%02d:%02d:%02d"

local dt = os.date("*t")
local d = datim.newDate(dt.year, dt.month, dt.day, c)
--logShow(d, "TDate", "w")
--local d = datim.newDate(1886, 12, 25, c) -- Check yester year
--local d = datim.newDate(2036, 12, 25, c) -- Check future year
--local d = datim.newDate(1900, 12, 31, c) -- Check end of base year
--local d = datim.newDate(1999, 12, 31, c) -- Check end of base year
--local d = datim.newDate(2000, 01, 01, c) -- Check start of leap year
--local d = datim.newDate(2000, 12, 31, c) -- Check end   of leap year
--local d = datim.newDate(2001, 01, 01, c) -- Check start of base year
--local d = datim.newDate(2012, 12, 31, c) -- Check end   of leap year
--local d = datim.newDate(2013, 01, 01, c) -- Check start of base year

--local d = datim.newDate(0001, 01, 01, c) -- Check start of base year ACE
--local d = datim.newDate(0000, 12, 31, c) -- Check end of base year BCE = -1
--local d = datim.newDate(0000, 12, 01, c) -- Check last month of base year BCE = -1
--local d = datim.newDate(0000, 03, 01, c) -- Check 3rd month of base year BCE = -1
--local d = datim.newDate(0000, 01, 02, c) -- Check 2nd day of base year BCE = -1
--local d = datim.newDate(0000, 01, 01, c) -- Check start of base year BCE = -1
--local d = datim.newDate(-001, 12, 31, c) -- Check start of base year - 1 BCE
--local d = datim.newDate(-001, 01, 01, c) -- Check start of base year - 1 BCE

--local d = datim.newDate(-002, 12, 30, c)
--local d = datim.newDate(-002, 12, 31, c)

--local d = datim.newDate(-003, 12, 31, c)
--local d = datim.newDate(-003, 12, 30, c)
--local d = datim.newDate(-003, 01, 01, c)
--local d = datim.newDate(-003, 03, 01, c)

--local d = datim.newDate(-004, 09, 01, c)

--local d = datim.newDate(2013, 03, 04, c)
--local d = datim.newDate(-2013, 01, 01, c)
--d.y = -d.y

--local d = datim.newDate(2016, 12, 33, c) -- Check leap Turn
--local d = datim.newDate(2017, 01, 01, c) -- Check leap Turn
--local d = datim.newDate(2508, 1, 1, c) -- Check start of 9th Pass

--local d = datim.newDate(0001, 01, 01, c)
--d:shd(-7)

local d = datim.newDate(2012, 03, 01, c)
d:shd(-1)
--local d = datim.newDate(2012, 02, 29, c) -- TODO: Ошибка с divYearDay + divEraDay

local YearDay   = c:getYearDay(d.y, d.m, d.d)
local EraDay    = c:getEraDay(d.y, d.m, d.d)
local EraMonth  = c:getEraMonth(d.y, d.m)

Info[#Info+1] = "== "..c.World.." =="
Info[#Info+1] = "────── TConfig ──────"
Info[#Info+1] = "== Date ==   = "..DateFmt:format(d.y, d.m, d.d)
Info[#Info+1] = "isLeapYear   = "..tostring(c:isLeapYear(d.y))
Info[#Info+1] = "getLeapDays  = "..("%1d"):format(c:getLeapDays(d.y))
Info[#Info+1] = "getYearDay   = "..("%03d"):format(YearDay)
Info[#Info+1] = "divYearDay   = "..DateFmt:format(d.y, c:divYearDay(d.y, YearDay))
Info[#Info+1] = "getYearWeek  = "..(" %02d"):format(c:getYearWeek(d.y, d.m, d.d))
Info[#Info+1] = "getMonthWeek = "..("  %1d"):format(c:getMonthWeek(d.y, d.m, d.d))
Info[#Info+1] = "getWeekDay   = "..("  %1d"):format(c:getWeekDay(d.y, d.m, d.d))
Info[#Info+1] = "getEraDay    = "..("%d"):format(EraDay)
Info[#Info+1] = "divEraDay    = "..DateFmt:format(c:divEraDay(EraDay))
Info[#Info+1] = "getEraMonth  = "..("%d"):format(EraMonth)
Info[#Info+1] = "divEraMonth  = "..("%04d-%02d"):format(c:divEraMonth(EraMonth))
Info[#Info+1] = SepLine

local t = datim.newTime(dt.hour, dt.min, dt.sec)
--logShow(t, "TTime", "w")

far.Show(unpack(Info))
--------------------------------------------------------------------------------
