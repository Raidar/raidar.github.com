--[[ YearStartWeek Test ]]--

--------------------------------------------------------------------------------

----------------------------------------
local datim = require "Rh_Scripts.Utils.DateTime"

----------------------------------------
--local context = context
local logShow = context.ShowInfo

local numbers = require 'context.utils.useNumbers'

local divf  = numbers.divf
local divm  = numbers.divm
local round = numbers.round

--------------------------------------------------------------------------------
local TestData_01 = {
  YearStartWeekDay = 1,
  { y = 2018, m = 1, d = 1, yweek = 1, wday = 1, },
  { y = 2013, m = 1, d = 1, yweek = 1, wday = 2, },
  { y = 2016, m = 1, d = 1, yweek = 1, wday = 5, },
  { y = 2014, m = 1, d = 1, yweek = 1, wday = 3, },
  { y = 2015, m = 1, d = 1, yweek = 1, wday = 4, },
  { y = 2011, m = 1, d = 1, yweek = 1, wday = 6, },
  { y = 2012, m = 1, d = 1, yweek = 1, wday = 0, },
  { y = -9999, m = 1, d = 1, yweek = 1, wday = 0, },
  { y = 10001, m = 1, d = 1, yweek = 1, wday = 0, },
  { y = 0, m = 1, d = 1, yweek = 1, wday = 0, },
} --- TestData_01

local TestData_04 = {
  YearStartWeekDay = 4,
  { y = 2018, m = 1, d = 1, yweek = 1, wday = 1, },
  { y = 2013, m = 1, d = 1, yweek = 1, wday = 2, },
  { y = 2014, m = 1, d = 1, yweek = 1, wday = 3, },
  { y = 2015, m = 1, d = 1, yweek = 1, wday = 4, },
  { y = 2016, m = 1, d = 1, yweek = 0, wday = 5, },
  { y = 2011, m = 1, d = 1, yweek = 0, wday = 6, },
  { y = 2012, m = 1, d = 1, yweek = 0, wday = 0, },
} --- TestData_04

local TestData_06 = {
  YearStartWeekDay = 6,
  { y = 2018, m = 1, d = 1, yweek = 1, wday = 1, },
  { y = 2013, m = 1, d = 1, yweek = 1, wday = 2, },
  { y = 2014, m = 1, d = 1, yweek = 0, wday = 3, },
  { y = 2015, m = 1, d = 1, yweek = 0, wday = 4, },
  { y = 2016, m = 1, d = 1, yweek = 0, wday = 5, },
  { y = 2011, m = 1, d = 1, yweek = 0, wday = 6, },
  { y = 2012, m = 1, d = 1, yweek = 0, wday = 0, },
} --- TestData_06

local TestData_07 = {
  YearStartWeekDay = 7,
  { y = 2018, m = 1, d = 1, yweek = 1, wday = 1, },
  { y = 2013, m = 1, d = 1, yweek = 0, wday = 2, },
  { y = 2014, m = 1, d = 1, yweek = 0, wday = 3, },
  { y = 2015, m = 1, d = 1, yweek = 0, wday = 4, },
  { y = 2016, m = 1, d = 1, yweek = 0, wday = 5, },
  { y = 2011, m = 1, d = 1, yweek = 0, wday = 6, },
  { y = 2012, m = 1, d = 1, yweek = 0, wday = 0, },
} --- TestData_07

local c = datim.newConfig()

local TestData = TestData_01
--local TestData = TestData_04
--local TestData = TestData_06
--local TestData = TestData_07

local function getYearWeek (k) --> (number)
  local Data = TestData[k]
  local y, m, d = Data.y, Data.m, Data.d

  local DayPerWeek = c.DayPerWeek
  local YearStartDay = c:getWeekDay(y, 1, 1)
  if YearStartDay == 0 then YearStartDay = DayPerWeek end
  local YearStartShift = DayPerWeek - TestData.YearStartWeekDay + 1

  return divf(c:getYearDay(y, m, d) - 1 +
              DayPerWeek + YearStartDay - 1 -
              --0,
              (YearStartDay > YearStartShift and DayPerWeek or 0),
              DayPerWeek)
         -- - ( YearStartDay > YearStartShift and 1 or 0 )
end ---- getYearWeek

local TestFmt = "%04d-%02d-%02d = %1d %s %1d wday = %1d / %1d -> %1d"

local function TestFormat (k)
  local Data = TestData[k]
  local y, m, d = Data.y, Data.m, Data.d

  local YearWeek = getYearWeek(k)
  --local YearWeek = c:getYearWeek(y, m, d)
  local YearStartDay = c:getWeekDay(y, 1, 1)

  return TestFmt:format(y, m, d,
                        YearWeek,
                        YearWeek == Data.yweek and '==' or '<>',
                        Data.yweek,
                        YearStartDay,
                        (YearStartDay == 0 and c.DayPerWeek or YearStartDay),
                        --(YearStartDay - 1) % c.DayPerWeek + 1
                        (YearStartDay == 0 and c.DayPerWeek or YearStartDay) - 1
                       )
end -- TestFormat

local SepLine = "─────────────────"

local t = {}
t[#t+1] = ("== %d =="):format(TestData.YearStartWeekDay)
t[#t+1] = "yyyy-mm-dd = W ?? w wday = w / 1 -> 1"
t[#t+1] = SepLine

for k = 1, #TestData do
  if not TestData[k] then
    t[#t+1] = SepLine
  else
    t[#t+1] = TestFormat(k)
  end
end --

t[#t+1] = SepLine

far.Show(unpack(t))
--------------------------------------------------------------------------------
