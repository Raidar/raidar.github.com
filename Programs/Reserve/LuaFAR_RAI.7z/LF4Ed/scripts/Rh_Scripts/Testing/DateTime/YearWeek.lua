--[[ YearWeek Test ]]--

--------------------------------------------------------------------------------

----------------------------------------
local datim = require "Rh_Scripts.Utils.DateTime"

----------------------------------------
--local context = context
local logShow = context.ShowInfo

local numbers = require 'context.utils.useNumbers'

local divf  = numbers.divf
local divm  = numbers.divm
local round = numbers.round

--------------------------------------------------------------------------------
local t = {}
local dt = os.date("*t")

--logShow(dt, "os.date")
--t[#t+1] = "──── os.date ────"
--t[#t+1] = ("%04d-%02d-%02d %02d:%02d:%02d"):format(
--          dt.year, dt.month, dt.day, dt.hour, dt.min, dt.sec)
--t[#t+1] = ("Day of week =   %1d"):format(dt.wday-1)
--t[#t+1] = ("Day of year = %03d"):format(dt.yday)

local d = datim.newDate(dt.year, dt.month, dt.day)
--logShow(d, "TDate", "w")
--d.y = 2012
--local d = datim.newDate(2013, 01, 09)

local c = d.config
t[#t+1] = "──── TConfig ────"
--t[#t+1] = "isLeapYear  = "..tostring(c:isLeapYear(d.y))
--t[#t+1] = "getLeapDays = "..("%1d"):format(c:getLeapDays(d.y))
--t[#t+1] = "getYearDay  = "..("%03d"):format(c:getYearDay(d.y, d.m, d.d))
--t[#t+1] = "getYearWeek = "..(" %02d"):format(c:getYearWeek(d.y, d.m, d.d))
--t[#t+1] = "getWeekDay  = "..("  %1d"):format(c:getWeekDay(d.y, d.m, d.d))
--t[#t+1] = "getEraDay   = "..("%d"):format(c:getEraDay(d.y, d.m, d.d))

local TestDay = 09
local TestMonth = 01
local TestFmt = "%04d-%02d-%02d = %1d %s %1d wday = %1d / %1d -> %1d"
local SepLine = "─────────────────"
t[#t+1] = "yyyy-mm-dd = W ?? w wday = w / 1 -> 1"
t[#t+1] = SepLine

local TestData = {
  { y = 2016, m = 01, d = 09, yweek = 2, },
  { y = 2015, m = 01, d = 09, yweek = 2, },
  { y = 2014, m = 01, d = 09, yweek = 2, },
  { y = 2013, m = 01, d = 09, yweek = 2, },
  { y = 2012, m = 01, d = 09, yweek = 3, },
  false,
  { y = 2011, m = 01, d = 09, yweek = 2, },
  { y = 2010, m = 01, d = 09, yweek = 2, },
  { y = 2009, m = 01, d = 09, yweek = 2, },
  { y = 2008, m = 01, d = 09, yweek = 2, },
  { y = 2007, m = 01, d = 09, yweek = 2, },
  { y = 2006, m = 01, d = 09, yweek = 3, },
  false,
  { y = 2013, m = 01, d = 10, yweek = 2, },
  { y = 2012, m = 01, d = 10, yweek = 3, },
  { y = 2011, m = 01, d = 10, yweek = 3, },
  { y = 2010, m = 01, d = 10, yweek = 2, },
} ---

local function getYearWeek (k) --> (number)
  local Data = TestData[k]
  local y, m, d = Data.y, Data.m, Data.d
  local c = datim.newConfig()
  local DayPerWeek = c.DayPerWeek
  local YearStartDay = c:getWeekDay(y, 1, 1)
  return divf(c:getYearDay(y, m, d) - 1 +
              --0,
              (YearStartDay == 0 and DayPerWeek or YearStartDay) - 1, --c.WeekStartDay,
              --DayPerWeek - c:getWeekDay(y, m, d) - 1, -- TODO: Исправить
              DayPerWeek) + 1
end ---- getYearWeek

local function TestFormat (k)
  local Data = TestData[k]
  local y, m, d = Data.y, Data.m, Data.d
  --local YearWeek = getYearWeek(k)
  local YearWeek = c:getYearWeek(y, m, d)
  local YearStartDay = c:getWeekDay(y, 01, 01)
  return TestFmt:format(y, m, d,
                        YearWeek,
                        YearWeek == Data.yweek and '==' or '<>',
                        Data.yweek,
                        c:getWeekDay(y, m, d),
                        YearStartDay,
                        --(YearStartDay - 1) % c.DayPerWeek + 1
                        (YearStartDay == 0 and c.DayPerWeek or YearStartDay) - 1
                       )
end -- TestFormat

for k = 1, #TestData do
  if not TestData[k] then
    t[#t+1] = SepLine
  else
    t[#t+1] = TestFormat(k)
  end
end --

t[#t+1] = SepLine

far.Show(unpack(t))
--------------------------------------------------------------------------------
