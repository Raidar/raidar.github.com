--[[ YearWeeks Test ]]--

--------------------------------------------------------------------------------

----------------------------------------
local datim = require "Rh_Scripts.Utils.DateTime"

----------------------------------------
--local context = context
local logShow = context.ShowInfo

local numbers = require 'context.utils.useNumbers'

local divf  = numbers.divf
local divm  = numbers.divm
local round = numbers.round

--------------------------------------------------------------------------------
local TestData_01 = {
  YearStartWeekDay = 1,
  { y = 2018, m = 1, d = 1, yweek = 1, wday = 1, yweeks = 52, },
  { y = 2013, m = 1, d = 1, yweek = 1, wday = 2, yweeks = 52, },
  { y = 2014, m = 1, d = 1, yweek = 1, wday = 3, yweeks = 52, },
  { y = 2015, m = 1, d = 1, yweek = 1, wday = 4, yweeks = 52, },
  { y = 2016, m = 1, d = 1, yweek = 1, wday = 5, yweeks = 52, },
  { y = 2011, m = 1, d = 1, yweek = 1, wday = 6, yweeks = 52, },
  { y = 2012, m = 1, d = 1, yweek = 1, wday = 0, yweeks = 53, },
} --- TestData_01

local TestData_04 = {
  YearStartWeekDay = 4,
  { y = 2018, m = 1, d = 1, yweek = 1, wday = 1, yweeks = 52, },
  { y = 2013, m = 1, d = 1, yweek = 1, wday = 2, yweeks = 52, },
  { y = 2014, m = 1, d = 1, yweek = 1, wday = 3, yweeks = 52, },
  { y = 2015, m = 1, d = 1, yweek = 1, wday = 4, yweeks = 53, },
  { y = 2016, m = 1, d = 1, yweek = 0, wday = 5, yweeks = 52, },
  { y = 2011, m = 1, d = 1, yweek = 0, wday = 6, yweeks = 52, },
  { y = 2012, m = 1, d = 1, yweek = 0, wday = 0, yweeks = 52, },
} --- TestData_04

local TestData_06 = {
  YearStartWeekDay = 6,
  { y = 2018, m = 1, d = 1, yweek = 1, wday = 1, yweeks = 52, },
  { y = 2013, m = 1, d = 1, yweek = 1, wday = 2, yweeks = 53, },
  { y = 2014, m = 1, d = 1, yweek = 0, wday = 3, yweeks = 52, },
  { y = 2015, m = 1, d = 1, yweek = 0, wday = 4, yweeks = 52, },
  { y = 2016, m = 1, d = 1, yweek = 0, wday = 5, yweeks = 52, },
  { y = 2011, m = 1, d = 1, yweek = 0, wday = 6, yweeks = 52, },
  { y = 2012, m = 1, d = 1, yweek = 0, wday = 0, yweeks = 52, },
} --- TestData_06

local TestData_07 = {
  YearStartWeekDay = 7,
  { y = 2018, m = 1, d = 1, yweek = 1, wday = 1, yweeks = 53, },
  { y = 2013, m = 1, d = 1, yweek = 0, wday = 2, yweeks = 52, },
  { y = 2014, m = 1, d = 1, yweek = 0, wday = 3, yweeks = 52, },
  { y = 2015, m = 1, d = 1, yweek = 0, wday = 4, yweeks = 52, },
  { y = 2016, m = 1, d = 1, yweek = 0, wday = 5, yweeks = 52, },
  { y = 2011, m = 1, d = 1, yweek = 0, wday = 6, yweeks = 52, },
  { y = 2012, m = 1, d = 1, yweek = 0, wday = 0, yweeks = 53, },
} --- TestData_07

local c = datim.newConfig()

local TestData = TestData_01
--local TestData = TestData_04
--local TestData = TestData_06
--local TestData = TestData_07

for k = 1, #TestData do
  local td = TestData[k]
  if TestData[k] then
    --local d = datim.newDate(td.y, td.m, td.d)
    local ld = {}
    local y, m, d = c:getYearLastDay(td.y)
    ld.y, ld.m, ld.d = y, m, d
    ld.yweek = c:getYearWeek(y, m, d, TestData.YearStartWeekDay)
    ld.wday = c:getWeekDay(y, m, d)
    td.Last = ld
    
    local nd = {}
    nd.y, nd.m, nd.d = y + 1, 1, 1
    nd.yweek = c:getYearWeek(nd.y, nd.m, nd.d, TestData.YearStartWeekDay)
    nd.wday = c:getWeekDay(nd.y, nd.m, nd.d)
    td.Newy = nd
  end
end --
--logShow(TestData, "TestData", "wM d4")

local function getYearWeeks (k) --> (number)
  local Data = TestData[k]
  --local y, m, d = Data.y, Data.m, Data.d
  local Last, Newy = Data.Last, Data.Newy
  --local ly, lm, ld = Last.y, Last.m, Last.d

  return Last.yweek - Newy.yweek --+ 1
end ---- getYearWeeks

local TestFmt = "%04d = %02d %s %02d weeks: %02d / %02d | %02d −> %1d / %1d | %1d"

local function TestFormat (k)
  local Data = TestData[k]
  local Last, Newy = Data.Last, Data.Newy
  local y, m, d = Data.y, Data.m, Data.d

  local YearWeeks = getYearWeeks(k)

  return TestFmt:format(y, --m, d,
                        YearWeeks,
                        YearWeeks == Data.yweeks and '==' or '<>',
                        Data.yweeks,

                        Data.yweek, Last.yweek, Newy.yweek,
                        Data.wday, Last.wday, Newy.wday
                       )
end -- TestFormat

local SepLine = "─────────────────"

local t = {}
t[#t+1] = ("== %d =="):format(TestData.YearStartWeekDay)
t[#t+1] = "yyyy = Ws ?? ws weeks: yw / lw / nw −> d / l | n"
t[#t+1] = SepLine

for k = 1, #TestData do
  if not TestData[k] then
    t[#t+1] = SepLine
  else
    t[#t+1] = TestFormat(k)
  end
end --

t[#t+1] = SepLine

far.Show(unpack(t))
--------------------------------------------------------------------------------
