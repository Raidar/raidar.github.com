--[[ MonthWeekDay Test ]]--

--------------------------------------------------------------------------------

----------------------------------------
local datim = require "Rh_Scripts.Utils.DateTime"

----------------------------------------
--local context = context
local logShow = context.ShowInfo

local numbers = require 'context.utils.useNumbers'

local divf  = numbers.divf
local divm  = numbers.divm
local round = numbers.round

--------------------------------------------------------------------------------
local t = {}
local dt = os.date("*t")

local d = datim.newDate(dt.year, dt.month, dt.day)

local c = d.config
t[#t+1] = "──── TConfig ────"
--t[#t+1] = "isLeapYear  = "..tostring(c:isLeapYear(d.y))
--t[#t+1] = "getLeapDays = "..("%1d"):format(c:getLeapDays(d.y))
--t[#t+1] = "getYearDay  = "..("%03d"):format(c:getYearDay(d.y, d.m, d.d))
--t[#t+1] = "getYearWeek = "..(" %02d"):format(c:getYearWeek(d.y, d.m, d.d))
--t[#t+1] = "getWeekDay  = "..("  %1d"):format(c:getWeekDay(d.y, d.m, d.d))
--t[#t+1] = "getEraDay   = "..("%d"):format(c:getEraDay(d.y, d.m, d.d))

--local TestFmt = "%04d-%02d-%02d %s %02d  %1d--%1d | "
local TestFmt = "%04d-%02d-%02d %s %02d  %1d--%1d | %2d+%1d | %02d %02d"
local SepLine = "─────────────────"
t[#t+1] = "yyyy-mm-dd ?? dD mw-wd"
t[#t+1] = SepLine

local TestData = {
  { y = 2013, m = 02, d = 20, mweek = 4, wday = 3, mw = -2, wd = 3, },
  { y = 2013, m = 02, d = 21, mweek = 4, wday = 4, mw = -2, wd = 4, },
  { y = 2013, m = 02, d = 22, mweek = 4, wday = 5, mw = -1, wd = 5, },
  { y = 2013, m = 02, d = 23, mweek = 4, wday = 6, mw = -1, wd = 6, },
  { y = 2013, m = 02, d = 24, mweek = 4, wday = 0, mw = -1, wd = 0, },
  { y = 2013, m = 02, d = 28, mweek = 5, wday = 4, mw = -1, wd = 4, },
  { y = 2013, m = 03, d = 29, mweek = 5, wday = 5, mw = -1, wd = 5, },
  { y = 2013, m = 03, d = 30, mweek = 5, wday = 6, mw = -1, wd = 6, },
  false,
  { y = 2013, m = 03, d = 01, mweek = 1, wday = 5, mw =  1, wd = 5, },
  { y = 2013, m = 03, d = 07, mweek = 2, wday = 4, mw =  1, wd = 4, },
  { y = 2013, m = 03, d = 08, mweek = 2, wday = 5, mw =  2, wd = 5, },
} ---

local function getMonthWeekDay (k) --> (number)
  local Data = TestData[k]
  local y, m = Data.y, Data.m
  local mw, wd = Data.mw, Data.wd

  local c = datim.newConfig()
  local DayPerWeek = c.DayPerWeek

  if mw < 0 then
    local LastDay = c:getMonthDays(y, m)
    local LastWeekDay = c:getWeekDay(y, m, LastDay)
    if LastWeekDay == 0 then LastWeekDay = DayPerWeek end
    local Shift = LastWeekDay >= wd and 1 or 0
    return LastDay +  DayPerWeek * (mw + Shift) + (wd - LastWeekDay)
  else
    local StartDay = 1
    local StartWeekDay = c:getWeekDay(y, m, StartDay)
    if StartWeekDay == 0 then StartWeekDay = DayPerWeek end
    local Shift = StartWeekDay <= wd and 1 or 0
    return StartDay + DayPerWeek * (mw - Shift) + (wd - StartWeekDay)
  end

  return 0
end ---- getMonthWeekDay

local function TestFormat (k)
  local Data = TestData[k]
  local y, m, d = Data.y, Data.m, Data.d
  local mw, wd = Data.mw, Data.wd

  local DayPerWeek = c.DayPerWeek
  local MonthWeek = c:getMonthWeek(y, m, d)
  local WeekDay = c:getWeekDay(y, m, d)
  --local YearStartDay = c:getWeekDay(y, 01, 01)
  --local Day = getMonthWeekDay(k)
  local Day = c:getMonthWeekDay(y, m, mw, wd)

  local StartDay = 1
  local StartWeekDay = c:getWeekDay(y, m, StartDay)
  if StartWeekDay == 0 then StartWeekDay = DayPerWeek end
  local LastDay = c:getMonthDays(y, m)
  local LastWeekDay = c:getWeekDay(y, m, LastDay)
  if LastWeekDay == 0 then LastWeekDay = DayPerWeek end

  return TestFmt:format(y, m, d,
                        d == Day and '==' or '<>',
                        Day,
                        MonthWeek,
                        WeekDay,
                        mw,
                        wd,
                        mw < 0 and LastDay or StartDay,
                        mw < 0 and LastWeekDay or StartWeekDay
                       )
end -- TestFormat

for k = 1, #TestData do
  if not TestData[k] then
    t[#t+1] = SepLine
  else
    t[#t+1] = TestFormat(k)
  end
end --

t[#t+1] = SepLine

far.Show(unpack(t))
--------------------------------------------------------------------------------
