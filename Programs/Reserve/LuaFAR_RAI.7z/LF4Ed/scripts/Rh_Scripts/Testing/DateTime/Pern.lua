--[[ Pern Test ]]--

--------------------------------------------------------------------------------

----------------------------------------
local datim = require "Rh_Scripts.Utils.DateTime"

local cfgPern = require "Rh_Scripts.Utils.DateTime.Pern"

----------------------------------------
--local context = context
local logShow = context.ShowInfo

--------------------------------------------------------------------------------

local TConfig = cfgPern.TConfig
--logShow(TConfig, "Pern TConfig", "w")

local Config = datim.newConfig(TConfig)

local flags = "w"
--local flags = "wM d3 f"
logShow(Config, "Pern Config", flags)
--------------------------------------------------------------------------------
