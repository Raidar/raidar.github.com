--[[ Key types ]]--

----------------------------------------
--[[ description:
  -- Information about keys.
  -- Информация о клавишах.
--]]
----------------------------------------
--[[ uses:
  [LuaFAR].
  -- group: Keys.
--]]

--------------------------------------------------------------------------------
--local _G = _G

----------------------------------------
local bit = bit64
--logShow(bit, "bit")
local band, bor = bit.band, bit.bor
local bnot, bxor = bit.bnot, bit.bxor
local bshl, bshr = bit.lshift, bit.rshift

----------------------------------------
--[[
local hex = utils.hex

local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

--------------------------------------------------------------------------------
local keys = {} -- Keys

---------------------------------------- Modifiers naming
-- Основные модификаторы
keys.SKEY_Base = { "CTRL", "ALT", "SHIFT" }
keys.SKEY_Text = { -- Используемые модификаторы
   C =  "Ctrl",  A =  "Alt",  S =  "Shift",
  LC = "LCtrl", LA = "LAlt", LS = "LShift",
  RC = "RCtrl", RA = "RAlt", RS = "RShift", }
keys.SKEY_Mods = { -- Обозначения модификаторов
   CTRL =  "C",  ALT =  "A",  SHIFT =  "S",
  LCTRL = "LC", LALT = "LA", LSHIFT = "LS",
  RCTRL = "RC", RALT = "RA", RSHIFT = "RS", }

---------------------------------------- VK_ key codes
-- Модификаторы VK_ клавиш.
local VKF_ = {
  CTRL  = 0x010000,
  ALT   = 0x020000,
  SHIFT = 0x040000,
} -- VKF_ / VKEY_Flags
keys.VKEY_Flags = VKF_

keys.VKEY_ComboFlags = {
  CTRL  = VKF_.CTRL,
  ALT   = VKF_.ALT,
  SHIFT = VKF_.SHIFT,
  CTRLSHIFT = VKF_.CTRL + VKF_.SHIFT,
  ALTSHIFT  = VKF_.ALT + VKF_.SHIFT,
  CTRLALT   = VKF_.CTRL + VKF_.ALT,
  CTRLALTSHIFT = VKF_.CTRL + VKF_.ALT + VKF_.SHIFT,
} -- VKEY_ComboFlags

-- ControlKeyState.
local VKCS_ = {
  RIGHT_ALT_PRESSED  = 0x0001,
  LEFT_ALT_PRESSED   = 0x0002,
  RIGHT_CTRL_PRESSED = 0x0004,
  LEFT_CTRL_PRESSED  = 0x0008,
  SHIFT_PRESSED = 0x0010,
  NUMLOCK_ON    = 0x0020,
  SCROLLLOCK_ON = 0x0040,
  CAPSLOCK_ON   = 0x0080,
  ENHANCED_KEY  = 0x0100,
} --- VKCS_ / VKEY_CtrlState
keys.VKEY_CtrlState = VKCS_

-- ControlKeyState combos.
local VKCM_ = {
  CTRLALTSHIFT = 0,

  RALT   = VKCS_.RIGHT_ALT_PRESSED,
  LALT   = VKCS_.LEFT_ALT_PRESSED,

  RCTRL  = VKCS_.RIGHT_CTRL_PRESSED,
  LCTRL  = VKCS_.LEFT_CTRL_PRESSED,

  SHIFT  = VKCS_.SHIFT_PRESSED,
  ALT    = VKCS_.RIGHT_ALT_PRESSED  + VKCS_.LEFT_ALT_PRESSED,
  CTRL   = VKCS_.RIGHT_CTRL_PRESSED + VKCS_.LEFT_CTRL_PRESSED,

  --NUMLOCK    = 0x0020,
  --SCROLLLOCK = 0x0040,
  --CAPSLOCK   = 0x0080,
  --ENHANCED   = 0x0100,
} -- VKC_ / VKEY_CtrlMods
keys.VKEY_CtrlMods = VKCM_

VKCM_.CTRLALTSHIFT = VKCM_.CTRL + VKCM_.ALT + VKCM_.SHIFT -- Any key pressed

-- Маски управляющих состояний.
keys.VKEY_CtrlMask = 0xFF
keys.VKEY_CtrlKind = VKCM_.CTRLALTSHIFT

-- Маски клавиш и модификаторов.
local VKM_CSmod = 0x10
keys.VKEY_CSmod = VKM_CSmod
keys.VKEY_KeyMask = 0x000001FF
keys.VKEY_ModMask = bshl(0x01FF, VKM_CSmod)

local VKM_ = {
  CTRL    = bshl(VKCS_.LEFT_CTRL_PRESSED, VKM_CSmod),
  ALT     = bshl(VKCS_.LEFT_ALT_PRESSED, VKM_CSmod),
  SHIFT   = bshl(VKCS_.SHIFT_PRESSED, VKM_CSmod),

  RCTRL   = bshl(VKCS_.RIGHT_CTRL_PRESSED, VKM_CSmod),
  RALT    = bshl(VKCS_.RIGHT_ALT_PRESSED, VKM_CSmod),
  --RSHIFT  = bshl(VKCS_.SHIFT_PRESSED, VKM_CSmod),

  NUM_ON    = bshl(VKCS_.NUMLOCK_ON, VKM_CSmod),
  SCROLL_ON = bshl(VKCS_.SCROLLLOCK_ON, VKM_CSmod),
  CAPS_ON   = bshl(VKCS_.CAPSLOCK_ON, VKM_CSmod),
  ENHANCED  = bshl(VKCS_.ENHANCED_KEY, VKM_CSmod),
} --- VKEY_Mods
keys.VKEY_Mods = VKM_
--logShow({ VKM_ = VKM_, VKCS_ = VKCS_ }, "VKM_", "x10")

-- TODO: Сделать автозаполнение по VKM_ .
keys.VKEY_ComboMods = {
  CTRL   = VKM_.CTRL,
  ALT    = VKM_.ALT,
  SHIFT  = VKM_.SHIFT,

  CTRLSHIFT   = VKM_.CTRL + VKM_.SHIFT,
  ALTSHIFT    = VKM_.ALT  + VKM_.SHIFT,
  CTRLALT     = VKM_.CTRL + VKM_.ALT,
  CTRLALTSHIFT  = VKM_.CTRL + VKM_.ALT + VKM_.SHIFT,

  RCTRL  = VKM_.RCTRL,
  RALT   = VKM_.RALT,
  --RSHIFT = VKM_.RSHIFT,

  RCTRLSHIFT  = VKM_.RCTRL + VKM_.SHIFT,
  RALTSHIFT   = VKM_.RALT  + VKM_.SHIFT,
  RCTRLALT    = VKM_.RCTRL + VKM_.ALT,
  --CTRLRSHIFT  = VKM_.CTRL + VKM_.RSHIFT,
  --ALTRSHIFT   = VKM_.ALT  + VKM_.RSHIFT,
  CTRLRALT    = VKM_.CTRL + VKM_.RALT,
  --RCTRLRSHIFT = VKM_.RCTRL + VKM_.RSHIFT,
  --RALTRSHIFT  = VKM_.RALT  + VKM_.RSHIFT,
  RCTRLRALT   = VKM_.RCTRL + VKM_.RALT,

  RCTRLALTSHIFT = VKM_.RCTRL + VKM_.ALT  + VKM_.SHIFT,
  CTRLRALTSHIFT = VKM_.CTRL  + VKM_.RALT + VKM_.SHIFT,
  --CTRLALTRSHIFT = VKM_.CTRL  + VKM_.ALT  + VKM_.RSHIFT,
  RCTRLRALTSHIFT = VKM_.RCTRL + VKM_.RALT  + VKM_.SHIFT,
  --RCTRLALTRSHIFT = VKM_.RCTRL + VKM_.ALT   + VKM_.RSHIFT,
  --CTRLRALTRSHIFT = VKM_.CTRL  + VKM_.RALT  + VKM_.RSHIFT,
  --RCTRLRALTRSHIFT = VKM_.RCTRL + VKM_.RALT + VKM_.RSHIFT,
} -- FKEY_ComboMods

keys.VKEY_SMods = {
  CTRL   = "CTRL",
  ALT    = "ALT",
  SHIFT  = "SHIFT",

  --LCTRL   = "CTRL",
  --LALT    = "ALT",
  --LSHIFT = "SHIFT",

  RCTRL  = "RCTRL",
  RALT   = "RALT",
  --RSHIFT = "RSHIFT",

  -- NUM_ON   = "NUM_ON",
  -- SCROLL_ON= "SCROLL_ON",
  -- CAPS_ON  = "CAPS_ON",
  -- ENHANCED = "ENHANCED",
} -- FKEY_SMods

---------------------------------------- VK_ codes/names
-- Коды VK_ клавиш по их названию.
local VK_ = {
  -- Mouse buttons
  LBUTTON   = 0x01,
  RBUTTON   = 0x02,
  CANCEL    = 0x03, -- Ctrl-Break
  MBUTTON   = 0x04,
  XBUTTON1  = 0x05,
  XBUTTON2  = 0x06,
  -- Some characters
  -- 0x07 -- Undefined
  BACK      = 0x08, -- BS
  TAB       = 0x09, -- Tab
  -- 0x0A - 0x0B -- Reserved
  CLEAR     = 0x0C,
  RETURN    = 0x0D, -- Enter
  -- 0x0E - 0x0F -- Undefined
  -- Modifiers
  SHIFT     = 0x10, -- Shift
  CONTROL   = 0x11, -- Ctrl
  MENU      = 0x12, -- Alt
  -- Other keys
  PAUSE     = 0x13,
  CAPITAL   = 0x14, -- Caps Lock
  -- IME keys
  KANA      = 0x15, HANGUL = 0x15, HANGUEL = 0x15,
  -- 0x16 -- Undefined
  JUNJA     = 0x17,
  FINAL     = 0x18,
  HANJA     = 0x19, KANJI  = 0x19,
  -- 0x1A -- Undefined
  ESCAPE    = 0x1B, -- Esc
  CONVERT   = 0x1C,
  NONCONVERT= 0x1D,
  ACCEPT    = 0x1E,
  MODECHANGE= 0x1F,
  SPACE     = 0x20,
  -- Arrow keys
  PRIOR     = 0x21, -- PgUp
  NEXT      = 0x22, -- PgDn
  END       = 0x23,
  HOME      = 0x24,
  LEFT      = 0x25,
  UP        = 0x26,
  RIGHT     = 0x27,
  DOWN      = 0x28,
  -- Other keys
  SELECT    = 0x29,
  PRINT     = 0x2A,
  EXECUTE   = 0x2B,
  SNAPSHOT  = 0x2C, -- Print Screen
  INSERT    = 0x2D, -- Ins
  DELETE    = 0x2E, -- Del
  HELP      = 0x2F,
  -- 0x30 - 0x39 -- Digits
  -- 0x3A - 0x40 -- Undefined
  -- 0x41 - 0x5A -- Letters
  -- Modifiers
  LWIN      = 0x5B,
  RWIN      = 0x5C,
  APPS      = 0x5D,
  -- 0x5E -- Reserved
  SLEEP     = 0x5F,
  -- Numpad keys
  NUMPAD0   = 0x60,
  NUMPAD1   = 0x61, NUMPAD2   = 0x62, NUMPAD3   = 0x63,
  NUMPAD4   = 0x64, NUMPAD5   = 0x65, NUMPAD6   = 0x66,
  NUMPAD7   = 0x67, NUMPAD8   = 0x68, NUMPAD9   = 0x69,
  MULTIPLY  = 0x6A, ADD       = 0x6B, SEPARATOR = 0x6C,
  SUBTRACT  = 0x6D, DECIMAL   = 0x6E, DIVIDE    = 0x6F,
  -- Function keys
  F1  = 0x70, F2  = 0x71, F3  = 0x72, F4  = 0x73,
  F5  = 0x74, F6  = 0x75, F7  = 0x76, F8  = 0x77,
  F9  = 0x78, F10 = 0x79, F11 = 0x7A, F12 = 0x7B,
  F13 = 0x7C, F14 = 0x7D, F15 = 0x7E, F16 = 0x7F,
  F17 = 0x80, F18 = 0x81, F19 = 0x82, F20 = 0x83,
  F21 = 0x84, F22 = 0x85, F23 = 0x86, F24 = 0x87,
  -- 0x88 - 0x8F -- Not used
  NUMLOCK   = 0x90,
  SCROLL    = 0x91,
  -- OEM keys
  OEM_NEC_EQUAL  = 0x92,
  OEM_FJ_MASSHOU = 0x93,
  OEM_FJ_TOUROKU = 0x94,
  OEM_FJ_LOYA    = 0x95,
  OEM_FJ_ROYA    = 0x96,
  -- 0x97 - 0x9F -- Not used
  -- Modifiers
  LSHIFT    = 0xA0,
  RSHIFT    = 0xA1,
  LCONTROL  = 0xA2,
  RCONTROL  = 0xA3,
  LMENU     = 0xA4,
  RMENU     = 0xA5,
  -- Multimedia
  BROWSER_BACK      = 0xA6,
  BROWSER_FORWARD   = 0xA7,
  BROWSER_REFRESH   = 0xA8,
  BROWSER_STOP      = 0xA9,
  BROWSER_SEARCH    = 0xAA,
  BROWSER_FAVORITES = 0xAB,
  BROWSER_HOME      = 0xAC,
  VOLUME_MUTE       = 0xAD,
  VOLUME_DOWN       = 0xAE,
  VOLUME_UP         = 0xAF,
  MEDIA_NEXT_TRACK  = 0xB0,
  MEDIA_PREV_TRACK  = 0xB1,
  MEDIA_STOP        = 0xB2,
  MEDIA_PLAY_PAUSE  = 0xB3,
  LAUNCH_MAIL       = 0xB4,
  LAUNCH_MEDIA_SELECT = 0xB5,
  LAUNCH_APP1       = 0xB6,
  LAUNCH_APP2       = 0xB7,
  -- 0xB8 - 0xB9 -- Reserved
  -- OEM standard keys
  OEM_1     = 0xBA, -- ";:"
  OEM_PLUS  = 0xBB, -- "=+"
  OEM_COMMA = 0xBC, -- ",<"
  OEM_MINUS = 0xBD, -- "-_"
  OEM_PERIOD= 0xBE, -- ".>"
  OEM_2     = 0xBF, -- "/?"
  OEM_3     = 0xC0, -- "`~"
  -- 0xC1 - 0xD7 -- Reserved
  -- 0xD8 - 0xDA -- Not used
  OEM_4     = 0xDB, -- "[{"
  OEM_5     = 0xDC, -- "\\|"
  OEM_6     = 0xDD, -- "]}"
  OEM_7     = 0xDE, -- "'"'"'
  OEM_8     = 0xDF, -- Miscellaneous chars
  -- 0xE0 -- Reserved
  -- Other keys
  -- 0xE1 -- OEM specific
  OEM_102   = 0xE2, -- "<>" / "\\|"
  -- 0xE3 - 0xE4 -- OEM specific
  PROCESSKEY= 0xE5,
  -- 0xE6 -- OEM specific
  PACKET    = 0xE7,
  -- 0xE8 -- Not used
  -- Only used by Nokia
  OEM_RESET     = 0xE9,
  OEM_JUMP      = 0xEA,
  OEM_PA1       = 0xEB,
  OEM_PA2       = 0xEC,
  OEM_PA3       = 0xED,
  OEM_WSCTRL    = 0xEE,
  OEM_CUSEL     = 0xEF,
  OEM_ATTN      = 0xF0,
  OEM_FINNISH   = 0xF1,
  OEM_COPY      = 0xF2,
  OEM_AUTO      = 0xF3,
  OEM_ENLW      = 0xF4,
  OEM_BACKTAB   = 0xF5,
  ATTN      = 0xF6,
  CRSEL     = 0xF7,
  EXSEL     = 0xF8,
  EREOF     = 0xF9,
  PLAY      = 0xFA,
  ZOOM      = 0xFB,
  NONAME    = 0xFC,
  PA1       = 0xFD,
  OEM_CLEAR = 0xFE,
  -- 0xFF -- Multimedia keys using ScanCode
} --- VK_ / VKEY_Keys
keys.VKEY_Keys = VK_

---------------------------------------- VK_ scan codes
keys.VKEY_ScanCodes = {
  -- Character keys
  [VK_.ESCAPE]      = 0x01, -- Esc / Escape

  [0x31] = 0x02, [0x32] = 0x03, [0x33] = 0x04, [0x34] = 0x05, [0x35] = 0x06, -- 1 2 3 4 5
  [0x36] = 0x07, [0x37] = 0x08, [0x38] = 0x09, [0x39] = 0x0A, [0x30] = 0x0B, -- 6 7 8 9 0

  [VK_.OEM_MINUS]   = 0x0C, -- -
  [VK_.OEM_PLUS]    = 0x0D, -- =
  [VK_.BACK]        = 0x0E, -- BS / BackSpace
  [VK_.TAB]         = 0x0F, -- Tab

  [0x51] = 0x10, [0x57] = 0x11, [0x45] = 0x12, [0x52] = 0x13, [0x54] = 0x14, -- q w e r t
  [0x59] = 0x15, [0x55] = 0x16, [0x49] = 0x17, [0x4F] = 0x18, [0x50] = 0x19, -- y u i o p

  [VK_.OEM_4]       = 0x1A,
  [VK_.OEM_6]       = 0x1B, -- p [ ]
  [VK_.RETURN]      = 0x1C, -- Enter / Return
  --[VK_.RETURN]      = 0x11C,-- Num Enter
  [VK_.CONTROL]     = 0x1D, -- Left Ctrl
  --[VK_.LCONTROL]    = 0x1D, -- Left Ctrl
  [VK_.RCONTROL]    = 0x11D,-- Right Ctrl

  [0x41] = 0x1E, [0x53] = 0x1F, [0x44] = 0x20, [0x46] = 0x21, [0x47] = 0x22, -- a s d f g
  [0x48] = 0x23, [0x4A] = 0x24, [0x4B] = 0x25, [0x4C] = 0x26,                -- h j k l

  [VK_.OEM_1]       = 0x27, -- ;
  [VK_.OEM_7]       = 0x28, -- '
  [VK_.OEM_3]       = 0x29, -- `
  [VK_.SHIFT]       = 0x2A, -- Left Shift
  --[VK_.LSHIFT]      = 0x2A, -- Left Shift
  [VK_.RSHIFT]      = 0x36, -- Right Shift
  [VK_.OEM_5]       = 0x2B, -- \

  [0x5A] = 0x2C, [0x58] = 0x2D, [0x43] = 0x2E, [0x56] = 0x2F, [0x42] = 0x30, -- z x c v b
  [0x4E] = 0x31, [0xDA] = 0x32,                                              -- n m

  [VK_.OEM_COMMA]   = 0x33, -- ,
  [VK_.OEM_PERIOD]  = 0x34, -- .
  [VK_.OEM_2]       = 0x35, -- /
  [VK_.SNAPSHOT]    = 0x37, -- Print Screen
  [VK_.MENU]        = 0x38, -- Alt
  [VK_.SPACE]       = 0x39, -- Space
  [VK_.CAPITAL]     = 0x3A, -- Caps Lock

  -- Function keys
  [VK_.F1]  = 0x3B, [VK_.F2]  = 0x3C, [VK_.F3]  = 0x3D, -- F1 F2 F3
  [VK_.F4]  = 0x3E, [VK_.F5]  = 0x3F, [VK_.F6]  = 0x40, -- F4 F5 F6
  [VK_.F7]  = 0x41, [VK_.F8]  = 0x42, [VK_.F9]  = 0x43, -- F7 F8 F9
  [VK_.F10] = 0x44, -- F10

  [VK_.PAUSE]       = 0x45, -- Pause
  [VK_.SCROLL]      = 0x46, -- Scroll Lock

  -- Numpad keys
  [VK_.NUMPAD7] = 0x47, -- 7
  [VK_.NUMPAD8] = 0x48, -- 8
  [VK_.NUMPAD9] = 0x49, -- 9
  [VK_.SUBTRACT]    = 0x4A, -- Num -
  [VK_.NUMPAD4] = 0x4B, -- 4
  [VK_.NUMPAD5] = 0x4C, -- 5
  [VK_.NUMPAD6] = 0x4D, -- 6
  [VK_.ADD]         = 0x4E, -- Num +
  [VK_.NUMPAD1] = 0x4F, -- 1
  [VK_.NUMPAD2] = 0x50, -- 2
  [VK_.NUMPAD3] = 0x51, -- 3

  [VK_.NUMPAD0] = 0x52, -- 0
  [VK_.DECIMAL] = 0x53, -- Dot
  -- 0x54 - 0x56

  [VK_.DIVIDE]      = 0x135, -- Num /
  [VK_.MULTIPLY]    = 0x137, -- Num *

  -- Function keys
  [VK_.F11] = 0x57, [VK_.F12] = 0x58, -- F11, F12

  -- 0x59 - 0x5A
  [VK_.LWIN]        = 0x5B, -- Left Win
  [VK_.RWIN]        = 0x5C, -- Right Win
  [VK_.APPS]        = 0x5D, -- Apps key
  ACPI_POWER        = 0x5E, -- ACPI Power
  ACPI_SLEEP        = 0x5F, -- ACPI Sleep
  -- 0x60 - 0x62
  ACPI_WAKE         = 0x63, -- ACPI Wake
  -- 0x64 - 0x6F
  DBE_KATAKANA      = 0x70, -- Katakana
  -- 0x71--0x76
  DBE_SBCSCHAR      = 0x77, -- SBCS char
  -- 0x78
  [VK_.CONVERT]     = 0x79,
  -- 0x7A
  [VK_.NONCONVERT]  = 0x7B,
  -- 0x7C - 0x7E

  -- Additional keys
  [VK_.NUMLOCK] = 0x145, -- Num Lock
  -- 0x146
  [VK_.HOME]    = 0x147, -- Home
  [VK_.UP]      = 0x148, -- Up
  [VK_.PRIOR]   = 0x149, -- PgUp
  -- 0x14A
  [VK_.LEFT]    = 0x14B, -- Left
  [VK_.CLEAR]   = 0x14C, -- Clear
  [VK_.RIGHT]   = 0x14D, -- Right
  -- 0x14E
  [VK_.END]     = 0x14F, -- End
  [VK_.DOWN]    = 0x150, -- Down
  [VK_.NEXT]    = 0x151, -- PgDn
  [VK_.INSERT]  = 0x152, -- Insert
  [VK_.DELETE]  = 0x153, -- Delete
} -- VKEY_ScanCodes

---------------------------------------- VK_ specials
-- Клавиши-модификаторы.
keys.VKEY_Ext_VMods = {
  [VK_.SHIFT]       = VKM_.SHIFT,
  [VK_.CONTROL]     = VKM_.CTRL,
  [VK_.MENU]        = VKM_.ALT,
  --[VK_.LSHIFT]      = VKM_.SHIFT,
  --[VK_.LCONTROL]    = VKM_.CTRL,
  --[VK_.LMENU]       = VKM_.ALT,
  [VK_.RSHIFT]      = VKM_.RSHIFT,
  [VK_.RCONTROL]    = VKM_.RCTRL,
  [VK_.RMENU]       = VKM_.RALT,
} -- VKEY_Ext_VMods

-- Клавиши перемещения курсора.
keys.VKEY_ArrowNavs = {
  [VK_.LEFT]  = true,
  [VK_.UP]    = true,
  [VK_.RIGHT] = true,
  [VK_.DOWN]  = true,
  [VK_.HOME]  = true,
  [VK_.END]   = true,
  [VK_.PRIOR] = true,
  [VK_.NEXT]  = true,
  [VK_.CLEAR] = true,
} -- VKEY_ArrowNavs

-- Клавиши цифровой клавиатуры для перемещения курсора.
keys.VKEY_NumpadNavs = {
  [VK_.NUMPAD0] = VK_.INS,
  [VK_.NUMPAD1] = VK_.END,
  [VK_.NUMPAD2] = VK_.DOWN,
  [VK_.NUMPAD3] = VK_.NEXT,
  [VK_.NUMPAD4] = VK_.LEFT,
  [VK_.NUMPAD5] = VK_.CLEAR,
  [VK_.NUMPAD6] = VK_.RIGHT,
  [VK_.NUMPAD7] = VK_.HOME,
  [VK_.NUMPAD8] = VK_.UP,
  [VK_.NUMPAD9] = VK_.PRIOR,
} -- VKEY_NumpadNavs

---------------------------------------- FK_ key bases
-- Основные константы KEY_ клавиш.
local FKEY_ = {
  BASE = 0x00000,       -- BASE
  CHR     = 0x0020,
  CHR_EXT = 0x0080,
  CHR_END = 0xFFFF,
  EXT    = 0x10000,
  INT    = 0x20000,
  INT_2  = 0x30000,
  FK_END = 0x1FFFF,
  VK_0xFF     = 0x0100,
  VK_0xFF_LEN = 0x00FF,
  OP     = 0x100,
  OP_LEN = 0x0FF,
  SK_END = 0x3FFFF,
  END  = 0x3FFFF,       -- BASE END

  MACRO     = 0x80000,  -- MACRO
  MACRO_O   = 0x00000, -- - 0x003FF
  MACRO_C   = 0x00400, -- - 0x007FF
  MACRO_V   = 0x00800, -- - 0x00BFF
  MACRO_F   = 0x00C00, -- - 0x...
  MACRO_U   = 0x08000, -- - 0x...
  MACRO_END = 0xFFFFF,  -- MACRO END
} --- FKEY_

-- Базисы значений KEY_ клавиш.
local FKB_ = {
  -- BASE
  KEY_CHAR_BEGIN  = FKEY_.CHR,
  KEY_CHAR_EXT    = FKEY_.CHR_EXT,
  KEY_CHAR_END    = FKEY_.CHR_END,
  EXTENDED_KEY_BASE = FKEY_.EXT,
  KEY_FKEY_BEGIN  = FKEY_.EXT,
  KEY_END_FKEY    = FKEY_.FK_END,
  KEY_VK_0xFF_BEGIN = FKEY_.EXT + FKEY_.VK_0xFF,
  KEY_VK_0xFF_END   = FKEY_.EXT + FKEY_.VK_0xFF + FKEY_.VK_0xFF_LEN,
  INTERNAL_KEY_BASE   = FKEY_.INT,
  INTERNAL_KEY_BASE_2 = FKEY_.INT_2,
  KEY_OP_BASE       = FKEY_.INT_2 + FKEY_.OP,
  KEY_OP_ENDBASE    = FKEY_.INT_2 + FKEY_.OP + FKEY_.OP_LEN,
  KEY_END_SKEY    = FKEY_.SK_END,
  KEY_LAST_BASE   = FKEY_.END,
  -- MACRO
  KEY_MACRO_BASE    = FKEY_.MACRO,
  KEY_MACRO_OP_BASE = FKEY_.MACRO + FKEY_.MACRO_O,
  KEY_MACRO_C_BASE  = FKEY_.MACRO + FKEY_.MACRO_C,
  KEY_MACRO_V_BASE  = FKEY_.MACRO + FKEY_.MACRO_V,
  KEY_MACRO_F_BASE  = FKEY_.MACRO + FKEY_.MACRO_F,
  KEY_MACRO_U_BASE  = FKEY_.MACRO + FKEY_.MACRO_U,
  KEY_MACRO_ENDBASE = FKEY_.MACRO_END,
} -- FKB_ / FKEY_Base
keys.FKEY_Base = FKB_

-- Маски клавиш и модификаторов.
keys.FKEY_ChrMask = 0xFFFF
keys.FKEY_DefMask = 0x0001FFFF
keys.FKEY_KeyMask = 0x0003FFFF
keys.FKEY_ModMask = 0xFFF00000
--keys.FKEY_ModMask = 0xFF000000

-- Модификаторы KEY_ клавиш.
local FKM_ = {
  CTRL      = 0x01000000,
  ALT       = 0x02000000,
  SHIFT     = 0x04000000,

  RCTRL     = 0x10000000,
  RALT      = 0x20000000,
  RSHIFT    = 0x80000000,

  ALTDIGIT  = 0x40000000,
  --M_OEM     = 0x00100000,
  --M_SPEC    = 0x00200000,
} -- FKM_ / FKEY_Mods
keys.FKEY_Mods = FKM_

-- TODO: Сделать автозаполнение по FKM_ .
keys.FKEY_ComboMods = {
  CTRL   = FKM_.CTRL,
  ALT    = FKM_.ALT,
  SHIFT  = FKM_.SHIFT,

  CTRLSHIFT   = FKM_.CTRL + FKM_.SHIFT,
  ALTSHIFT    = FKM_.ALT  + FKM_.SHIFT,
  CTRLALT     = FKM_.CTRL + FKM_.ALT,
  CTRLALTSHIFT  = FKM_.CTRL + FKM_.ALT + FKM_.SHIFT,

  RCTRL  = FKM_.RCTRL,
  RALT   = FKM_.RALT,
  --RSHIFT = FKM_.RSHIFT,

  RCTRLSHIFT  = FKM_.RCTRL + FKM_.SHIFT,
  RALTSHIFT   = FKM_.RALT  + FKM_.SHIFT,
  RCTRLALT    = FKM_.RCTRL + FKM_.ALT,
  --CTRLRSHIFT  = FKM_.CTRL + FKM_.RSHIFT,
  --ALTRSHIFT   = FKM_.ALT  + FKM_.RSHIFT,
  CTRLRALT    = FKM_.CTRL + FKM_.RALT,
  --RCTRLRSHIFT = FKM_.RCTRL + FKM_.RSHIFT,
  --RALTRSHIFT  = FKM_.RALT  + FKM_.RSHIFT,
  RCTRLRALT   = FKM_.RCTRL + FKM_.RALT,

  RCTRLALTSHIFT = FKM_.RCTRL + FKM_.ALT  + FKM_.SHIFT,
  CTRLRALTSHIFT = FKM_.CTRL  + FKM_.RALT + FKM_.SHIFT,
  --CTRLALTRSHIFT = FKM_.CTRL  + FKM_.ALT  + FKM_.RSHIFT,
  RCTRLRALTSHIFT = FKM_.RCTRL + FKM_.RALT  + FKM_.SHIFT,
  --RCTRLALTRSHIFT = FKM_.RCTRL + FKM_.ALT   + FKM_.RSHIFT,
  --CTRLRALTRSHIFT = FKM_.CTRL  + FKM_.RALT  + FKM_.RSHIFT,
  --RCTRLRALTRSHIFT = FKM_.RCTRL + FKM_.RALT + FKM_.RSHIFT,
} -- FKEY_ComboMods

keys.FKEY_Masks = {
  CTRLMASK  = keys.FKEY_ModMask,
  KEY_MASKF = keys.FKEY_DefMask,
} -- FKEY_Masks

keys.FKEY_SMods = {
  CTRL   = "CTRL",
  ALT    = "ALT",
  SHIFT  = "SHIFT",

  --LCTRL   = "CTRL",
  --LALT    = "ALT",
  --LSHIFT = "SHIFT",

  RCTRL  = "RCTRL",
  RALT   = "RALT",
  -- RSHIFT   = "RSHIFT",

  -- ALTDIGIT = "ALTDIGIT",
  -- M_OEM    = "M_OEM",
  -- M_SPEC   = "M_SPEC",
} -- FKEY_SMods

---------------------------------------- FK_ codes/names
local EXTENDED_KEY_BASE   = FKB_.EXTENDED_KEY_BASE
local INTERNAL_KEY_BASE   = FKB_.INTERNAL_KEY_BASE
local INTERNAL_KEY_BASE_2 = FKB_.INTERNAL_KEY_BASE_2
local KEY_OP_BASE         = FKB_.KEY_OP_BASE

-- Код KEY_ клавиш по их названию.
local FK_ = {
  -- KEY_CTRLMASK --
  BRACKET     = 0x5B, -- '['
  BACKBRACKET = 0x5D, -- ']'
  COMMA = 0x2C, -- ','
  QUOTE = 0x22, -- '"'
  DOT   = 0x2E, -- '.'
  SLASH     = 0x2F, -- '/'
  COLON     = 0x3A, -- ':'
  SEMICOLON = 0x3B, -- ';',
  BACKSLASH = 0x5C, -- '\\'
  BS    = 0x08,
  TAB   = 0x09,
  ENTER = 0x0D,
  ESC   = 0x1B,
  SPACE = 0x20,
  -- KEY_MASKF --

  -- KEY_FKEY_BEGIN --
  BREAK = EXTENDED_KEY_BASE + VK_.CANCEL,
  -- Other keys
  PAUSE = EXTENDED_KEY_BASE + VK_.PAUSE,
  CAPSLOCK = EXTENDED_KEY_BASE + VK_.CAPITAL,
  -- Arrow keys
  PGUP  = EXTENDED_KEY_BASE + VK_.PRIOR,
  PGDN  = EXTENDED_KEY_BASE + VK_.NEXT,
  END   = EXTENDED_KEY_BASE + VK_.END,
  HOME  = EXTENDED_KEY_BASE + VK_.HOME,
  LEFT  = EXTENDED_KEY_BASE + VK_.LEFT,
  UP    = EXTENDED_KEY_BASE + VK_.UP,
  RIGHT = EXTENDED_KEY_BASE + VK_.RIGHT,
  DOWN  = EXTENDED_KEY_BASE + VK_.DOWN,
  -- Other keys
  PRNTSCRN = EXTENDED_KEY_BASE + VK_.SNAPSHOT,
  INS   = EXTENDED_KEY_BASE + VK_.INSERT,
  DEL   = EXTENDED_KEY_BASE + VK_.DELETE,
  -- Modifiers
  LWIN  = EXTENDED_KEY_BASE + VK_.LWIN,
  RWIN  = EXTENDED_KEY_BASE + VK_.RWIN,
  APPS  = EXTENDED_KEY_BASE + VK_.APPS,
  -- Other keys
  STANDBY  = EXTENDED_KEY_BASE + VK_.SLEEP,
  -- Numpad keys
  NUMPAD0  = EXTENDED_KEY_BASE + VK_.NUMPAD0,
  NUMPAD1  = EXTENDED_KEY_BASE + VK_.NUMPAD1,
  NUMPAD2  = EXTENDED_KEY_BASE + VK_.NUMPAD2,
  NUMPAD3  = EXTENDED_KEY_BASE + VK_.NUMPAD3,
  NUMPAD4  = EXTENDED_KEY_BASE + VK_.NUMPAD4,
  NUMPAD5  = EXTENDED_KEY_BASE + VK_.NUMPAD5,
  CLEAR    = EXTENDED_KEY_BASE + VK_.NUMPAD5, -- NUMPAD5
  NUMPAD6  = EXTENDED_KEY_BASE + VK_.NUMPAD6,
  NUMPAD7  = EXTENDED_KEY_BASE + VK_.NUMPAD7,
  NUMPAD8  = EXTENDED_KEY_BASE + VK_.NUMPAD8,
  NUMPAD9  = EXTENDED_KEY_BASE + VK_.NUMPAD9,
  MULTIPLY = EXTENDED_KEY_BASE + VK_.MULTIPLY,
  ADD      = EXTENDED_KEY_BASE + VK_.ADD,
  SUBTRACT = EXTENDED_KEY_BASE + VK_.SUBTRACT,
  DECIMAL  = EXTENDED_KEY_BASE + VK_.DECIMAL,
  DIVIDE   = EXTENDED_KEY_BASE + VK_.DIVIDE,
  -- Function keys
  F1  = EXTENDED_KEY_BASE + VK_.F1,
  F2  = EXTENDED_KEY_BASE + VK_.F2,
  F3  = EXTENDED_KEY_BASE + VK_.F3,
  F4  = EXTENDED_KEY_BASE + VK_.F4,
  F5  = EXTENDED_KEY_BASE + VK_.F5,
  F6  = EXTENDED_KEY_BASE + VK_.F6,
  F7  = EXTENDED_KEY_BASE + VK_.F7,
  F8  = EXTENDED_KEY_BASE + VK_.F8,
  F9  = EXTENDED_KEY_BASE + VK_.F9,
  F10 = EXTENDED_KEY_BASE + VK_.F10,
  F11 = EXTENDED_KEY_BASE + VK_.F11,
  F12 = EXTENDED_KEY_BASE + VK_.F12,
  F13 = EXTENDED_KEY_BASE + VK_.F13,
  F14 = EXTENDED_KEY_BASE + VK_.F14,
  F15 = EXTENDED_KEY_BASE + VK_.F15,
  F16 = EXTENDED_KEY_BASE + VK_.F16,
  F17 = EXTENDED_KEY_BASE + VK_.F17,
  F18 = EXTENDED_KEY_BASE + VK_.F18,
  F19 = EXTENDED_KEY_BASE + VK_.F19,
  F20 = EXTENDED_KEY_BASE + VK_.F20,
  F21 = EXTENDED_KEY_BASE + VK_.F21,
  F22 = EXTENDED_KEY_BASE + VK_.F22,
  F23 = EXTENDED_KEY_BASE + VK_.F23,
  F24 = EXTENDED_KEY_BASE + VK_.F24,
  -- Other keys
  NUMLOCK    = EXTENDED_KEY_BASE + VK_.NUMLOCK,
  SCROLLLOCK = EXTENDED_KEY_BASE + VK_.SCROLL,
  -- Multimedia
  BROWSER_BACK      = EXTENDED_KEY_BASE + VK_.BROWSER_BACK,
  BROWSER_FORWARD   = EXTENDED_KEY_BASE + VK_.BROWSER_FORWARD,
  BROWSER_REFRESH   = EXTENDED_KEY_BASE + VK_.BROWSER_REFRESH,
  BROWSER_STOP      = EXTENDED_KEY_BASE + VK_.BROWSER_STOP,
  BROWSER_SEARCH    = EXTENDED_KEY_BASE + VK_.BROWSER_SEARCH,
  BROWSER_FAVORITES = EXTENDED_KEY_BASE + VK_.BROWSER_FAVORITES,
  BROWSER_HOME      = EXTENDED_KEY_BASE + VK_.BROWSER_HOME,
  VOLUME_MUTE       = EXTENDED_KEY_BASE + VK_.VOLUME_MUTE,
  VOLUME_DOWN       = EXTENDED_KEY_BASE + VK_.VOLUME_DOWN,
  VOLUME_UP         = EXTENDED_KEY_BASE + VK_.VOLUME_UP,
  MEDIA_NEXT_TRACK  = EXTENDED_KEY_BASE + VK_.MEDIA_NEXT_TRACK,
  MEDIA_PREV_TRACK  = EXTENDED_KEY_BASE + VK_.MEDIA_PREV_TRACK,
  MEDIA_STOP        = EXTENDED_KEY_BASE + VK_.MEDIA_STOP,
  MEDIA_PLAY_PAUSE  = EXTENDED_KEY_BASE + VK_.MEDIA_PLAY_PAUSE,
  LAUNCH_MAIL       = EXTENDED_KEY_BASE + VK_.LAUNCH_MAIL,
  LAUNCH_MEDIA_SELECT
                    = EXTENDED_KEY_BASE + VK_.LAUNCH_MEDIA_SELECT,
  LAUNCH_APP1       = EXTENDED_KEY_BASE + VK_.LAUNCH_APP1,
  LAUNCH_APP2       = EXTENDED_KEY_BASE + VK_.LAUNCH_APP2,

  -- KEY_VK_0xFF_BEGIN --
  -- KEY_VK_0xFF_END --

  -- KEY_END_FKEY --

  CTRLALTSHIFTPRESS    = INTERNAL_KEY_BASE + 1,
  CTRLALTSHIFTRELEASE  = INTERNAL_KEY_BASE + 2,

  MSWHEEL_UP    = INTERNAL_KEY_BASE + 3,
  MSWHEEL_DOWN  = INTERNAL_KEY_BASE + 4,
  
  --RCTRLALTSHIFTPRESS   = INTERNAL_KEY_BASE + 7,
  --RCTRLALTSHIFTRELEASE = INTERNAL_KEY_BASE + 8,
  NUMDEL   = INTERNAL_KEY_BASE + 0x9,
  NUMENTER = INTERNAL_KEY_BASE + 0xB,

  MSWHEEL_LEFT  = INTERNAL_KEY_BASE + 0xC,
  MSWHEEL_RIGHT = INTERNAL_KEY_BASE + 0xD,

  MSLCLICK  = INTERNAL_KEY_BASE + 0x0F,
  MSRCLICK  = INTERNAL_KEY_BASE + 0x10,
  MSM1CLICK = INTERNAL_KEY_BASE + 0x11,
  MSM2CLICK = INTERNAL_KEY_BASE + 0x12,
  MSM3CLICK = INTERNAL_KEY_BASE + 0x13,

  NONE = INTERNAL_KEY_BASE_2 + 1,
  IDLE = INTERNAL_KEY_BASE_2 + 2,

  --DRAGCOPY             = INTERNAL_KEY_BASE_2 + 3,
  --DRAGMOVE             = INTERNAL_KEY_BASE_2 + 4,

  KILLFOCUS            = INTERNAL_KEY_BASE_2 + 6,
  GOTFOCUS             = INTERNAL_KEY_BASE_2 + 7,
  CONSOLE_BUFFER_RESIZE= INTERNAL_KEY_BASE_2 + 8,

  -- KEY_OP_BASE --
  --OP_XLAT              = KEY_OP_BASE + 0,
  --OP_DATE              = KEY_OP_BASE + 1,
  --OP_PLAINTEXT         = KEY_OP_BASE + 2,
  --OP_SELWORD           = KEY_OP_BASE + 3,
  -- KEY_OP_ENDBASE --

  -- KEY_END_SKEY --
  -- KEY_LAST_BASE --

} --- FK_ / FKEY_Keys
keys.FKEY_Keys = FK_

---------------------------------------- FK_ specials
-- Клавиши-модификаторы.
keys.FKEY_Mod_VExts = {
  [FKM_.CTRL]       = VK_.CONTROL,
  [FKM_.ALT]        = VK_.MENU,
  [FKM_.SHIFT]      = VK_.SHIFT,
  --[FKM_.LCTRL]      = VK_.LCONTROL,
  --[FKM_.LALT]       = VK_.LMENU,
  --[FKM_.LSHIFT]     = VK_.LSHIFT,
  [FKM_.RCTRL]      = VK_.RCONTROL,
  [FKM_.RALT]       = VK_.RMENU,
  [FKM_.RSHIFT]     = VK_.RSHIFT,
} -- FKEY_Mod_VExts

-- Клавиши перемещения курсора.
keys.FKEY_ArrowNavs = {
  [FK_.LEFT]  = true,
  [FK_.UP]    = true,
  [FK_.RIGHT] = true,
  [FK_.DOWN]  = true,
  [FK_.HOME]  = true,
  [FK_.END]   = true,
  [FK_.PGUP]  = true,
  [FK_.PGDN]  = true,
  [FK_.CLEAR] = true,
} -- FKEY_ArrowNavs

-- Клавиши цифровой клавиатуры для перемещения курсора.
keys.FKEY_NumpadNavs = {
  [FK_.NUMPAD0] = FK_.INS,
  [FK_.NUMPAD1] = FK_.END,
  [FK_.NUMPAD2] = FK_.DOWN,
  [FK_.NUMPAD3] = FK_.PGDN,
  [FK_.NUMPAD4] = FK_.LEFT,
  [FK_.NUMPAD5] = FK_.CLEAR,
  [FK_.NUMPAD6] = FK_.RIGHT,
  [FK_.NUMPAD7] = FK_.HOME,
  [FK_.NUMPAD8] = FK_.UP,
  [FK_.NUMPAD9] = FK_.PGUP,
} -- FKEY_NumpadNavs

-- "Клавиши" прокрутки мышью для перемещения курсора.
keys.FKEY_MSWheelNavs = {
  [FK_.MSWHEEL_UP]    = FK_.UP,
  [FK_.MSWHEEL_DOWN]  = FK_.DOWN,
  [FK_.MSWHEEL_LEFT]  = FK_.LEFT,
  [FK_.MSWHEEL_RIGHT] = FK_.RIGHT,
  --[FK_.MSWHEEL_UP]    = FK_.PGUP,
  --[FK_.MSWHEEL_DOWN]  = FK_.PGDN,
} -- FKEY_MSWheelNavs

---------------------------------------- Symbols mapping
-- Символы для особых клавиш.
--[[ Values:
  0 - special symbol key without shift.
  1 - special symbol key with shift.
  2 - standard symbol key without shift.
  3 - standard symbol key with shift.
--]]
keys.KSYM_Mods = {
  [' '] = 2, --['\127'] = 2, -- Space, Delete -- TODO: etc
  ['!'] = 3, ['@'] = 3, ['#'] = 3, ['$'] = 3, ['%%'] = 3,
  ['^'] = 3, ['&'] = 3, ['*'] = 3, ['('] = 3, [')']  = 3,
  ['-'] = 0, ['_'] = 1, ['='] = 0, ['+'] = 1, ['`']  = 0, ['~'] = 1,
  ['['] = 0, ['{'] = 1, [']'] = 0, ['}'] = 1, ['\\'] = 0, ['|'] = 1,
  [';'] = 0, [':'] = 1, ["'"] = 0, ['"'] = 1,
  [','] = 0, ['<'] = 1, ['.'] = 0, ['>'] = 1, ['/']  = 0, ['?'] = 1,
} -- KSYM_Mods

keys.KSYM_FKeys = { -- KEY_
  [' ']    = "SPACE",
  --['\127'] = ""
  [';'] = "COLON",
  ['/'] = "SLASH",
  ['`'] = "`",
  ['['] = "BRACKET",
 ['\\'] = "BACKSLASH",
  [']'] = "BACKBRACKET",
  ["'"] = "QUOTE",
  ['-'] = "-",
  ['='] = "=",
  [','] = "COMMA",
  ['.'] = "DOT",
} -- KSYM_FKeys

keys.KSYM_VKeys = { -- VK_
  [' '] = "SPACE",
  [';'] = "OEM_1", -- ";:"
  ['/'] = "OEM_2", -- "/?"
  ['`'] = "OEM_3", -- "`~"
  ['['] = "OEM_4", -- "[{"
 ['\\'] = "OEM_5", -- "\\|"
  [']'] = "OEM_6", -- "]}"
  ["'"] = "OEM_7", -- "'"'"'
  ['-'] = "OEM_MINUS",  -- "-_"
  ['='] = "OEM_PLUS",   -- "=+"
  [','] = "OEM_COMMA",  -- ",<"
  ['.'] = "OEM_PERIOD", -- ".>"
} -- KSYM_VKeys

do
  local pairs = pairs

-- Различие символов для клавиш с Shift.
keys.SKEY_Shifts = {
  ['!'] = '1', ['@'] = '2', ['#'] = '3', ['$'] = '4', ['%%'] = '5',
  ['^'] = '6', ['&'] = '7', ['*'] = '8', ['('] = '9', [')']  = '0',
  ['_'] = '-', ['+'] = '=', ['~'] = '`',
  ['{'] = '[', ['}'] = ']', ['|'] = '\\',
  [':'] = ';', ['"'] = "'",
  ['<'] = ',', ['>'] = '.', ['?'] = '/',
} -- SKEY_Shifts

keys.SKEY_SBacks = {}
for k, v in pairs(keys.SKEY_Shifts) do keys.SKEY_SBacks[v] = k end

  local charkey = string.byte

-- Различие кодов символов для клавиш с Shift.
keys.AKEY_Shifts = {}
for k, v in pairs(keys.SKEY_Shifts) do
  keys.AKEY_Shifts[charkey(k)] = charkey(v)
end
--logShow(keys.AKEY_Shifts, "AKEY_Shifts", "x2")

keys.AKEY_SBacks = {}
for k, v in pairs(keys.AKEY_Shifts) do keys.AKEY_SBacks[v] = k end

end -- do

---------------------------------------- Keys mapping/diffs
-- Различие кодов: KEY_ --> VK_
keys.FKEY_to_VKEY = {
  --[0x000]       = 0x00,         -- NULL
  [FK_.BS]      = VK_.BACK,     -- BS / Back
  [FK_.TAB]     = VK_.TAB,      -- Tab
  [FK_.ENTER]   = VK_.RETURN,   -- Enter / Return
  [FK_.ESC]     = VK_.ESCAPE,   -- Escape / Esc
  [FK_.SPACE]   = VK_.SPACE,    -- Space
  -- TODO: Сделать автогенерацию части для FKEY_to_VKEY и VKEY_to_FKEY
  --       в одном цикле по KSYM_FKeys+FKEY_Keys и KSYM_VKeys+VKEY_Keys! при = 0!
  [0x2D]    = VK_.OEM_MINUS,    -- "-_"
  [0x3D]    = VK_.OEM_PLUS,     -- "=+"
  [0x2C]    = VK_.OEM_COMMA,    -- ",<"
  [0x2E]    = VK_.OEM_PERIOD,   -- ".>"
  [0x3B]    = VK_.OEM_1,    -- ";:"
  [0x2F]    = VK_.OEM_2,    -- "/?"
  [0x60]    = VK_.OEM_3,    -- "`~"
  [0x5B]    = VK_.OEM_4,    -- "[{"
  [0x5C]    = VK_.OEM_5,    -- "\\|"
  [0x5D]    = VK_.OEM_6,    -- "]}"
  --[0x22]    = VK_.OEM_7,    -- "'"'"'
  [0x27]    = VK_.OEM_7,    -- "'"'"'
  --[0x??]    = VK_.OEM_102,  -- "<>" / "\\|"
  [FK_.NUMENTER]= VK_.RETURN,   -- NumEnter
  --[FK_.CLEAR]    = VK_.CLEAR,   -- Numpad5 / Clear
  [FK_.NUMDEL]  = VK_.DELETE,   -- NumDel / Decimal
} -- FKEY_to_VKEY

-- Различие кодов: VK_ --> KEY_
keys.VKEY_to_FKEY = {
  --[0x00] = 0x000, -- NULL
  [VK_.BACK]   = FK_.BS,    -- Back / BS
  [VK_.TAB]    = FK_.TAB,   -- Tab
  [VK_.RETURN] = FK_.ENTER, -- Return / Enter
  [VK_.SPACE]  = FK_.SPACE, -- Space
  [VK_.OEM_1] = 0x3B,   -- ";:"
  [VK_.OEM_2] = 0x2F,   -- "/?"
  [VK_.OEM_3] = 0x60,   -- "`~"
  [VK_.OEM_4] = 0x5B,   -- "[{"
  [VK_.OEM_5] = 0x5C,   -- "\\|"
  [VK_.OEM_6] = 0x5D,   -- "]}"
  --[VK_.OEM_7] = 0x22,   -- "'"'"'
  [VK_.OEM_7] = 0x27,   -- "'"'"'
  [VK_.OEM_MINUS]  = 0x2D,  -- "-_"
  [VK_.OEM_PLUS]   = 0x3D,  -- "=+"
  [VK_.OEM_COMMA]  = 0x2C,  -- ",<"
  [VK_.OEM_PERIOD] = 0x2E,  -- ".>"
  --[VK_.OEM_102] = 0x??,     -- "<>" / "\\|"
  --[VK_.CLEAR]  = FK_.CLEAR,     -- Clear / Numpad5 ??
  --[VK_.DELETE] = FK_.DEL,       -- Decimal / NumDel
  --[VK_.DELETE] = FK_.DECIMAL,   -- Decimal / NumDecimal
} -- VKEY_to_FKEY

-- Различие названий VK_ и KEY_ клавиш.
keys.SKEY_Diffs = {
  PRIOR  = "PGUP",
  NEXT   = "PGDN",
  INSERT = "INS",
  DELETE = "DEL",
  CANCEL = "BREAK",
  BACK   = "BS",
  RETURN = "ENTER",
  ESCAPE = "ESC",
  CLEAR  = "NUMPAD5",
  SNAPSHOT = "PRNTSCRN",
  SCROLL   = "SCROLLLOCK",
  CAPITAL  = "CAPSLOCK",
  SLEEP    = "STANDBY",

  OEM_1 = "COLON",      -- ";:"
  OEM_2 = "SLASH",      -- "/?"
  OEM_3 = "`",          -- "`~"
  OEM_4 = "BRACKET",    -- "[{"
  OEM_5 = "BACKSLASH",  -- "\\|"
  OEM_6 = "BACKBRACKET",-- "]}"
  OEM_7 = "QUOTE", -- "'"..'"'
  --OEM_8 = "",      -- ""
  OEM_MINUS  = "-",     -- "-_"
  OEM_PLUS   = "=",     -- "+="
  OEM_COMMA  = "COMMA", -- ",<"
  OEM_PERIOD = "DOT",   -- ".>"

  [':'] = "COLON",
  ['/'] = "SLASH",
  ['['] = "BRACKET",
 ['\\'] = "BACKSLASH",
  [']'] = "BACKBRACKET",
  ['"'] = "QUOTE",
  [','] = "COMMA",
  ['.'] = "DOT",

  [';'] = "SEMICOLON",
} -- SKEY_Diffs

--------------------------------------------------------------------------------
return keys
--------------------------------------------------------------------------------
