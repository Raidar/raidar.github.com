--[[ Shell Execute ]]--

--------------------------------------------------------------------------------
--local _G = _G

----------------------------------------
local logShow = context.ShowInfo

--------------------------------------------------------------------------------
--local args = {...}
--local argc = select("#", ...)

--logShow(args, argc)

local alien2 = require "alien2"

local hShell = alien2.opendll"Shell32"
--logShow(alien2, tostring(hShell))

local ShExec
ShExec = alien2.getfunction(hShell, "ShellExecuteW", "isisss")
--ShExec = alien2.getfunction(hShell, "ShellExecuteW", "isissssi") -- Полный список
ShExec = alien2.getfunction(hShell, "ShellExecuteExW", "ist") -- Таблица

--logShow(ShExec, tostring(hShell))
--logShow(ShExec(0, "", "cls", "", "", 1), "ShExec")
--logShow(ShExec(0, "", "7z.exe", "l *.7z"), "ShExec")

-- Как узнать и задать размер структуры SHELLEXECUTEINFO?
--logShow(ShExec{"i:iiiiiiiii", 30, 15, 18, 22, 9, 110, 5, 0, 0}, "ShExec") -- Неверно

--[[
for k = 1, argc do
  logShow(args[k], tostring(k))
end
--]]

--------------------------------------------------------------------------------