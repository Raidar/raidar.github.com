--[[ UniUtf Unicode ]]--
--[[ Проверка функций lua-версии ]]--

--------------------------------------------------------------------------------

local schar, sbyte = string.char, string.byte
--local ssub = string.sub

----------------------------------------
local bit = bit64
local band, bor = bit.band, bit.bor
--local bnot, bxor = bit.bnot, bit.bxor
local bshl, bshr = bit.lshift, bit.rshift

----------------------------------------
--local context = context
local logShow = context.ShowInfo

local numbers = require 'context.utils.useNumbers'

local hex = numbers.hex8

----------------------------------------
--local farUt = require "Rh_Scripts.Utils.Utils"

----------------------------------------
-- UTF-8 Unicode modules ---
--local UC = require "Rh_Scripts.UniUtf.unicode"
local UH = require "Rh_Scripts.UniUtf.unichar"

local u8 = UH.utf8

--require "unicode"
--local utf8 = unicode.utf8

--------------------------------------------------------------------------------
local function Utf16ToNum (s) -- (four-char string) --> (number)
  local n1, n2, n3, n4 = sbyte(s, 1, 4)
  return bor(     n1 or 0x00,      bshl(n2 or 0x00, 8),
             bshl(n3 or 0x00, 16), bshl(n4 or 0x00, 24))
end --

local function NumToUtf16 (n) -- (number) --> (four-char string)
  return schar(band(n,           0xFF), band(bshr(n,  8), 0xFF),
               band(bshr(n, 16), 0xFF), band(bshr(n, 24), 0xFF))
end --

local function Utf8ToTable (s)
  return { sbyte(s, 1, -1) }
end --

local function Utf8ToHex (s)
  local t = { sbyte(s, 1, -1) }
  local s = ""
  for k = 1, #t do
    s = s..hex(t[k], 2).." "
  end -- for
  local c = 7-#t
  c = c < 0 and 0 or c
  s = s..(" "):rep(c*5)
  return s
end --

local function CheckConverter (s)
  --local n1, n2, n3, n4 = sbyte(s, 1, 4)
  local code = Utf16ToNum(s)
  local enco, enco_c = u8.enco(code)
  --local emco, emco_c = u8.emco(code)
  local deco, deco_c = u8.deco(enco)
  --local deco, deco_c = u8.deco(ssub(enco, 2, 3))
  local scode = hex(code, 8)
  local c = 7-enco:len()
  c = c < 0 and 0 or c

  local t = {
    scode,
    u8.count(enco),
    enco_c,
    hex(deco, 8),
    deco_c,
    Utf8ToHex(enco),
    "'"..enco.."'"..(" "):rep(c),
  } ---

  local u = {
    --u16s = s,
    --code = code,
    count = u8.count(enco),
    enco = { enco, enco_c },
    --emco = { emco, emco_c },
    deco = { deco, deco_c },
    --enco_t = Utf8ToTable(enco),
    --emco_t = Utf8ToTable(emco),
  } ---

  return t, u, scode
end ----

local function TestConverter (s_t, n)
  local s = s_t[n or 2]
  local _, t, scode = CheckConverter(s)
  logShow(t, scode, "d3 xv2")
end ----

local function LogConverter (s_t)
  local ft = dbg.open("Uni_Utf8.txt")
  local t, u, scode
  for k = 1, #s_t do
    ft:logln()
    t, u, scode = CheckConverter(s_t[k])
    ft:Message(table.concat(t, "\t"), nil, 3, "hv2")
  end -- for
  ft:close()
end ----

local s_t = { -- UTF-16 chars:
  "", -- Empty string
  "\086", -- 0x0056 = 0d086
  "\086\003", -- 0x0356 = 0d035 0d003
  "\086\035", -- 0x2356 = 0d035 0d086
  "\086\035\001\000", -- 0x0001 0x2356 = 0d000 0d001 0d035 0d086
  "\000\001\035",     -- 0x0023 0x0100 = 0d035 0d001 0d000
  "\000\001\035\006", -- 0x0623 0x0100 = 0d006 0d035 0d000 0d001
  "\000\000\000\008", -- 0x5000 0x0000 = 0d080 0d000 0d000 0d000
  "\000\001\035\086", -- 0x5623 0x0100 = 0d086 0d035 0d001 0d000
  "\048\004", -- 0x0430 = 0d048 0x004 -- а
  "\061\004", -- 0x043D = 0d061 0x004 -- н
} --- s_t

LogConverter(s_t)
--TestConverter(s_t, 3)

--------------------------------------------------------------------------------
