--[[ Screens ]]--

----------------------------------------
--[[ description:
  -- Menu based screens (windows) list.
  -- Список экранов (окон) на основе меню.
--]]
----------------------------------------
--[[ uses:
  LuaFAR,
  LF context,
  Rh Utils.
  -- group: Common.
  -- areas: any.
--]]
--------------------------------------------------------------------------------

local type = type
local pairs = pairs
local setmetatable = setmetatable

----------------------------------------
local bit = bit64
--local bshr = bit.rshift
local band, bor = bit.band, bit.bor
--local bshl, bshr = bit.lshift, bit.rshift

----------------------------------------
local useprofiler = false
--local useprofiler = true

if useprofiler then
  require "profiler" -- Lua Profiler
  profiler.start("Screens.log")
end

----------------------------------------
local far = far
local F = far.Flags

local AdvControl = far.AdvControl

----------------------------------------
--local context = context
local logShow = context.ShowInfo

--local utils = require 'context.utils.useUtils'
local numbers = require 'context.utils.useNumbers'
local strings = require 'context.utils.useStrings'
local tables = require 'context.utils.useTables'
local datas = require 'context.utils.useDatas'
local locale = require 'context.utils.useLocale'

local divf = numbers.divf

local Null = tables.Null
local addNewData = tables.extend

----------------------------------------
local farUt = require "Rh_Scripts.Utils.Utils"

----------------------------------------
local keyUt = require "Rh_Scripts.Utils.Keys"

local IsModCtrl, IsModAlt = keyUt.IsModCtrl, keyUt.IsModAlt
local IsModCtrlAlt = keyUt.IsModCtrlAlt

--------------------------------------------------------------------------------
local unit = {}

---------------------------------------- Main data
unit.ScriptName = "Screens"
unit.ScriptPath = "scripts\\Rh_Scripts\\Common\\"

local usercall = farUt.usercall
unit.RunMenu = usercall(nil, require, "Rh_Scripts.RectMenu.RectMenu")

---------------------------------------- ---- Custom
unit.DefCustom = {
  name = unit.ScriptName,
  path = unit.ScriptPath,

  label = unit.ScriptName,

  help   = { topic = unit.ScriptName, },
  locale = {
    kind = 'load',
  }, --
} -- DefCustom

----------------------------------------
unit.DefOptions = {
  BaseDir  = "Rh_Scripts.Common."..unit.ScriptName..".",
} -- DefOptions

--[[
local L, e1, e2 = locale.localize(unit.DefCustom)
if L == nil then
  return locale.showError(e1, e2)
end

logShow(L, "L", "wM")
--]]
---------------------------------------- ---- Config
unit.DefCfgData = { -- Конфигурация по умолчанию:
} -- DefCfgData

---------------------------------------- ---- Types
--unit.DlgTypes = { -- Типы элементов диалога:
--} -- DlgTypes

---------------------------------------- Configure

---------------------------------------- Main class
local TMain = {
  --Guid       = win.Uuid(""),
  --ConfigGuid = win.Uuid(""),
}
local MMain = { __index = TMain }

-- Создание объекта основного класса.
local function CreateMain (ArgData)

  local self = {
    ArgData   = addNewData(ArgData, unit.DefCfgData),

    Custom    = false,
    Options   = false,
    History   = false,
    CfgData   = false,
    --DlgTypes  = unit.DlgTypes,
    LocData   = false,
    L         = false,

    -- Текущее состояние:
    Items     = false,    -- Список пунктов меню
    Props     = false,    -- Свойства меню

    ActItem   = false,    -- Выбранный пункт меню
    ItemPos   = false,    -- Позиция выбранного пункта меню
    --Action    = false,    -- Выбранное действие
    --Effect    = false,    -- Выбранный эффект
  } --- self

  self.ArgData.Custom = self.ArgData.Custom or {} -- MAYBE: addNewData with deep?!
  --logShow(self.ArgData, "ArgData", "wA d2")
  self.Custom = datas.customize(self.ArgData.Custom, unit.DefCustom)
  self.Options = addNewData(self.ArgData.Options, unit.DefOptions)

  self.History = datas.newHistory(self.Custom.history.full)
  self.CfgData = self.History:field(self.Custom.history.field)

  --local CfgData = self.CfgData

  setmetatable(self.CfgData, { __index = self.ArgData })
  --logShow(self.CfgData, "CfgData", "w")

  locale.customize(self.Custom)
  --logShow(self.Custom, "Custom")

  return setmetatable(self, MMain)
end -- CreateMain

---------------------------------------- Dialog

---------------------------------------- Main making

---------------------------------------- ---- Init
do

end -- do
---------------------------------------- ---- Prepare
do
-- Localize data.
-- Локализация данных.
function TMain:Localize ()
  local self = self

  self.LocData = locale.getData(self.Custom)
  -- TODO: Нужно выдавать ошибку об отсутствии файла сообщений!!!
  if not self.LocData then return end

  self.L = locale.make(self.Custom, self.LocData)

  return self.L
end ---- Localize

--[[
function TMain:MakeColors ()

  local colors = require 'context.utils.useColors'
  local basics = colors.BaseColors
  local Basis = {
    --StandardFG  = basics.black,
    SelectedFG  = basics.blue,
    MarkedFG    = basics.maroon,
    --BorderFG    = basics.black,
    --TitleFG     = basics.black,
    --StatusBarFG = basics.black,
    --ScrollBarFG = basics.black,
  } --- Basis

  local menUt = require "Rh_Scripts.Utils.Menu"
  self.Colors = menUt.FormColors(Basis)

  return true
end ---- MakeColors
--]]

function TMain:MakeProps ()
  local self = self

  -- Свойства меню:
  local Props = self.CfgData.Props or {}
  self.Props = Props

  Props.Id = Props.Id or self.Guid
  Props.HelpTopic = self.Custom.help.tlink

  local L = self.LocData
  Props.Title  = L.Screens
  --Props.Bottom = L.ScreensKeys

  -- Свойства RectMenu:
  local RM_Props = {
    Order = "H",
    Cols = 1,

    --MenuEdge = 2,
    MenuAlign = "CM",

    --Colors = self.Colors,

  } --- RM_Props
  Props.RectMenu = RM_Props

  return true
end ---- MakeProps

local Msgs = {
  NoLocale  = "No localization",
} ---

-- Подготовка.
-- Preparing.
function TMain:Prepare ()

  if not self:Localize() then
    --self.Error = Msgs.NoLocale
    --return
    self.LocData = {}
  end

  --self:MakeColors()

  return self:MakeProps()
end ---- Prepare

end -- do
---------------------------------------- ---- Menu
do
--[[
-- Заполнение меню.
function TMain:FillMenu () --> (table)
end ---- FillMenu
--]]

-- Формирование меню.
function TMain:MakeMenu () --> (table)
  local self = self

  local t = {}
  self.Items = t

  local Count = AdvControl(F.ACTL_GETWINDOWCOUNT)
  local Current

  -- Формирование пунктов:
  for i = 1, Count do
     local Info = AdvControl(F.ACTL_GETWINDOWINFO, i)

     Info.Current  = (band(Info.Flags, F.WIF_CURRENT) ~= 0)
     Info.Modified = (band(Info.Flags, F.WIF_MODIFIED) ~= 0)
     if Info.Current then Current = Info end

     Info.wtype = Info.TypeName:sub(1, 1) or ' '
     Info.title = Info.Name:match('[^\\/]+$') or 'none'
     Info.text  = ('%2i. %s %s%s %s'):format(i, Info.wtype,
                                              Info.Modified and '*' or ' ',
                                              Info.Current and '>' or ' ',
                                              Info.title)
     t[#t+1] = Info
  end --
  if not Current then
    for k, v in ipairs(t) do
       v.disable = true
    end
  end
  --logShow(t, "Screens", "wM")

  self.Props.SelectIndex = Current.index or 1

  --self:FillMenu() -- Таблица символов

  return true
end -- MakeMenu

-- Формирование календаря.
function TMain:Make () --> (table)

  self.Items = false -- Сброс меню (!)

  return self:MakeMenu()
end -- Make

end -- do
---------------------------------------- ---- Utils

---------------------------------------- ---- Events
do
  local CloseFlag  = { isClose = true }
  local CancelFlag = { isCancel = true }
  local CompleteFlags = { isRedraw = false, isRedrawAll = true }

--[[
  local DateActions = {
    AltLeft     = "dec_m",
    AltRight    = "inc_m",
    AltUp       = "dec_y",
    AltDown     = "inc_y",
  } -- DateActions

  local InputActions = {
    ["1"] = true,
    ["2"] = true,
    ["3"] = true,
    ["4"] = true,
    ["5"] = true,
    ["6"] = true,
    ["7"] = true,
    ["8"] = true,
    ["9"] = true,
    ["0"] = true,
    ["-"] = true,
    ["BS"] = true,
    ["Subtract"] = true,
  } --- InputActions
--]]

function TMain:AssignEvents () --> (bool | nil)
  local self = self

  local function MakeUpdate () -- Обновление!
    farUt.RedrawAll()
    self:Make()
    --logShow(self.Items, "MakeUpdate")
    if not self.Items then return nil, CloseFlag end
    --logShow(ItemPos, hex(FKey))
    return { self.Props, self.Items, self.Keys }, CompleteFlags
  end -- MakeUpdate

  local function ChangeScreen (Info) --> (bool)
    if AdvControl(F.ACTL_SETCURRENTWINDOW, Info.Pos) == 0 then
      return
    end
    if AdvControl(F.ACTL_COMMIT) == 0 then return end

    return true
  end -- ChangeScreen

  -- Обработчик выделения пункта.
  local function SelectItem (Kind, ItemPos)
    local Info = self.Items[ItemPos]
    --logShow(Info, ItemPos, "w d2")
    if not Info then return end

    local r = AdvControl(F.ACTL_SETCURRENTWINDOW, Info.Pos)
    logShow(Info, r, "w d2")
    r = AdvControl(F.ACTL_COMMIT)
    logShow(Info, r, "w d2")
    
    return self:Make()
  end -- SelectItem

  -- Обработчик выбора пункта.
  local function ChooseItem (Kind, ItemPos)
    local Info = self.Items[ItemPos]
    if not Info then return end

    if Kind == "Enter" then
      if ChangeScreen(Info) then return end

      return MakeUpdate()
    end

    return nil, CloseFlag
  end -- ChooseItem

  -- Назначение обработчиков:
  local RM_Props = self.Props.RectMenu
  --RM_Props.OnSelectItem = SelectItem
  RM_Props.OnChooseItem = ChooseItem
end -- AssignEvents

end --

---------------------------------------- ---- Show
-- Показ меню заданного вида.
function TMain:ShowMenu () --> (item, pos)
  return usercall(nil, unit.RunMenu, self.Props, self.Items, self.Keys)
end ---- ShowMenu

-- Вывод календаря.
function TMain:Show () --> (bool | nil)

  --local Cfg = self.CfgData

  self:Make()
  if self.Error then return nil, self.Error end

  if useprofiler then profiler.stop() end

  self.ActItem, self.ItemPos = self:ShowMenu()

  return true
end -- Show

---------------------------------------- ---- Run
function TMain:Run () --> (bool | nil)

  self:AssignEvents()

  return self:Show()
end -- Run

---------------------------------------- main

function unit.Execute (Data) --> (bool | nil)

  --logShow(Data, "Data", "w d2")

  local _Main = CreateMain(Data)
  if not _Main then return end

  --logShow(Data, "Data", "w d2")
  --logShow(_Main, "Config", "w _d2")
  --logShow(_Main.CfgData, "CfgData", "w d2")
  --if not _Main.CfgData.Enabled then return end

  _Main:Prepare()
  if _Main.Error then return nil, _Main.Error end

  return _Main:Run()
end ---- Execute

--------------------------------------------------------------------------------
--return unit
return unit.Execute()
--------------------------------------------------------------------------------
