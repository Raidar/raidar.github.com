
-- [[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]

  local farMatch = regex.match

-- ������ ����� ������� �� ������������ � ���������� ���.
local function ParseKeyName (KeyName) --> (mod, key)
  return farMatch(KeyName, "(([LR]?Ctrl)?([LR]?Alt)?(Shift)?)(.*)", 1)
  --return farMatch(KeyName, "((?:R?Ctrl)?(?:R?Alt)?(?:Shift)?)(.*)", 1)
end --

local Keys = {
  "A",
  "L",
  "R",
  "S",
  "Add",
  "Left",
  "Right",
  "Space",
} --- Keys

local Mods = {
  "",
  "Alt",  "LAlt",  "RAlt",
  "Ctrl", "LCtrl", "RCtrl",
  "Shift",

  "AltShift",  "LAltShift",  "RAltShift",

   "CtrlAlt",  "CtrlLAlt",  "CtrlRAlt",
  "LCtrlAlt", "LCtrlLAlt", "LCtrlRAlt",
  "RCtrlAlt", "RCtrlLAlt", "RCtrlRAlt",

  "CtrlShift", "LCtrlShift", "RCtrlShift",

   "CtrlAltShift",  "CtrlLAltShift",  "CtrlRAltShift",
  "LCtrlAltShift", "LCtrlLAltShift", "LCtrlRAltShift",
  "RCtrlAltShift", "RCtrlLAltShift", "RCtrlRAltShift",
} --- Mods

--local n = #Keys

local t = {}

for m = 1, #Mods do
  for k = 1, #Keys do
    --t[#t + 1] = { ParseKeyName(Mods[m]..Keys[k]) }
    local mMod, mCtrl, mAlt, mShift, mKey = ParseKeyName(Mods[m]..Keys[k])
    t[#t + 1] = { mMod, mKey }
  end
end

logShow(t, "ParseKeyName")
