--[[ Работа со списком пунктов ]]--

--------------------------------------------------------------------------------

----------------------------------------
local F = far.Flags

----------------------------------------
--local context = context
local logShow = context.ShowInfo

--local utils = require 'context.utils.useUtils'
local numbers = require 'context.utils.useNumbers'

----------------------------------------
--local farUt = require "Rh_Scripts.Utils.Utils"

--------------------------------------------------------------------------------

----------------------------------------
local function GetUM ()
  local Props = {
    --HelpTopic = "Contents",
    --HelpTopic = '<'.."D:\\Programs\\Far\\Plugins\\LF4Ed\\scripts\\Rh_Scripts\\RectMenu\\RectMenuRus.hlf"..'>',
    --HelpTopic = '<'.."D:\\Programs\\Far\\Plugins\\LF4Ed\\scripts\\Rh_Scripts\\RectMenu\\RectMenuRus.hlf"..'>'.."Contents",
    Title = "UM",
    --Bottom = "Keys",
    Bottom = "Bottom text for using keys help",
    Flags = F.FMENU_WRAPMODE,
    --Flags = F.FMENU_WRAPMODE, -- DONE
    --Flags = newFlags(F.FMENU_WRAPMODE, F.FMENU_AUTOHIGHLIGHT), -- DONE
    --Flags = newFlags(F.FMENU_WRAPMODE, F.FMENU_REVERSEAUTOHIGHLIGHT), -- DONE
    --Flags = newFlags(F.FMENU_WRAPMODE, F.FMENU_SHOWAMPERSAND), -- DONE
    --Flags = newFlags(F.FMENU_WRAPMODE, F.FMENU_CHANGECONSOLETITLE), -- TODO: MAYBE
    --SelectIndex = 2,
    SelectIndex = 32,
    --SelectIndex = 34,
    --SelectIndex = 713,
    -- Свойства прямоугольного меню:
    RectMenu = {
      --LTitle = "Left title",
      --RTitle = "Right title",
      --lineMax = 1,
      --lineMax = 2,
      --lineMax = { [3] = 2, },
      --MultiLine = true,
      --BoxScroll = true,
      --BoxScroll = false,
      --MenuOnly = false,
      --MenuOnly = true,
      --MenuEdge = 2,
      --MenuEdge = 4,
      --BoxKind = nil,
      --BoxKind = "",
      --BoxKind = "S",
      --BoxKind = "D",
      --BoxKind = "R",
      --BoxKind = "L",
      --BoxKind = "Y",
      --BoxKind = "B",
      --textMax = 7,
      --textMax = 9,
      --textMax = 16,
      --Rows = Cols = nil -- DONE
      --Rows = 0,
      --Cols = 0,
      --Rows = 6,
      --Cols = 9,
      Cols = 10,
      --Cols = 4,
      --Shape = "H", -- "V" by default
      --Order = "V", -- "H" by default
      --Separators = "H",
      --Separators = "V",
      --Separators = "HV",
      CheckedChar   = "+",
      UncheckedChar = "-",
      --[[
      Fixed = {
        HeadRows = 1,
        FootRows = 3,
        HeadCols = 2,
        FootCols = 1,
      },
      --]]
    }, ----- RectMenu
  } --- Props
  local Menu, str = {}
  local Count = 100
  Count = 33
  --Count = 170
  --Count = 370
  --Count = 765
  --Count = 770

  local Rows = Props.RectMenu.Rows
  local Cols = Props.RectMenu.Cols
  if Rows then
    Cols = numbers.divc(Count, Rows)
  elseif Cols then
    Rows = numbers.divc(Count, Cols)
  else
    Rows = numbers.sqrti(Count)
    Cols = numbers.divc(Count, Rows)
  end

  for k = 1, Count do
    str = "Item "
    --if k % Cols <= 11 then str = "" end
    if k > 30 then str = str..'&' end
    Menu[k] = { text = str..tostring(k) }
    --Menu[k] = { text = str..tostring(k), Flags = 0 }
  end

  Menu[1].text = "Выбери &1"
  Menu[2].text = "Item&&&2"

  Menu[3].hidden = true
  --Menu[3].AccelKey = 0x42 -- B

  Menu[4].text = "Item && &4"
  Menu[4].Hint = "Item #4"

  Menu[5].text = "Item 5-"
  Menu[5].disable = true

  Menu[6].text = "Item &&6-"
  Menu[8].text = "Test item text"
  --Menu[7].AccelKey = 0x41 -- A
  --Menu[8].AccelKey = 0x61 -- a
  
  Menu[10].separator = true
  --Menu[10].AccelKey = 0x63 -- c

  Menu[16].text = "&Элемент 1&&6-"
  Menu[18].text = "&Разовый элемент"

  Menu[20].disable = true
  Menu[26].grayed = true
  Menu[17].checked = true
  Menu[27].checked = "*"

  Menu[32].text = "Two\nl&ines"
  Menu[33].text = "Tab\tc&har"

  --[[
  Menu[40].text = "&Z"
  Menu[41].text = "&&Z"
  Menu[42].text = "&&&Z"
  Menu[43].text = "&&&&Z"
  Menu[44].text = "&&&&&Z"
  Menu[45].text = "&&&&&&Z"
  Menu[46].text = "&"
  Menu[47].text = "&&"
  Menu[48].text = "&&&"
  Menu[49].text = "&&&&"
  Menu[50].text = "&&&&&"
  Menu[51].text = "&&&&&&"
  Menu[63].text = "NmMa&HrkNm__"
  --Menu[63].RectMenu = { TextMark = { 3, 7 } }
  Menu[Count].disable = true
  --]]

  local BKeys = {
    { BreakKey = "C+A" },
    --{ BreakKey = "OEM_PLUS" },
    --{ BreakKey = "S+OEM_PLUS" },
    --{ BreakKey = "J", Action = "Some action" },
  } --- BKeys

  return Props, Menu, BKeys
end -- GetUM

function ShowTabularMenu ()
  local RunMenu = require "Rh_Scripts.RectMenu.RectMenu"
  local Props, Menu, BKeys = GetUM()
  --[[
  local function KeyPress (FKey, FMod)
    if Props.Bottom and Props.Bottom ~= "" then
      Props.Bottom = Props.Bottom:sub(1, -2)
    end
    return { Props, Menu, BKeys }
  end -- KeyPress
  Props.RectMenu.OnKeyPress = KeyPress
  --]]
  local Result = RunMenu(Props, Menu, BKeys)
  if Result then logShow(Result, "Test RectMenu") end

  return Result
end ---- ShowTabularMenu

function ShowFilterMenu ()
  local RunMenu = require "Rh_Scripts.Common.FilterMenu"
  local Props, Menu, BKeys = GetUM()
  local Result = RunMenu(Props, Menu, BKeys)
  if Result then logShow(Result, "Test RectMenu") end
  return Result
end ---- ShowFilterMenu

function ShowDefaultMenu ()
  local Props, Menu, BKeys = GetUM()
  local Result = far.Menu(Props, Menu, BKeys)
  --if Result then logShow(Result, "Test RectMenu") end
  return Result
end ---- ShowDefaultMenu

--[=[
function ShowRectangMenu ()
  local RunMenu = require "Rh_Scripts.RectMenu.RectMenu"
  local Props, Menu, BKeys = GetUM()
  --[[
  local function KeyPress (FKey, FMod)
    if Props.Bottom and Props.Bottom ~= "" then
      Props.Bottom = Props.Bottom:sub(1, -2)
    end
    return { Props, Menu, BKeys }
  end -- KeyPress
  Props.RectMenu.OnKeyPress = KeyPress
  --]]
  local Result = RunMenu(Props, Menu, BKeys)
  if Result then logShow(Result, "Test RectMenu") end
  return Result
end ---- ShowRectangMenu
--]=]
--------------------------------------------------------------------------------
local args = (...)

--logShow(args, "args", 1)
if type(args) == 'table' and args[1] then
  return getfenv()[ args[1] ](unpack(args, 2))
else
  return ShowTabularMenu()
end
--------------------------------------------------------------------------------
