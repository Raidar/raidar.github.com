--[[ Работа с горизонтальным меню ]]--

--------------------------------------------------------------------------------

----------------------------------------
local F = far.Flags

----------------------------------------
--local context = context
local logShow = context.ShowInfo

--local utils = require 'context.utils.useUtils'
local numbers = require 'context.utils.useNumbers'

----------------------------------------
--local farUt = require "Rh_Scripts.Utils.Utils"

--------------------------------------------------------------------------------

----------------------------------------
local function GetUM ()
  local Props = {
    --HelpTopic = "Contents",
    --HelpTopic = '<'.."D:\\Programs\\Far\\Plugins\\LF4Ed\\scripts\\Rh_Scripts\\RectMenu\\RectMenuRus.hlf"..'>',
    HelpTopic = '<'.."D:\\Programs\\Far\\Plugins\\LF4Ed\\scripts\\Rh_Scripts\\RectMenu\\RectMenuRus.hlf"..'>'.."Contents",
    Title = "UM",
    --Bottom = "Keys",
    Bottom = "Bottom text for using keys help",
    Flags = F.FMENU_WRAPMODE,
    --Flags = F.FMENU_WRAPMODE, -- DONE
    --Flags = newFlags(F.FMENU_WRAPMODE, F.FMENU_AUTOHIGHLIGHT), -- DONE
    --Flags = newFlags(F.FMENU_WRAPMODE, F.FMENU_REVERSEAUTOHIGHLIGHT), -- DONE
    --Flags = newFlags(F.FMENU_WRAPMODE, F.FMENU_SHOWAMPERSAND), -- DONE
    --Flags = newFlags(F.FMENU_WRAPMODE, F.FMENU_CHANGECONSOLETITLE), -- TODO: MAYBE
    SelectIndex = 5,
    -- Свойства прямоугольного меню:
    RectMenu = {
      Position = { x = 0, y = 1 },
      --MenuOnly = false,
      MenuOnly = true,
      --MenuEdge = 2,
      --BoxScroll = true,
      --textMax = 7,
      --textMax = 9,
      --Rows = Cols = nil -- DONE
      Rows = 1,
      --Cols = 1,
      --Rows = 6,
      --Cols = 10,
      --Cols = 4,
      --Shape = "H", -- "V" by default
      --Order = "V", -- "H" by default
      --Separators = "H",
      --Separators = "V",
      --Separators = "HV",
    }, ----- RectMenu
  } --- Props
  local Menu, str = {}
  local Count = 10
  local Rows = Props.RectMenu.Rows
  local Cols = Props.RectMenu.Cols
  if Rows then
    Cols = numbers.divc(Count, Rows)
  elseif Cols then
    Rows = numbers.divc(Count, Cols)
  else
    Rows = numbers.sqrti(Count)
    Cols = numbers.divc(Count, Rows)
  end
  for k = 1, Count do
    str = "Item "
    --if k % Cols <= 11 then str = "" end
    if k > 30 then str = str..'&' end
    Menu[k] = { text = str..tostring(k) }
    --Menu[k] = { text = str..tostring(k), Flags = 0 }
  end
  Menu[2].text = "Item&&&2"
  Menu[3].hidden = true
  Menu[4].text = "Item && &4"
  Menu[5].text = "Item 5-"
  Menu[5].disable = true
  Menu[6].text = "Item &&6-"
  Menu[7].AccelKey = 0x41
  Menu[8].AccelKey = 0x61
  Menu[10].separator = true
  Menu[10].AccelKey = 0x63
  local BKeys = {
    { BreakKey = "CtrlA" },
    { BreakKey = "Add" },
    { BreakKey = "Shift+Add" },
    { BreakKey = "J", Action = "Some action" },
  } --- BKeys

  return Props, Menu, BKeys
end -- GetUM

function ShowHorzMenu ()
  local RunMenu = require "Rh_Scripts.RectMenu.RectMenu"
  local Props, Menu, BKeys = GetUM()
  local Result = RunMenu(Props, Menu, BKeys)
  --logShow(Result, "Test RectMenu")

  return Result
end ---- ShowHorzMenu

function ShowDefaultMenu ()
  local Props, Menu, BKeys = GetUM()
  return far.Menu(Props, Menu, BKeys)
end ---- ShowDefaultMenu

--------------------------------------------------------------------------------
local args = (...)
--logShow(args, "args", 1)

if type(args) == 'table' and args[1] then
  return getfenv()[ args[1] ](unpack(args, 2))
else
  return ShowHorzMenu()
end
--------------------------------------------------------------------------------
