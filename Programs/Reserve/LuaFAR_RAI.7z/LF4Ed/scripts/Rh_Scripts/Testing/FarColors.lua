--[[ Работа с цветами ]]--

--------------------------------------------------------------------------------

----------------------------------------
local far = far
local F = far.Flags

local Colors = far.Colors

----------------------------------------
local fkeys = require "far2.keynames"

local InputRecordToName = fkeys.InputRecordToName

--------------------------------------------------------------------------------

---------------------------------------- Dialog
local dialog = require "far2.dialog"
local dlgUt = require "Rh_Scripts.Utils.Dialog"

local DI = dlgUt.DlgItemType

function TestDlg ()
  local D = dialog.NewDialog() -- Форма окна
  D._     = {DI.DBox,  3, 1, 14,  5, 0, 0, 0,   0, "Testing dialog"}
  D.edt   = {DI.Text,  5, 2, 10,  0, 0, 0, nil, 0, sText}
  D.edt   = {DI.Text,  5, 3, 10,  0, 0, 0, nil, 0, sAccText}

  return D
end ---- TestDlg

local function SendDlgClose (hDlg)
  far.SendDlgMessage(hDlg, "DM_CLOSE", -1, 0)
end

function TestDialog (args, ...)

  local NoDlgClose

  -- ОБРАБОТЧИК НАЖАТИЯ КЛАВИШИ:
  local function DlgCtrlEvent (hDlg, ProcItem, Input) --> (bool)
    local VirKey = far.ParseInput(Input) -- FAR23
    if type(VirKey) ~= 'table' then return end

    local EventType = VirKey.EventType
    if EventType ~= F.KEY_EVENT and
       EventType ~= F.FARMACRO_KEY_EVENT then
      return
    end

    local StrKey = InputRecordToName(VirKey) or ""

    -- Обработка Enter для проверки.
    if StrKey == "Enter" then
      --NoDlgClose = true
      SendDlgClose(hDlg); return true
      --SendDlgClose(hDlg); return false
      --return true
      --return false
    end

    far.Text(2, 2, Colors.COL_MENUTEXT, "Текст COL_MENUTEXT")
    far.Text(2, 4, Colors.COL_MENUHIGHLIGHT, "Текст COL_MENUHIGHLIGHT")
    far.Text(2, 6, Colors.COL_MENUBOX, "Текст COL_MENUBOX")

    return false
  end -- DlgCtrlEvent

  local function DlgClose (hDlg, ProcItem, NoUse) --> (bool)
    --ShowMsg(ProcItem, NoUse)
    -- Закрытие только при правильном выборе пункта меню:
    if NoDlgClose then NoDlgClose = false; return false else return true end
  end -- DlgClose

  -- Обработчик событий диалога.
  local function DlgProc (hDlg, msg, param1, param2)
    -- Ссылки на обработчики событий:
    local Procs = {
      [F.DN_CONTROLINPUT] = DlgCtrlEvent,
      [F.DN_CLOSE]        = DlgClose,
    }
    if Procs[msg] then return Procs[msg](hDlg, param1, param2) end
    --[[ -- For Debug:
    if Procs[msg] then
      local Result = Procs[msg](hDlg, param1, param2)
      --if msg == F.DN_KEY then ShowMsg(Result, "DlgProc Result") end
      return Result
    end
    --]]
  end -- DlgProc

  local D = TestDlg()
  local Flags = { FDLG_SMALLDIALOG = 1, FDLG_NODRAWSHADOW = 1 }
  local Result = dlgUt.Dialog(nil, -1, -1, D._[4]+4, D._[5]+2, nil, D, Flags, DlgProc) -- FAR3: GUID
  --ShowMsg(Result, "dialog Result")
end ---- TestDialog

--------------------------------------------------------------------------------
return TestDialog(...)
--------------------------------------------------------------------------------
