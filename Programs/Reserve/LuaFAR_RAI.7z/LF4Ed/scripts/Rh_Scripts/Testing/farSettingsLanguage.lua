--[[ Test far Settings Language ]]--

----------------------------------------
local far = far
local F = far.Flags

----------------------------------------
-- [[
local dbg = require "context.utils.useDebugs"
local logShow = dbg.Show
--]]
----------------------------------------
far.FreeSettings()

--local obj = far.CreateSettings("far")
local obj = far.CreateSettings("far", F.PSL_LOCAL)
if not obj then return end

local key = obj:OpenSubkey(0, "Language")
if not key then return end

local typ = F.FST_STRING
local lngMain = obj:Get(key, "Main", typ) -- Язык интерфейса
local lngHelp = obj:Get(key, "Help", typ) -- Язык справки

local Enum = obj:Enum(key)

local t = {
  settings = obj,
  name = "Language",
  key = key,
  Main = lngMain,
  Help = lngHelp,
  --ActUrl = actUrl,
  Enum = Enum,
} ---

logShow(t, "far Settings Language", "wM")

obj:Free()

--------------------------------------------------------------------------------
