--[[ TT: text ]]--

----------------------------------------
--[[ description:
  -- Templates for 'text'.
  -- Шаблоны для 'text'.
--]]
--------------------------------------------------------------------------------
local line_len = 40
local line_hymin = ('-'):rep(line_len)
local line_equal = ('='):rep(line_len)

---------------------------------------- Data
local Data = {
  --[[DO]]--

  regex = false; -- !!!

  --[[Templates]]-- Шаблоны:

  -- Simple lines:
  { find = "`---`",  plain = line_hymin },
  { find = "ё---ё",  plain = line_hymin },
  { find = "`===`",  plain = line_equal },
  { find = "ё===ё",  plain = line_equal },
  { find = "`----`", plain = line_hymin..line_hymin },
  { find = "ё----ё", plain = line_hymin..line_hymin },
  { find = "`====`", plain = line_equal..line_equal },
  { find = "ё====ё", plain = line_equal..line_equal },
} --- Data

return Data
--------------------------------------------------------------------------------
