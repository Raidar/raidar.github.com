
return { LuaFarHotKey='L' }
