--[[ Menu Extending ]]--

----------------------------------------
--[[ Common Settings ]]--

--local rhlog = require "scripts/Rh_Scripts/Utils/Logging"
--rhlog.TblMsg(_G, "_G", 0, "f")
--rhlog.TblMsg(getfenv(), "getfenv", 1)

--local UseAutoAdding = true
local UseAutoAdding = false

----------------------------------------
--[[ Add User Files ]]--

-- Add LuaFAR context features first only!!!
require "context.initiate"       -- LFc initiate
if context.use.LFVer >= 3 then
MakeResident("context.resident") -- LFc resident
else
MakeResident(require "context.resident") -- LFc resident
end

--MakeResident("Test_Redraw")

--return -- TEST LuaFAR context only

-- [==[
if UseAutoAdding then
  --[[ Auto loading ]]--
  --AutoInstall("", "%_.+menu%.lua", 1) -- Загрузка всех _*menu.lua
  AutoInstall("scripts/", "%_.+menu%.lua$", 1) -- Загрузка всех _*menu.lua
  --AutoInstall("scripts/", "%_usermenu%.lua$", 1) -- Загрузка всех _usermenu.lua
else
  --[[ Manual loading ]]--

  AddUserFile('scripts/lfa_config/_usermenu.lua') -- LFA config menu

  AddUserFile("scripts/Rh_Scripts/_usermenu.lua") -- Rh_Scripts menu

  AddUserFile("scripts/Rh_Scripts/_selfmenu.lua") -- Self-created menu
  AddUserFile("scripts/TestScripts/_usermenu.lua") -- Test scripts menu

  AddUserFile('scripts/fl_scripts/_usermenu.lua') -- farlua scripts menu
end
--]==]

----------------------------------------
--[[ Some menu items ]]--

----------------------------------------
--[[ Command prefixes ]]--

--local rhlog = require "scripts/Rh_Scripts/Utils/Logging"
--rhlog.TblMsg(_G, "_G", 0, "tf")
--------------------------------------------------------------------------------
